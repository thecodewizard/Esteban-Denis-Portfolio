﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace ShoppingApp
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        /* De doelstellingen van MainWindow:
         * 1. De opgeslagen categoriën en data inladen
         * 2. De gebruiker lijsten laten ontwerpen op basis van ingeladen data
         * 3. De gemaakte lijsten printen/wegschrijven/inladen.
         * 
         * Opslag gebeurd door bestanden in de root van de applicatie.:
         * Lijsten: | TXT-bestand | bestand per lijst: lijstnaam.txt | productnr;productaantal;bslider;selectedcategorie;categorysorted;selectedproduct;productsorted;productview;
         * Producten: | CSV-bestand | 1 bestand: producten.csv | productnr;productnaam;productprijs;categorie;shop;aantalgeselecteerd;
         */

        /* Mainwindow bestaat uit de volgende hoofdmodules:
         * 1. GetData  ->  Bij start applicatie producten ophalen en de categoriën vullen.
         *      A. ImportFile -> producten.csv uitlezen.
         *      B. SortData -> Data wegschrijven naar de juiste array.
         *      C. GiveCategories -> De opgehaalde categoriëen tonen in de combobox.
         *      
         * 2. GetCategory   -> Bij keuze van een categorie de listbox vullen.
         ->     0. ClearWindow ->   Het verwijderen van de te schrijven elementen
         *      A. LoadCategory ->  De categoriëen en de bijhorende producten in een tijdelijke array laden.
         *      B. SortCategory ->  De Tijdelijke array sorteren zoals gewenst.
         *      C. WriteCategory -> De tijdelijke array wegschrijven naar de category-listbox.
         *
         --> GETTEMPFILE -> ADD TO START
         * 3. GetChart  ->  Trigger het tonen/Verversen van het winkelkarretje.
         *      0. ClearWindow
         *      A. ImportFile
         *      B. SortChart    -> De tijdelijke array sorteren zoals gewenst en er de gevraagde gegevens uitfilteren.
         *      C. WriteChart   -> De tijdelijke array wegschrijven naar de chart-listbox.
         *      
         * 4. GetDetails    ->  Vraag het geselecteerde product op en toon de details ervan.
         * 4b. WriteDetails ->  Schijf detailveranderingen weg naar de productarray en schrijf die dan weg naar het productbestand.
         * 5. ScanProducts  ->  Indien de gebruiker quicksearched, geeft het programma op een invoer afgestemde alfabetische aanvulling.
         * 6. AddToChart    ->  Het gevraagde object in de listbox toevoegen aan het winkellijstje.
         ->     0. GuaranteeFileExistance -> Controleer ofdat het naar weg te schrijven bestand al bestaat.
         ->     1. AddToArray ->  Het gevraagde bestand toevoegen aan de array.
         *      A. ExportToChart -> De chart wegschrijven naar de tijdelijke chart File.
         *      B. GetChart
         *      
         * 7. PrintChart    -> Deze methode initieert het printen van het karretje.
         * 8. SaveChart     -> Deze methode schrijft het gemaakte winkelkarretje weg. Enkel bij wijzigingen kan deze knop nogmaals ingedrukt worden.
         * 8b. SaveProducts ->  Deze methode zal het productenbestand overschrijven.
         * 9. ImportChart     -> Deze methode zal een eerder ontworpen winkellijstje inladen.
         *      A. ImportFile
         *      D. PrepareWindow    -> Deze zal ervoor zorgen dat de scherminstellingen conform zijn met de opgeslagen instellingen.
         *      E. GetChart.
         * 10. GetBackToMenu    ->  Indien men op het logo van de shoppingapp klikt komt met terug op de homescreen.
         */

        public MainWindow()
        {
            InitializeComponent();
        }

        //Declareren op moduleniveau
        //BasisData
        //Productenarrays
        private String[] marrsProducten = new String[0];    //In deze array zitten alle ingeladen producten     A
        private String[] marrsProductNaam = new String[0];  //In deze array zitten de namen van alle ingeladen producten    A
        private String[] marrsProductprijsType = new String[0]; //In deze array zitten alle ppt van de ingeladen producten. A
        private String[] marrsShop = new String[0]; //In deze array zitten alle winkels van de ingeladen producten      A
        private String[] marrsCategorie = new String[0];    //in deze array zitten alle categoriën van de ingeladen producten.  A
        private int[] marriProductnr = new int[0];  //in deze array zitten alle productnummers van alle ingeladen producten     A
        private int[] marriPopularity = new int[0];   //In deze array zitten alle selectienummers van alle ingeladen producten    A
        private double[] marrdproductprijs = new double[0]; //In deze array zitten alle prijzen van alle ingeladen producten    A
        //Vaste Variabelen
        private String msDataFolder = AppDomain.CurrentDomain.BaseDirectory + "/AppData/";
        private String msProducten = AppDomain.CurrentDomain.BaseDirectory + "/AppData/producten.csv";
        private String msTempChartFile = "";

        //Additional Data
        //Arrays
        private int[] marriInProductList = new int[0];  //In deze array zitten alle productnummers van de elementen in lstproducten B
        private int[] marriInChart = new int[0];    //In deze array zitten alle productnummers van de elementen van de winkelkar    C
        private double[] marrdHoeveelheid = new double[0];  //In deze array zitten de gekozen hoeveelheden van alle ingeladen producten C
        private bool[] marrbSlider = new bool[0];   //In deze array zit gegeven ofdat de slider moet weergegeven worden voor een bepaald element. C
        //Variabelen
        private String msLoadedFile = "";
        private int miQuickSearchSuggestion;
        private int miTEMPdetails;
        private bool mbEditingDetails;
        private bool mbDetailsChanged;
        private bool mbSliderMovedByHuman;
        private bool mbDroppedDown;
        //Objecten
        private DispatcherTimer tmr = new DispatcherTimer();
        private object oSliderSender = null;

        private void LoadWindow()
        {
            //Deze methode zal bij het starten de window klaarzetten voor gebruik.
            InitialiseWindowElements(); //Zet alle verandelijke controls klaar voor gebruik
            InitTimer();
            EnableDisableControls();    //Window Klaarzetten
            ImportProductData();    //Haal alle begindata uit de arrays
            GetTempFile();  //Genereer een tijdelijk bestand voor het karretje.
            ControlLoadedFile();    //Controleer ofdat er een winkelkarretje geladen moet worden.
        }   //H. Laden van Window

        private void ImportProductData()
        {
            //Deze methode zal de data uit product.csv inladen in de juiste arrays.
            ClearProductArrays();   //Verwijder te schrijven arrays.
            ImportFile(ref marrsProducten, msProducten);    //Importeer alle producten in de productarray.
            InterpretData(marrsProducten); //Sorteer de gegevens naar de juiste subarrays.
            LoadCategories(); //Toon de juiste categoriën in de combobox.
        }   //H. Productarrays Vullen.

        private void ExportProductData()
        {
            //Deze methode zal de productenarray herschrijven
            //Het te schrijven bestand leegmaken.
            GuaranteeFileExistance(msProducten);    //Zeker van zijn dat het bestaat alvorens te verwijderen om crashfouten tegen te gaan.
            File.Delete(msProducten);   //Het bestand verwijderen
            File.Create(msProducten).Close();   //Het bestand opnieuw aanmaken.
            using (StreamWriter initialiser = new StreamWriter(msProducten, false))
            {
                String sInit = "PRODUCTDATA SHOPPINGAPP V2.0, WRITTEN ON " + System.DateTime.Today.ToShortDateString() + ": ";
                initialiser.WriteLine(sInit);
            }
            //Per product de volledige lijn aanmaken en wegschrijven naar een tijdelijke array.
            for (int i = 0; i < marriProductnr.Length; i++)
            {
                String sLine = marriProductnr[i].ToString();
                sLine += ";" + marrsProductNaam[i].Replace(' ', '_');
                sLine += ";" + marrdproductprijs[i] + marrsProductprijsType[i].Replace(' ', '_').Replace('€', '&');
                sLine += ";" + marrsCategorie[i].Replace(' ', '_');
                sLine += ";" + marrsShop[i].Replace(' ', '_');
                sLine += ";" + marriPopularity[i].ToString() + ";";
                //De gegenereerde lijn wegschrijven naar het productenbestand
                using (StreamWriter writer = new StreamWriter(msProducten, true))
                {
                    writer.WriteLine(sLine);
                }
            }
        } //H. Exporteer de productenarrays.

        private void LoadProducts()    //H. Vul de productenlijst.
        {
            //Deze methode zal bij een keuze van de categorie de juiste producten in de productenlijst plaatsen.
            //eerst de lijsten leegmaken alvorens ze te vullen.
            ClearWindow(false, true);
            Array.Resize(ref marriInProductList, 0);

            int[] arriTemp = new int[0]; //De categorieën en de bijhorende producten in een tijdelijke array laden.
            if (cboCategories.SelectedIndex >= 0)  //Deze waarde kan negatief worden tijdens het verversen van de lijst.
            {
                String sSelectedCategory = cboCategories.SelectedItem.ToString();

                //De producten behorend tot de categorie ophalen.
                FindProducts(ref arriTemp, sSelectedCategory);     //Vind alle producten in de categorie en NIET in de chart.
                SortProducts(ref arriTemp); //Sorteer alle producten zoals gevraagd mbv. Radiobuttons
                ListProducts(arriTemp);     //Vul de listbox met de gesorteerde producten.
            }
            EnableDisableControls();
        }

        private void ImportChartData()
        {
            //Deze methode zal de data voor het karretje ophalen uit het tijdelijk bestand en opslaan in de karretjearrays.
            //De karretjesarrays zijn: marriInChart (prodnrs) + marrdHoeveelheid (#geselecteerd) + marrbSlider (sld bool).
            //Het bestand ophalen
            String[] arrsTemp = new String[0];
            ImportFile(ref arrsTemp, msTempChartFile);
            //De karretjesarrays legen alvorens ze opnieuw te vullen
            Array.Resize(ref marriInChart, 0);
            Array.Resize(ref marrdHoeveelheid, 0);
            Array.Resize(ref marrbSlider, 0);
            //De opgehaalde lijn splitsen over de juiste subarrays
            InterpretChart(arrsTemp);   //Splitsen in subarrays.
            LoadChart();    //Het karretje tonen nadat de nieuwe arrays geladen zijn.
        }   //H. Chartarrays Vullen.

        private void ExportChartData()
        {
            //Deze methode zal de huidige karretjearray wegschrijven naar het tijdelijk bestand en een nieuwe import aanvragen.
            //Het bestand verwijderen en opnieuw aanmaken om hem zo 'instantly' leeg te maken.
            GuaranteeFileExistance(msTempChartFile);        //Het bestand eerst garanderen om verwijderfouten te voorkomen.
            File.Delete(msTempChartFile);
            GetTempFile();
            using (StreamWriter initialiser = new StreamWriter(msTempChartFile, false))
            {
                String sInit = "CHARTDATA SHOPPINGAPP V2.0, WRITTEN ON " + System.DateTime.Today.ToShortDateString() + ": ";
                initialiser.WriteLine(sInit);
            }
            //Lijn per lijn elk product in het karretje overlopen en de gegevens verzamelen.
            foreach (int iProductnr in marriInChart)
            {
                //Enkel lijnen wegschrijven waarvan er geen "0" items geselecteerd zijn
                if (marrdHoeveelheid[Array.IndexOf(marriInChart, iProductnr)] != 0)
                {
                    String sLine = iProductnr + ";";        //0. productnummer
                    sLine += marrdHoeveelheid[Array.IndexOf(marriInChart, iProductnr)] + ";";       //1. Selectiehoeveelheid
                    sLine += marrbSlider[Array.IndexOf(marriInChart, iProductnr)] + ";";    //2. Sliderzichtbaarheid
                    if (cboCategories.SelectedIndex >= 0) sLine += marrsCategorie[cboCategories.SelectedIndex].Replace(' ', '_') + ";";   //3. Categorie
                    else sLine += "0;";
                    if (rbtAlphaBet.IsChecked == true) sLine += "rbtAlphaBet;"; //4. CategorieSortering
                    if (rbtPopularity.IsChecked == true) sLine += "rbtPopularity;";
                    if (rbtPrice.IsChecked == true) sLine += "rbtPrice;";
                    if (rbtShop.IsChecked == true) sLine += "rbtShop";
                    if (lstProducten.SelectedIndex >= 0) sLine += marriInChart[lstProducten.SelectedIndex] + ";";   //5. Geselecteerd listitem
                    else sLine += "0;";
                    sLine += btnSort.Content.ToString().Replace(' ', '_') + ";"; //6. Gesorteerde knop
                    sLine += btnView.Content.ToString().Replace(' ', '_') + ";"; //7. ViewKnop
                    //De gegenereerde lijn wegschrijven naar het bestand.
                    using (StreamWriter writer = new StreamWriter(msTempChartFile, true))
                    {
                        writer.WriteLine(sLine);
                    }
                }
            }
        } //H. Chartarrays wegschrijven naar het tijdelijke bestand.

        private void LoadChart()
        {
            //Deze methode maakt het karretje aan op basis van de karretjesarrays.
            //De huidige instellingen ophalen.
            string sView = btnView.Content.ToString();
            string sSort = btnSort.Content.ToString();
            //Voor het vullen van het winkelkarretje, eerst het karretje leegmaken.
            ClearWindow(false, false, true, false, true);
            //De huidige karretjesarray Sorteren zoals gevraagd.
            SortChart(ref marriInChart, sSort);
            //Het karretje wegschrijven
            WriteChart(sView);
            //De listBox Vernieuwen
            int iSelected = cboCategories.SelectedIndex;
            if (iSelected != -1) LoadProducts();
            LoadCategories();
            if (cboCategories.Items.Count > iSelected) cboCategories.SelectedIndex = iSelected;
            EnableDisableControls();
        }   //H. Maak het karretje aan uit het karretjesarray.

        private void AddToChart(int iProductNr)
        {
            //Deze methode voegt een product toe aan het karretje
            //De arrays vergroten en nieuwe data toevoegen.
            AddToArray(ref marriInChart, iProductNr);
            AddToArray(ref marrdHoeveelheid, 1);
            AddToArray(ref marrbSlider, false);
            //Registreren dat de populariteit van het gekozen product met 1 gestegen is.
            int iProductplaats = Array.IndexOf(marriProductnr, iProductNr);
            marriPopularity[iProductplaats] = marriPopularity[iProductplaats] + 1;
            //Het karretje vernieuwen om de veranderingen door te pushen.
            LoadChart();
            LoadProducts();

        } //H. Voeg een product toe aan het karretje

        private void WriteChart(String sViewCode)
        {
            //Deze methode schrijft de huidige karretjesarrays weg in de listbox.
            for (int i = 0; i < marriInChart.Length; i++)
            {
                //Verkrijg de data van het huidige item.
                int iProductNr = marriInChart[i];
                int iProductPositie = Array.IndexOf(marriProductnr, iProductNr);
                //Maak de te schrijven lijn op.
                String sProductData = marrsProductNaam[iProductPositie];
                if (sViewCode.Contains('€')) sProductData += " - " + marrdproductprijs[iProductPositie].ToString("C") + " " + marrsProductprijsType[iProductPositie];
                if (sViewCode.Contains('?')) sProductData += " - " + marrsShop[iProductPositie];
                //Creeër het te maken listitem.
                CreateListItem(sProductData, marrdHoeveelheid[i], i);
            }
        }   //H. Schrijf de huidige karretjearrays weg volgens de viewcode.

        private void LoadDetails(bool bListIsAsker)
        {
            //Deze methode zal de details van een geselecteerd item opvragen.
            //Initieer de benodigde variabelen
            mbEditingDetails = true;
            int iSelectedIndex = -1; int iProductNr = -1;
            //Verwijder de details alvorens ze te vullen.
            ClearWindow(false, false, false, true);
            //Data ophalen van de sender.
            if (bListIsAsker == true)
            {
                iSelectedIndex = lstProducten.SelectedIndex;
                if (iSelectedIndex >= 0) iProductNr = marriInProductList[iSelectedIndex];
            }
            else
            {
                iSelectedIndex = lstChart.SelectedIndex;
                if (iSelectedIndex >= 0) iProductNr = marriInChart[iSelectedIndex];
            }
            if (iProductNr != -1)
            {
                //Data invullen in de details
                int iPositie = Array.IndexOf(marriProductnr, iProductNr);
                txtName.Text = marrsProductNaam[iPositie];
                txtPrijs.Text = marrdproductprijs[iPositie] + marrsProductprijsType[iPositie];
                txtWinkel.Text = marrsShop[iPositie];
                cboCategory.SelectedItem = marrsCategorie[iPositie];
                miTEMPdetails = iProductNr;
            }
            mbEditingDetails = false;
        } //H. Laad de details van een geselecteerd product.

        private void InitialiseWindowElements()
        {
            //Deze methode zal alle veranderlijke controls klaarzetten bij het starten van de applicatie.
            String sCurrentTime = System.DateTime.Today.ToShortDateString();
            txtChartName.Text = sCurrentTime;
            txtChartName.Text = txtChartName.Text.Replace('/', '-');
            txbSearchResult.Visibility = Visibility.Visible;
            cboCategories.SelectedIndex = -1;
        }

        public MainWindow(String sParameter)
            : this()
        {
            this.msLoadedFile = sParameter;
        }

        private void ControlLoadedFile()
        {
            if ((msLoadedFile != null) || (msLoadedFile != ""))
            {
                if (File.Exists(msLoadedFile))
                {
                    ImportChart(true);
                    if (cboCategories.SelectedIndex != -1) LoadProducts();
                }
            }
        }

        private void ImportFile(ref String[] arrsResultaat, String sFilePath)   //De eerste lijn is altijd commentaar
        {
            //Deze methode haalt de gegevens op uit de gevraagde file en geeft ze door aan de opgegeven array.
            Array.Resize(ref arrsResultaat, 0); //De resultaatarray leegmaken.

            using (StreamReader reader = new StreamReader(sFilePath))
            {
                String sLine = reader.ReadLine();   //Lees de eerste lijn, en lees onmiddellijk tweede lijn.
                sLine = reader.ReadLine();

                while (sLine != null)
                {
                    //Lees data en vul aan in array.
                    AddToArray(ref arrsResultaat, sLine.Replace('&', ' '));

                    //initeer volgende loop
                    sLine = reader.ReadLine();
                }
            }
        }

        private void InterpretData(String[] arrsDataPool)   // Productarray verdelen in subarrays.
        {
            //Deze methode zal de data uit de opgegeven array wegschrijven naar de juiste subarrays.
            //Subarrays zijn: marriproductnummer, marrsproductnaam, marrfproductprijs, marrsproductprijstype, marrscategorie, marrfquot 
            bool bSucceeded = false;
            try
            {
                foreach (String sData in arrsDataPool)
                {
                    String[] arrsTemp = sData.Split(';');

                    //1. Sorteer het productnummer.
                    int iProductnummer;
                    bool bTest = int.TryParse(arrsTemp[0], out iProductnummer);
                    if (bTest == true) AddToArray(ref marriProductnr, iProductnummer);

                    //2. Sorteer productnaam & marrscategorie & shop
                    if (bTest == true) AddToArray(ref marrsProductNaam, arrsTemp[1].Replace('_', ' '));
                    if (bTest == true) AddToArray(ref marrsCategorie, arrsTemp[3].Replace('_', ' '));
                    if (bTest == true) AddToArray(ref marrsShop, arrsTemp[4].Replace('_', ' '));

                    //3. Sorteer Productprijs & productprijstype
                    double dProductPrijs = -1; String sProductPrijsType = null;
                    bool bConvert = true;
                    for (int i = 0; i < arrsTemp[2].Length; i++)
                    {
                        if (bConvert == true)
                        {
                            String sTest = arrsTemp[2].Substring(0, i + 1);
                            bConvert = double.TryParse(sTest, out dProductPrijs);
                        }
                        else
                        {
                            if (sProductPrijsType == null)
                            {
                                bool bConvert2 = double.TryParse(arrsTemp[2].Substring(0, i - 1), out dProductPrijs);
                                sProductPrijsType = arrsTemp[2].Substring(i - 1, arrsTemp[2].Length - i + 1);
                            }
                        }
                    }
                    if ((bTest == true) && (sProductPrijsType != null))
                    {
                        AddToArray(ref marrdproductprijs, dProductPrijs);
                        AddToArray(ref marrsProductprijsType, sProductPrijsType.Replace('_', ' '));
                    }

                    //4. Sorteer Productpopulariteit
                    int iPopularity;
                    bool bTest2 = int.TryParse(arrsTemp[5], out iPopularity);
                    if ((bTest == true) && (bTest2 == true) && (sProductPrijsType != null)) AddToArray(ref marriPopularity, iPopularity);

                    //Succes Bepalen
                    if ((bTest == true) && (bTest2 == true) && (sProductPrijsType != null))
                    {
                        if ((marriPopularity.Length == marrdproductprijs.Length) && (marriProductnr.Length == marrdproductprijs.Length) && (marrsProductNaam.Length == marrsProductprijsType.Length))
                        {
                            bSucceeded = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("S101. An error occured whilst Sorting the data array. Please check the products.csv file for inconsistencies. Thanks." + System.Environment.NewLine + "Error details: " + ex.ToString(), "Error Occurred", MessageBoxButton.OK, MessageBoxImage.Error, MessageBoxResult.OK);
            }
            finally
            {
                if (bSucceeded == false)
                {
                    ClearProductArrays();
                    MessageBox.Show("S102. Error. The Sorting has failed." + System.Environment.NewLine + "Details: The arrays are not equal in length. Please check the saving syntax.", "error in sorting", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void InterpretChart(String[] arrsDataPool)
        {
            //Deze methode zal alle ingelezen karretjelijnen splitsen in de juiste subarrays.
            for (int i = 0; i < arrsDataPool.Length; i++)
            {
                String[] arrsLineData = arrsDataPool[i].Split(';');
                //De waarden initialiseren
                int iProductNr = 0; double dHoeveelheid = 0; bool bSliderVisibility = false;
                //De waarden Converteren
                bool bTest = int.TryParse(arrsLineData[0], out iProductNr);
                if (bTest == true) bTest = double.TryParse(arrsLineData[1], out dHoeveelheid);
                if (bTest == true) bTest = bool.TryParse(arrsLineData[2], out bSliderVisibility);
                if (bTest == true)
                {
                    //De waarden Wegschrijven
                    AddToArray(ref marriInChart, iProductNr);  //Het productnummer toevoegen aan het karretje
                    AddToArray(ref marrdHoeveelheid, dHoeveelheid);  //De hoeveelheid toevoegen aan het karretje
                    AddToArray(ref marrbSlider, bSliderVisibility);   //De sliderstatus toevoegen aan het karretje

                    //De waarden toewijzen
                    String sSelectedCategory = arrsLineData[3].Replace('_', ' ');
                    String sSelectedRbt = arrsLineData[4];
                    int iSelectedProductNr = -1;
                    bTest = int.TryParse(arrsLineData[5], out iSelectedProductNr);
                    String sSort = arrsLineData[6].Replace('_', ' ');
                    String sView = arrsLineData[7].Replace('_', ' ');

                    //De waarden verwerken
                    if (cboCategories.Items.Contains(sSelectedCategory)) cboCategories.SelectedItem = sSelectedCategory;
                    switch (sSelectedRbt)
                    {
                        case "rbtPopularity":
                            rbtPopularity.IsChecked = true;
                            break;
                        case "rbtPrice":
                            rbtPrice.IsChecked = true;
                            break;
                        case "rbtShop":
                            rbtShop.IsChecked = true;
                            break;
                        default:
                            rbtAlphaBet.IsChecked = true;
                            break;
                    }
                    int iPositie = Array.IndexOf(marriInProductList, iSelectedProductNr);
                    if (lstProducten.Items.Count >= iPositie) lstProducten.SelectedIndex = iPositie;
                    btnSort.Content = sSort;
                    btnView.Content = sView;
                }
            }
        }   //Karretjedata naar subarrays en venster klaarzetten.

        private void LoadCategories()
        {
            //Deze Methode scant naar alle categorieën en geeft ze weer in alle categoriecomboboxen.
            //Eerst Alle Comboboxen leegmaken voordat er naar geschreven wordt.
            ClearWindow(true, true);
            //Alle categoriën afgaan en enkel de nieuwe toevoegen.
            String[] arrsTempCatArray = new String[0];
            foreach (String sCategorie in marrsCategorie)
            {
                if (arrsTempCatArray.Contains(sCategorie) == false)
                {
                    AddToArray(ref arrsTempCatArray, sCategorie);
                }
            }
            //Alle nieuwe categoriën wegschrijven in de comboboxes.
            foreach (String sCat in arrsTempCatArray)
            {
                int iProductCount = CheckProductCount(sCat);    //indien er nog mogelijkheden zijn voor de gekozen categorie.
                if (iProductCount > 0)
                {
                    cboCategories.Items.Add(sCat);
                    cboCategory.Items.Add(sCat);
                }
            }
            EnableDisableControls();
        }

        private void GetTempFile()
        {
            //Deze methode bepaalt een uniek tijdelijk bestand voor het winkelkarretje.
            String sTempFile = System.IO.Path.GetTempFileName();
            if (sTempFile != null) msTempChartFile = sTempFile;
        }

        private void ClearProductArrays()
        {
            //Deze methode zal de arrays gebruikt voor basisdata leegmaken.
            Array.Resize(ref marrsProducten, 0);
            Array.Resize(ref marrsProductNaam, 0);
            Array.Resize(ref marrsProductprijsType, 0);
            Array.Resize(ref marrsShop, 0);
            Array.Resize(ref marrsCategorie, 0);
            Array.Resize(ref marriProductnr, 0);
            Array.Resize(ref marriPopularity, 0);
            Array.Resize(ref marrdproductprijs, 0);
        }

        private void ClearWindow(bool bComboBoxes = false, bool bProductList = false, bool bChart = false, bool bDetails = false, bool bQuickSearch = false)
        {
            if (bComboBoxes == true)
            {
                cboCategories.Items.Clear();
                cboCategory.Items.Clear();
            }
            if (bProductList == true)
            {
                lstProducten.Items.Clear();
            }
            if (bChart == true)
            {
                lstChart.Items.Clear();
            }
            if (bDetails == true)
            {
                txtName.Text = "";
                txtPrijs.Text = "";
                txtWinkel.Text = "";
            }
            if (bQuickSearch == true)
            {
                txtQuickSearch.Text = "Quick Search";
                txbSearchResult.Text = "";
            }
        }

        private int CheckProductCount(String sCategoryToCount)
        {
            //Deze methode zal bepalen hoeveel producten beschikbaar zijn voor een category na de aftrek van wat er in het winkelkarretje zit.
            int iProductCount = 0;
            for (int i = 0; i < marrsCategorie.Length; i++)
            {
                String sCategory = marrsCategorie[i];   //Indien het product dezelfde category heeft als gezocht
                if (sCategory == sCategoryToCount)
                {
                    int iProductnummer = marriProductnr[i]; //Indien het niet in het karretje zit, tel het bij.
                    if (marriInChart.Contains(iProductnummer) == false) iProductCount++;
                }
            }
            return iProductCount;
        }   //Tel het aantal producten beschikbaar in category.

        private void CloseWindow()
        {
            //Deze methode zal ervoor zorgen dat het tijdelijke karretjebestand verwijderd wordt bij het sluiten van de applicatie.
            GuaranteeFileExistance(msTempChartFile);
            File.Delete(msTempChartFile);
        }

        private void AddToArray(ref String[] arrs, string sToAdd)
        {
            //Deze methode zal de array met 1 plaats vergroten en de gevraagde String toevoegen.
            Array.Resize(ref arrs, arrs.Length + 1);
            arrs[arrs.GetUpperBound(0)] = sToAdd;
        }

        private void AddToArray(ref int[] arri, int iToAdd)
        {
            //Deze methode zal de array met 1 plaats vergroten en de gevraagde Integer toevoegen.
            Array.Resize(ref arri, arri.Length + 1);
            arri[arri.GetUpperBound(0)] = iToAdd;
        }

        private void AddToArray(ref double[] arrd, double dToAdd)
        {
            //Deze methode zal de array met 1 plaats vergroten en de gevraagde double toevoegen.
            Array.Resize(ref arrd, arrd.Length + 1);
            arrd[arrd.GetUpperBound(0)] = dToAdd;
        }

        private void AddToArray(ref bool[] arrb, bool bToAdd)
        {
            //Deze methode zal de array met 1 plaats vergroten en de gevraagde bool toevoegen.
            Array.Resize(ref arrb, arrb.Length + 1);
            arrb[arrb.GetUpperBound(0)] = bToAdd;
        }

        private void PassProducttoAdder()
        {
            //Deze methode vangt de request op van de listbox om een item aan het karretje toe te voegen
            //en geeft het door aan de addToChart methode.
            if ((lstProducten != null) && (lstProducten.SelectedIndex >= 0))
            {
                //Detecteren van het te verplaatsen product
                int iSelectedItem = lstProducten.SelectedIndex;
                if (iSelectedItem >= 0)
                {
                    //Ophalen en doorgeven van product.
                    int iProductNr = marriInProductList[iSelectedItem];
                    AddToChart(iProductNr);
                }
                //Na afloop de controls verversen
                if (cboCategories.SelectedIndex >= 0)
                {
                    int iControle = CheckProductCount(cboCategories.SelectedItem.ToString());
                    if (iControle <= 0) LoadProducts();
                }

            }
        } //Geef het geselecteerde product door aan de toevoeg-methode.

        private void GuaranteeFileExistance(String sFilePath, Int16 iTeller = 0)
        {
            //Deze methode garandeerd het bestaan van een bestand. Indien mislukt geeft dit een foutmelding weer.
            if (File.Exists(sFilePath) == false)
            {
                if (iTeller <= 3)
                {
                    File.Create(sFilePath).Close();
                    GuaranteeFileExistance(sFilePath, iTeller++);
                }
                else
                {
                    MessageBox.Show("ERROR" + System.Environment.NewLine + "Het programma is er na enkele pogingen nog steeds niet in geslaagd een bestand aan te maken op deze computer. Gelieve te controleren ofdat het uitvoerbestand zich in een map met schrijfrechten bevind. Indien dit probleem aanhoud, probeer dit te starten met administratorpermissie. (rechtsklik op de hyperlink en kies voor 'run as administrator' of 'voer uit als administrator')", "Error Encountered", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void FindProducts(ref int[] arriTemp, String sSelectedCategory)
        {
            for (int i = 0; i < marrsCategorie.Length; i++)
            {
                String sCategory = marrsCategorie[i];   //Indien het product dezelfde category heeft als gezocht
                if (sCategory == sSelectedCategory)
                {
                    int iProductnummer = marriProductnr[i]; //Indien het niet in het karretje zit, tel het bij.
                    if (marriInChart.Contains(iProductnummer) == false)
                    {
                        AddToArray(ref arriTemp, iProductnummer);
                    }
                }
            }
        }   //Haal de beschikbare producten v.d. categorie op

        private void SortProducts(ref int[] arriTemp)   //Sorteer de producten op basis van gevraagd criterium.
        {
            //Deze methode sorteerd de array van productnummers van lstproducten op basis van de sorteerselectie.
            //Vind het vereiste sorteercriterium
            String sSortOn = null;
            if (rbtAlphaBet.IsChecked == true) sSortOn = "Alfabet";
            if (rbtPopularity.IsChecked == true) sSortOn = "Populariteit";
            if (rbtPrice.IsChecked == true) sSortOn = "Prijs";
            if (rbtShop.IsChecked == true) sSortOn = "Winkel";
            //Laat de array gesorteerd worden op basis van het gevonden criterium.
            SortProducts(ref arriTemp, sSortOn);
        }

        private void SortProducts(ref int[] arriToSort, String sSortingMechanismn)  //SortingSlave
        {
            String[] arrsTemp = new String[0];
            //Het bepalen van de juiste sorteersyntax.
            foreach (int iProdnr in arriToSort)
            {
                //Elk te sorteren productnummer herschrijven met te sorteren gegeven in de tijdelijke array.
                int iProductPositie = Array.IndexOf(marriProductnr, iProdnr);
                switch (sSortingMechanismn)
                {
                    case "Populariteit":
                        AddToArray(ref arrsTemp, marriPopularity[iProductPositie] + ";" + iProdnr);
                        break;
                    case "Prijs":
                        AddToArray(ref arrsTemp, marrdproductprijs[iProductPositie] + ";" + iProdnr);
                        break;
                    case "Winkel":
                        AddToArray(ref arrsTemp, marrsShop[iProductPositie] + ";" + iProdnr);
                        break;
                    default:
                        AddToArray(ref arrsTemp, marrsProductNaam[iProductPositie] + ";" + iProdnr);
                        break;
                }
            }
            //Sorteren m.b.v. de naam en de gegeven array leegmaken voor herschrijven.
            Array.Sort(arrsTemp);
            Array.Resize(ref arriToSort, 0);
            //De te sorteren array herschrijven met gesorteerde waarden.
            foreach (String sProd in arrsTemp)
            {
                int iPositie = sProd.IndexOf(';');
                int iGesorteerdProductNummer = 0;

                bool bTest = int.TryParse(sProd.Substring(iPositie + 1, sProd.Length - iPositie - 1), out iGesorteerdProductNummer);
                AddToArray(ref arriToSort, iGesorteerdProductNummer);
            }
        }

        private void SortChart(ref int[] arriToSort, String sSortingMechanismn)
        {
            //Deze methode zal het karretjesarray sorteren op basis van het gevraagde zoekcriterium.
            //Benodigde variabelen aanmaken    
            String[] arrsTemp = new String[0];
            int[] arriold = arriToSort;
            double[] arrdTemp = marrdHoeveelheid;
            bool[] arrbSlider = marrbSlider;
            //Sorteermechanisme achterhalen
            foreach (int iProdNr in arriToSort)
            {
                int iProductPlaats = Array.IndexOf(marriProductnr, iProdNr);
                int iProductPlaatsInChart = Array.IndexOf(marriInChart, iProdNr);
                switch (sSortingMechanismn)
                {
                    case "Sort €":
                        AddToArray(ref arrsTemp, marrdproductprijs[iProductPlaats].ToString() + ";" + iProdNr);
                        break;
                    case "Sort ?":
                        AddToArray(ref arrsTemp, marrsShop[iProductPlaats] + ";" + iProdNr);
                        break;
                    case "Sort #":
                        AddToArray(ref arrsTemp, marrdHoeveelheid[iProductPlaatsInChart] + ";" + iProdNr);
                        break;
                    default:
                        AddToArray(ref arrsTemp, marrsProductNaam[iProductPlaats] + ";" + iProdNr);
                        break;
                }
            }
            //Sorteren
            //Sorteren m.b.v. de naam en de gegeven array leegmaken voor herschrijven.
            Array.Sort(arrsTemp);
            Array.Resize(ref arriToSort, 0);
            Array.Resize(ref marrdHoeveelheid, 0);
            Array.Resize(ref marrbSlider, 0);
            //De te sorteren array herschrijven met gesorteerde waarden.
            for (int i = 0; i < arrsTemp.Length; i++)
            {
                String sProd = arrsTemp[i];
                int iProductNr = 0;
                int iPositie = sProd.IndexOf(';') + 1;
                String sResult = sProd.Substring(iPositie, sProd.Length - iPositie);
                bool bTest = int.TryParse(sResult, out iProductNr);
                if (bTest == true) AddToArray(ref arriToSort, iProductNr);
                //Trek de veranderde waarden door naar de overige arrays
                int iOldArrayPosition = Array.IndexOf(arriold, iProductNr);
                AddToArray(ref marrdHoeveelheid, arrdTemp[iOldArrayPosition]);
                AddToArray(ref marrbSlider, arrbSlider[iOldArrayPosition]);
            }
        }   //Sorteer de producten op basis van gevraagd criterium

        private void ListProducts(int[] arriTemp)   //Schrijf de gevonden producten weg.
        {
            //Deze methode zal de gesorteerde producten vertalen naar de juiste syntax en ze weergeven in de lijst.
            foreach (int iProductnr in arriTemp)
            {
                int iProductPositie = Array.IndexOf(marriProductnr, iProductnr);
                String sLine = marrsProductNaam[iProductPositie];
                sLine += " - " + marrdproductprijs[iProductPositie].ToString("C") + " " + marrsProductprijsType[iProductPositie];
                sLine += " - " + marrsShop[iProductPositie];
                AddToArray(ref marriInProductList, iProductnr);
                lstProducten.Items.Add(sLine);
            }
        }

        private void CreateListItem(String sData, double dHoeveelheid, int iChartNr)
        {
            //Maak een grid voor het listitem.
            Grid grd = new Grid();
            ColumnDefinition col1 = new ColumnDefinition();
            ColumnDefinition col2 = new ColumnDefinition();
            grd.Height = lstChart.ActualHeight - 10;
            grd.Width = lstChart.ActualWidth - 10;
            grd.ColumnDefinitions.Add(col1);
            grd.ColumnDefinitions.Add(col2);
            lstChart.Items.Add(grd);

            //Maak de eerste stackpanel aan en vul hem met de meegekregen data.
            StackPanel spnl = new StackPanel();
            spnl.Orientation = Orientation.Horizontal;
            TextBlock tbl = new TextBlock();
            tbl.Text = sData;
            spnl.Children.Add(tbl);
            //Voeg hem toe aan de grid.
            Grid.SetColumn(spnl, 0);
            grd.Children.Add(spnl);

            //Maak de tweede stackpanel aan en vul hem met de benodigde gegevens.
            StackPanel spnl2 = new StackPanel();
            Grid.SetColumn(spnl2, 1);
            spnl2.Orientation = Orientation.Horizontal;
            grd.Children.Add(spnl2);

            //Voeg de elementen toe aan de stackpanel
            if (marrbSlider[iChartNr] == true)
            {
                Slider sld = new Slider();
                spnl2.Children.Add(sld);
                sld.Minimum = 0;
                sld.Maximum = 1000;
                sld.MinWidth = (lstChart.ActualWidth / 5);
                sld.Value = dHoeveelheid;
                ToolTip t = new ToolTip();
                t.Visibility = Visibility.Visible;
                sld.ToolTip = t;
                sld.HorizontalAlignment = HorizontalAlignment.Center;
                sld.VerticalAlignment = VerticalAlignment.Center;
                sld.ValueChanged += sld_ValueChanged;   //Opnemen wanneer men de waarde van de slider veranderd heeft
                sld.LostFocus += sld_LostFocus; //veranderingen doorvoeren wanneer men klaar is met de wijzigingen.
                sld.MouseLeftButtonUp += sld_MouseLeftButtonUp; //Veranderingen doorvoeren tijdens het wijzigen.
                sld.Tag = iChartNr;
            }
            else
            {
                Button btn = new Button();
                spnl2.Children.Add(btn);
                btn.MinHeight = 25;
                btn.MinWidth = 25;
                btn.SetResourceReference(Control.StyleProperty, "Button-Sketch");
                btn.Content = "-";
                btn.Click += btn_Click; //De click op de - button opvangen
                btn.Tag = iChartNr;
                if (dHoeveelheid <= 0) btn.IsEnabled = false;
            }

            TextBox txb = new TextBox();
            spnl2.Children.Add(txb);
            txb.TextWrapping = TextWrapping.Wrap;
            txb.HorizontalAlignment = HorizontalAlignment.Center;
            txb.VerticalAlignment = VerticalAlignment.Center;
            txb.MinHeight = 25;
            txb.MinWidth = 25;
            txb.SetResourceReference(Control.StyleProperty, "BasicTextBox-Sketch");
            txb.Text = dHoeveelheid.ToString();
            txb.TextChanged += txb_TextChanged; //Opnemen wanneer men de waarde van de textbox veranderd heeft.
            txb.LostFocus += txb_LostFocus; //Veranderingen doorvoeren wanneer men klaar is met wijzigingen
            txb.Tag = iChartNr;

            if (marrbSlider[iChartNr] == false)
            {
                Button btn2 = new Button();
                spnl2.Children.Add(btn2);
                btn2.MinHeight = 25;
                btn2.MinWidth = 25;
                btn2.SetResourceReference(Control.StyleProperty, "Button-Sketch");
                btn2.Content = "+";
                btn2.Click += btn2_Click; //De click op de + button opvangen
                btn2.Tag = iChartNr;
                if (dHoeveelheid >= 10000) btn2.IsEnabled = false;
            }

            Button btn3 = new Button();
            spnl2.Children.Add(btn3);
            btn3.MinHeight = 25;
            btn3.MinWidth = 25;
            btn3.SetResourceReference(Control.StyleProperty, "Button-Sketch");
            btn3.Content = "T";
            btn3.Click += btn3_Click; //De click op de T button opvangen
            btn3.Tag = iChartNr;

            Button btn4 = new Button();
            spnl2.Children.Add(btn4);
            btn4.MinHeight = 25;
            btn4.MinWidth = 25;
            btn4.SetResourceReference(Control.StyleProperty, "Button-Sketch");
            btn4.Content = "V";
            btn4.Click += btn4_Click; //De click op de V button opvangen
            btn4.Tag = iChartNr;

            //De Grid de juiste hoogte geven.
            grd.Height = txb.MinHeight;
        }

        private void WriteDetails()
        {
            //Deze methode zal de wijzigingen aangebracht in het detailvenster opslaan.
            if (mbDetailsChanged == true)
            {
                //Bepalen van geselecteerd product & bijhorend productnummer
                int iProductNummer = miTEMPdetails;
                int iGeselecteerdProduct = Array.IndexOf(marriProductnr, iProductNummer);

                //Aanpassen van gegevens in de arrays
                //Aanpassen van de strings
                marrsProductNaam[iGeselecteerdProduct] = txtName.Text;
                marrsCategorie[iGeselecteerdProduct] = (String)cboCategory.SelectedItem;
                marrsShop[iGeselecteerdProduct] = txtWinkel.Text;
                //Aanpassen van de prijs
                double dProductPrijs = -1; String sProductPrijsType = null; double dPrijs = 0; String sPrijsType = "";
                bool bConvert = true;
                for (int i = 0; i < txtPrijs.Text.Length; i++)
                {
                    if (bConvert == true)
                    {
                        String sTest = txtPrijs.Text.Substring(0, i + 1);
                        bConvert = double.TryParse(sTest, out dProductPrijs);
                    }
                    else
                    {
                        if (sProductPrijsType == null)
                        {
                            bool bConvert2 = double.TryParse(txtPrijs.Text.Substring(0, i - 1), out dProductPrijs);
                            sProductPrijsType = txtPrijs.Text.Substring(i - 1, txtPrijs.Text.Length - i + 1);
                        }
                    }
                }
                if (sProductPrijsType != null)
                {
                    dPrijs = dProductPrijs;
                    sPrijsType = sProductPrijsType.Replace('€', ' ');
                }
                marrdproductprijs[iGeselecteerdProduct] = dPrijs;
                marrsProductprijsType[iGeselecteerdProduct] = sPrijsType;

                //Wegschrijven van de aangepaste arrays
                ExportProductData();

                //Aanpassingen Finaliseren
                ClearWindow(false, false, false, true, false);
                mbDetailsChanged = false;
                txbSucceeded.Visibility = Visibility.Visible;

                //Data verversen
                ImportProductData();
                LoadProducts();
                LoadChart();
            }
        } // Sla de gemaakte wijzigingen in de details op.

        private void ScanProducts()
        {
            //Deze methode defineert het aanvullen op alfabet indien de gebruiker quicksearched.
            if ((txtQuickSearch.Text != "Quick Search") && (txtQuickSearch.Text != ""))
            {
                bool bFailed = true;
                String sSearchQuery = txtQuickSearch.Text.ToLower();
                for (int i = 0; i < marrsProductNaam.Length; i++)
                {
                    String sNaam = marrsProductNaam[i].ToLower();
                    if ((sNaam.StartsWith(sSearchQuery)) && (bFailed == true))
                    {
                        int iProductNummer = marriProductnr[i];
                        if (Array.IndexOf(marriInChart, iProductNummer) == -1)
                        {
                            txbSearchResult.Text = sNaam;
                            bFailed = false;
                            miQuickSearchSuggestion = marriProductnr[i];
                        }
                    }
                }
                if (bFailed == true)
                {
                    txbSearchResult.Text = "Geen resultaten";
                }
            }
        } // QuickSearch Scan

        private void RemoveFromChart(int iProdInChartPosition)
        {
            //Deze methode zal een item verwijderen uit de arrays van het winkelkarretje
            //De nieuwe karretjesarray declareren.
            int[] arriNewChart = new int[0];
            double[] arrdNewHoeveelheden = new double[0];
            bool[] arrbNewSlider = new bool[0];
            //Alles hertoevoegen behalve het te verwijdereren element
            for (int i = 0; i < marriInChart.Length; i++)
            {
                if (i != iProdInChartPosition)
                {
                    AddToArray(ref arriNewChart, marriInChart[i]);
                    AddToArray(ref arrdNewHoeveelheden, marrdHoeveelheid[i]);
                    AddToArray(ref arrbNewSlider, marrbSlider[i]);
                }
            }
            //De arrays opnieuw toewijzen
            marriInChart = arriNewChart;
            marrdHoeveelheid = arrdNewHoeveelheden;
            marrbSlider = arrbNewSlider;
            //Een vernieuwing van het karretje uitlokken
            LoadProducts();
            LoadChart();
        } //Deze methode zal een item uit het karretje verwijderen.

        private void AddScanResult()
        {
            //Deze methode zal het gevonden zoekresultaat toevoegen aan het winkelkarretje.
            if ((txbSearchResult.Text != "") || (txbSearchResult.Text != null) || (txtQuickSearch.Text != "Quick Search") || (txbSearchResult.Text != "Geen resultaten"))
            {
                //Data ophalen
                int iProductNr = miQuickSearchSuggestion;

                //Het gekozen product wegschrijven naar het karretje en een nieuw karretje ophalen.
                AddToChart(iProductNr);

                //Controls resetten
                miQuickSearchSuggestion = -1;
                txbSearchResult.Text = "";
                txtQuickSearch.Text = "Quick Search";
                lstChart.Focus();
                if ((lstProducten.Items.Count >= 0) && (cboCategories.SelectedIndex >= 0))
                    LoadProducts();     //Aangezien het toegevoegde product tussen de weergegeven lijst zou kunnen zitten, ververs de lijst indien nodig
            }
        }  //Quicksearch resultaat toevoegen aan karretje.

        private void PrintChart()
        {
            //Deze methode laat het karretje geprint worden.
            //Eerst, sla de huidige staat van het karretje nogmaals op.
            ExportChartData();
            ImportChartData();
            //Dan lees het tijdelijke winkelkarretje bestand in.
            String[] arrsToPrint = MakePrintArray();
            //Print de ingelezen array.
            PrintDialog printer = new PrintDialog();
            printer.PageRangeSelection = PageRangeSelection.AllPages;
            printer.UserPageRangeEnabled = true;
            if (printer.ShowDialog() == true)
            {
                FlowDocument toprint = new FlowDocument();
                foreach (String sLine in arrsToPrint)
                {
                    Paragraph linetoprint = new Paragraph();
                    linetoprint.Margin = new Thickness(0);
                    linetoprint.Inlines.Add(new Run(sLine));
                    toprint.Blocks.Add(linetoprint);
                }
                DocumentPaginator paginator = ((IDocumentPaginatorSource)toprint).DocumentPaginator;
                printer.PrintDocument(paginator, "My ShoppingChart:");
            }
        }   //Print het winkelkarretje uit.

        private String[] MakePrintArray()
        {
            //Deze methode maakt het printdocument op.
            //Maak de tijdelijke printvariabelen op.
            int[] arriTemp = new int[0];
            String[] arrsToPrint = new String[0];
            String sCurrentShop = "";
            arriTemp = marriInChart;
            SortChart(ref arriTemp, "Sort ?");
            //Schrijf de printarray - Schrijf per winkel elk product weg.
            AddToArray(ref arrsToPrint, "WINKELKARRETJE SHOPPINGAPP. Geprint op " + System.DateTime.Today.ToShortDateString() + ": ");
            for (int i = 0; i <= arriTemp.GetUpperBound(0); i++)
            {
                //Veelgebruike variabelen bepalen
                int iProductnummer = arriTemp[i];
                int iProductPlaats = Array.IndexOf(marriProductnr, iProductnummer);
                int iProductPlaatsInKarretje = Array.IndexOf(marriInChart, iProductnummer);

                //Hier overlopen we elk te printen productnummer.
                //Sorteer alle producten volgens winkel.
                if (btnView.Content.ToString().Contains("?"))
                {
                    if (sCurrentShop != marrsShop[iProductPlaats])
                    {
                        sCurrentShop = marrsShop[iProductPlaats];
                        AddToArray(ref arrsToPrint, " ");
                        AddToArray(ref arrsToPrint, " ");
                        AddToArray(ref arrsToPrint, sCurrentShop + ": ");
                        AddToArray(ref arrsToPrint, " ");
                    }
                }
                string sLine = "";
                sLine += (i + 1).ToString() + ".   ";
                sLine += marrdHoeveelheid[iProductPlaatsInKarretje] + " ";
                sLine += marrsProductNaam[iProductPlaats];
                if (btnView.Content.ToString().Contains("€")) sLine += " - " + marrdproductprijs[iProductPlaats].ToString("C") + marrsProductprijsType[iProductPlaats];
                AddToArray(ref arrsToPrint, sLine);
            }
            //Nadat alle prodcuten weggeschreven zijn, bereken het subtotaal voor alle producten (indien gevraagd)
            AddToArray(ref arrsToPrint, " ");
            if (btnView.Content.ToString().Contains("€"))
            {
                String sLine = "";
                double dTotaalPrijs = 0;
                for (int i = 0; i <= arriTemp.GetUpperBound(0); i++)
                {
                    if (arriTemp[i] >= 0)
                    {
                        //Veelgebruike variabelen bepalen
                        int iProductnummer = arriTemp[i];
                        int iProductPlaats = Array.IndexOf(marriProductnr, iProductnummer);

                        //Totaalprijs berekenen
                        dTotaalPrijs = dTotaalPrijs + (marrdHoeveelheid[Array.IndexOf(marriInChart, iProductnummer)] * marrdproductprijs[iProductPlaats]);
                    }
                }
                sLine = "Geschatte totaal van alle producten in het winkelmandje: " + dTotaalPrijs + "euro.";
                AddToArray(ref arrsToPrint, sLine);
                AddToArray(ref arrsToPrint, " ");
            }
            return arrsToPrint;
        }   //PrintSlaveMethod

        private void SaveChart()
        {
            //Deze methode schrijft het gemaakte winkelkarretje weg.
            //Om bevestiging vragen
            MessageBoxResult mbr = new MessageBoxResult();
            mbr = MessageBox.Show("Weet u zeker dat u deze winkelkar wilt opslaan. Controleer de naamgeving van het karretje, want bestanden met dezelfde benaming zullen worden overschreven door deze nieuwe lijst. Wilt u doorgaan?", "Bevestiging gevraagd", MessageBoxButton.OKCancel, MessageBoxImage.Question, MessageBoxResult.Cancel);
            if (mbr == MessageBoxResult.OK)
            {
                //Het opslagbestand Maken
                String sFilename = msDataFolder + "/" + txtChartName.Text + ".txt";
                GuaranteeFileExistance(sFilename);  //Zorgen dat het bestand bestaat vooraleer het verwijderd wordt om schrijffouten te voorkomen.
                File.Delete(sFilename); //het bestand verwijdereren want het mag niet bestaan tijdens het copiëren.
                ExportChartData();  //Het tijdelijk bestand vernieuwen
                File.Copy(msTempChartFile, sFilename);  //Een export maken.
            }
            EnableDisableControls();
        }   // Sla het huidige karretje op en een bestand. (bevestiging vereist)

        private void ImportChart(bool bChosen = false)
        {
            //deze methode zal een eerder ontworpen winkellijstje laden op basis van een selectie van de gebruiker.
            OpenFileDialog ofd = new OpenFileDialog();
            ofd.Filter = "Textfiles (*.txt)|*.txt";
            ofd.InitialDirectory = AppDomain.CurrentDomain.BaseDirectory + "AppData";
            if (bChosen == true) ofd.FileName = msLoadedFile;
            else ofd.ShowDialog();
            if (ofd.FileName != "")
            {
                //Haal gegevens op.
                String sSourcename = ofd.FileName;
                String sDestname = msTempChartFile;
                //Verzeker bestaan
                GuaranteeFileExistance(sSourcename);
                GuaranteeFileExistance(sDestname);
                //Verwijder doelbestand en copieer bron
                File.Delete(sDestname);
                File.Copy(sSourcename, sDestname);
                //Laad gegevens in
                ImportChartData();
                EnableDisableControls();
            }
        } // laad een eerder gemaakt karretje in.

        private void GoToMenu()
        {
            //Deze methode zorgt ervoor dat de gebruiker terug kan gaan naar het hoofdmenu.
            //Er wordt bevestiging vereist.
            MessageBoxResult mbr = new MessageBoxResult();
            mbr = MessageBox.Show("Bent u zeker? Alle niet opgeslagen data gaat verloren als u dit venster verlaat.", "Bevestiging vereist", MessageBoxButton.OKCancel, MessageBoxImage.Question, MessageBoxResult.Cancel);
            if (mbr.Equals(MessageBoxResult.OK))
            {
                //Voor het weggaan, eerst de waarden heropslaan (herstelpunt)
                ExportChartData();
                //Indien de gebruker heeft goedgekeurd, doorgaan naar het hoofdmenu.
                HomeWindow hwin = new HomeWindow();
                hwin.Show();
                this.Close();
            }
        } //Keer terug naar het hoofdmenu (bevestiging vereist)

        private void TriggerButton(Button btn)
        {
            //Deze methode zorgt ervoor dat het karretje de visuele sorteermogelijkheden doorkrijgt.
            //Pas de lay-out (en daarmee het sorteermechanismetrigger) van de button aan.
            if (btn.Name == "btnView")  //Voor de Viewknop
            {
                switch (btn.Content.ToString())
                {
                    case "View €-?":
                        btn.Content = "View";
                        break;
                    case "View €":
                        btn.Content = "View ?";
                        break;
                    case "View":
                        btn.Content = "View €";
                        break;
                    default:    //Alphabet is standaard
                        btn.Content = "View €-?";
                        break;
                }
            }
            else if (btn.Name == "btnSort") //Voor de sorteerknop
            {
                switch (btn.Content.ToString())
                {
                    case "Sort A-Z":
                        btn.Content = "Sort €";
                        break;
                    case "Sort €":
                        btn.Content = "Sort ?";
                        break;
                    case "Sort ?":
                        btn.Content = "Sort #";
                        break;
                    default:    //Alphabet is standaard
                        btn.Content = "Sort A-Z";
                        break;
                }
            }
            //Na de visuele veranderingen, trigger de wissel in het scherm door het karretje te herladen.
            LoadChart();
        }

        private void AlteredDetails()
        {
            if (mbEditingDetails == false)
            {
                mbDetailsChanged = true;
                mbDroppedDown = false;
                txbSucceeded.Visibility = Visibility.Hidden;
            }
        }

        private void InitTimer()
        {
            tmr.Interval = TimeSpan.FromMilliseconds(500);
            tmr.Tick += tmr_Tick;
        }

        void tmr_Tick(object sender, EventArgs e)
        {
            ShowSliderChanges();
            tmr.Stop();
        }

        private void ShowSliderChanges()
        {
            //Deze methode zal de gemaakte wijzigingen via de slider doorvoeren.
            if ((mbSliderMovedByHuman == true) && (oSliderSender != null))
            {
                //Reset de gebruikte variabelen
                mbSliderMovedByHuman = false;
                //Achterhaal wie de request verzonden heeft
                Slider sld = (Slider)oSliderSender;
                int iGeselecteerdProductInChart = Convert.ToInt16(sld.Tag);
                //Verzet de gekozen sliderwaarde naar de hoeveelheidsarray
                double dSlidedWaarde = sld.Value;
                dSlidedWaarde = Math.Round(dSlidedWaarde, 0);
                marrdHoeveelheid[iGeselecteerdProductInChart] = dSlidedWaarde;
                //Vernieuw het karretje
                LoadChart();    //Push de nieuwe sliderwaarden naar het karretje.
                oSliderSender = null;
            }
        }

        void txb_LostFocus(object sender, RoutedEventArgs e)
        {
            //Veranderingen doorvoeren wanneer men klaar is met wijzigingen
            //Achterhaal wie de request verzonden heeft.
            TextBox txb = (TextBox)sender;
            int iSelectedProductFormChart = Convert.ToInt16(txb.Tag);
            //Sla de hoeveelheid op in de array
            if (iSelectedProductFormChart >= -1)
            {
                double dHoeveelheid;
                bool bTest = double.TryParse(txb.Text, out dHoeveelheid);
                marrdHoeveelheid[iSelectedProductFormChart] = dHoeveelheid;
            }
        }   //Gemaakte wijzigingen naar arrayss sturen indien de gebruiker wegklikt van de textbox.

        void txb_TextChanged(object sender, TextChangedEventArgs e)
        {
            //Opnemen wanneer men de waarde van de textbox veranderd heeft.
            //Achterhalen wie de request gestuurd heeft.
            TextBox txb = (TextBox)sender;
            //Controleren ofdat er een geldige waarde doorgegeven is
            double dTest;
            bool bTest = double.TryParse(txb.Text, out dTest);
            //De gebruiker informeren over de correctheid van de huidige waarde.
            if (bTest == true)
            {
                //Indien de gebruiker juiste waarden ingeeft
                SolidColorBrush brush = new SolidColorBrush();
                brush.Color = Color.FromRgb(96, 96, 96);
                txb.BorderBrush = brush;
            }
            else
            {
                //Indien de gebruiker foute waarden doorgeeft.
                txb.BorderBrush = Brushes.Red;
                Keyboard.Focus(txb);    //Indien er foute waarden zijn, stuur het toetsenbord naar de textbox om de waarden aan te passen.
            }
        }

        void btn4_Click(object sender, RoutedEventArgs e)
        {
            //Deze methode defineert wat er gebeurd als je op de "V" knop drukt in een listboxitem.
            //Achterhalen wie de request gestuurd heeft.
            Button btn = (Button)sender;
            int iSelectedProductFromChart = Convert.ToInt16(btn.Tag);
            //Het huidig geselecteerde product opzoeken en verwijderen.
            RemoveFromChart(iSelectedProductFromChart);
        }

        void btn3_Click(object sender, RoutedEventArgs e)
        {
            //Deze methode defineert wat er gebeurd als je op de "T" knop drukt in een listboxitem.
            //Achterhalen wie de request verstuurd heeft.
            Button btn = (Button)sender;
            int iSelectedProductFromChart = Convert.ToInt16(btn.Tag);
            //De slider verzetten.
            if (marrbSlider[iSelectedProductFromChart] == false) marrbSlider[iSelectedProductFromChart] = true;
            else marrbSlider[iSelectedProductFromChart] = false;
            //Het karretje vernieuwen
            LoadChart();    //De verandering in sliderwaarden doorpushen naar het karretje.
        }

        void btn2_Click(object sender, RoutedEventArgs e)
        {
            //Deze methode defineert wat er gebeurd als je op de "+" knop drukt in een listboxitem.
            //Achterhalen wie de request gestuurd heeft
            Button btn = (Button)sender;
            int iSelectedProductFromChart = Convert.ToInt16(btn.Tag);
            //De hoeveelheidwaarde wijzigen
            if (iSelectedProductFromChart >= -1)
            {
                double dHoeveelheid = marrdHoeveelheid[iSelectedProductFromChart];
                dHoeveelheid = dHoeveelheid + 1;
                //De beschikbaarheid van het product controleren
                if (dHoeveelheid >= 10000)
                {
                    btn.IsEnabled = false;
                }
                else
                {
                    btn.IsEnabled = true;
                }
                marrdHoeveelheid[iSelectedProductFromChart] = dHoeveelheid;
            }
            //De nieuwe waarde doorsturen naar het karretje
            LoadChart();
        }

        void btn_Click(object sender, RoutedEventArgs e)
        {
            //Deze methode defineert wat er gebeurd als je op de "-" knop drukt in een listboxitem.
            //Achterhalen wie de Request gestuurd heeft.
            Button btn = (Button)sender;
            int iSelectedProductFromChart = Convert.ToInt16(btn.Tag);
            //De hoeveelheidswaarde wijzigen
            if (iSelectedProductFromChart >= -1)
            {
                double dHoeveelheid = marrdHoeveelheid[iSelectedProductFromChart];
                dHoeveelheid = dHoeveelheid - 1;
                //De beschikbaarheid controleren
                if (dHoeveelheid <= 0)
                {
                    btn.IsEnabled = false;
                }
                else
                {
                    btn.IsEnabled = true;
                }
                marrdHoeveelheid[iSelectedProductFromChart] = dHoeveelheid;
            }
            //De nieuwe waarde doorsturen naar het karretje
            LoadChart();
        }

        void sld_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            //Opnemen wanneer men de waarde van de slider veranderd heeft
            //Achterhalen wie de request gestuurd heeft.
            Slider sld = (Slider)sender;
            //Computerwaarden wegfilteren
            if ((sld != null) && (sld.Value != 0))
            {
                //De waarde controleren op geldigheid
                double dSlidedWaarde = sld.Value;
                if ((dSlidedWaarde >= 0) && (dSlidedWaarde <= 10000))
                {
                    mbSliderMovedByHuman = true;
                    oSliderSender = sender;
                    tmr.Start();
                }
            }
            else
            {
                mbSliderMovedByHuman = false;
            }
        }

        void sld_LostFocus(object sender, RoutedEventArgs e)
        {
            ShowSliderChanges();
        }

        void sld_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            ShowSliderChanges();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadWindow();
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            CloseWindow();
        }

        private void txbShopping_MouseButtonUp(object sender, MouseButtonEventArgs e)
        {
            GoToMenu();
        }

        private void cboCategories_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            LoadProducts();
        }

        private void lstProducten_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (lstProducten.Items.Count > 0) WriteDetails();
            if (lstProducten.SelectedIndex >= 0) LoadDetails(true);
            lstChart.SelectedIndex = -1;
            EnableDisableControls();
        }

        private void txtQuickSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (txbSearchResult != null) ScanProducts();
            EnableDisableControls();
        }

        private void btnPrintChart_Click(object sender, RoutedEventArgs e)
        {
            PrintChart();
        }

        private void btnView_Click(object sender, RoutedEventArgs e)
        {
            TriggerButton((Button)sender);
        }

        private void btnSort_Click(object sender, RoutedEventArgs e)
        {
            TriggerButton((Button)sender);
        }

        private void btnLoad_Click(object sender, RoutedEventArgs e)
        {
            ImportChart();
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            SaveChart();
        }

        private void txtName_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (txtName.IsFocused == true) AlteredDetails();
        }

        private void txtPrijs_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (txtPrijs.IsFocused == true) AlteredDetails();
            EnableDisableControls();
        }

        private void cboCategory_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (mbDroppedDown == true) AlteredDetails();
        }

        private void txtWinkel_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (txtPrijs.IsFocused == true) AlteredDetails();
        }

        private void lstChart_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {
            if (lstChart.Items.Count > 0) WriteDetails();
            if (lstChart.SelectedIndex >= 0) LoadDetails(false);
            lstProducten.SelectedIndex = -1;
        }

        private void Quicksearch_DoubleClick(object sender, MouseButtonEventArgs e)
        {
            AddScanResult();
        }

        private void SearchSuggestion_Clicked(object sender, MouseButtonEventArgs e)
        {
            AddScanResult();
        }

        private void DropDownOpened(object sender, EventArgs e)
        {
            mbDroppedDown = true;
        }

        private void QuickSearch_GotFocus(object sender, RoutedEventArgs e)
        {
            txtQuickSearch.Text = "";
            txbSearchResult.Text = "";
        }

        private void rbtPrice_Checked(object sender, RoutedEventArgs e)
        {
            if (cboCategories != null) LoadProducts();
        }

        private void rbtAlphaBet_Checked(object sender, RoutedEventArgs e)
        {
            if (cboCategories != null) LoadProducts();
        }

        private void rbtShop_Checked(object sender, RoutedEventArgs e)
        {
            if (cboCategories != null) LoadProducts();
        }

        private void rbtPopularity_Checked(object sender, RoutedEventArgs e)
        {
            if (cboCategories != null) LoadProducts();
        }

        private void Producten_DoubleClicked(object sender, MouseButtonEventArgs e)
        {
            PassProducttoAdder();
        }

        private void QuickSearch_LostFocus(object sender, RoutedEventArgs e)
        {
            EnableDisableControls();
        }

        private void EnableDisableControls()
        {
            //Deze methode bepaald welke elementen er actief mogen zijn op welke momenten.
            //Deze is opgebouwd per element
            //LstProducten
            if (lstProducten != null)
            {
                if ((lstProducten.Items.Count > 0) && (cboCategories.SelectedIndex >= 0))
                {
                    lstProducten.IsEnabled = true;
                }
                else
                {
                    lstProducten.IsEnabled = false;
                }
            }
            //txtQuickSearch
            if ((txtQuickSearch != null) && (txbSearchResult != null))
            {
                if (txtQuickSearch.Text == "Quick Search") txbSearchResult.Text = "";
                if (txtQuickSearch.IsFocused == false) txtQuickSearch.Text = "Quick Search";
            }
            //btnPrint && btnView && btnSort
            if ((btnPrintChart != null) && (btnView != null) && (btnSort != null))
            {
                if (lstChart.Items.Count <= 0)
                {
                    btnPrintChart.IsEnabled = false;
                    btnView.IsEnabled = false;
                    btnSort.IsEnabled = false;
                }
                else
                {
                    btnPrintChart.IsEnabled = true;
                    btnView.IsEnabled = true;
                    btnSort.IsEnabled = true;
                }
            }
            //btnLoad
            btnLoad.IsEnabled = false;
            String[] arrsFiles = Directory.GetFiles(msDataFolder);
            foreach (String sFile in arrsFiles)
            {
                if (sFile.EndsWith(".txt"))
                {
                    btnLoad.IsEnabled = true;
                }
            }
            //btnSave & lstchart
            if (btnSave != null)
            {
                if ((txtChartName.Text != "") && (lstChart.Items.Count > 0))
                {
                    btnSave.IsEnabled = true;
                    lstChart.IsEnabled = true;
                }
                else
                {
                    btnSave.IsEnabled = false;
                    lstChart.IsEnabled = false;
                }
            }
            //Details
            if (txbProductDetails != null)
            {
                if ((lstChart.SelectedIndex >= 0) || (lstProducten.SelectedIndex >= 0))
                {
                    txtName.IsEnabled = true;
                    txtPrijs.IsEnabled = true;
                    txtWinkel.IsEnabled = true;
                    cboCategory.IsEnabled = true;
                }
                else
                {
                    txtName.IsEnabled = false;
                    txtPrijs.IsEnabled = false;
                    txtWinkel.IsEnabled = false;
                    cboCategory.IsEnabled = false;
                }
            }
            //Inputcontrole details
            if (txtPrijs != null)
            {
                int iTest;
                bool bTest = int.TryParse(txtPrijs.Text, out iTest);
                if (bTest == false) txtPrijs.BorderBrush = Brushes.Red;
                else
                {
                    SolidColorBrush brush = new SolidColorBrush();
                    brush.Color = Color.FromRgb(96, 96, 96);
                    txtPrijs.BorderBrush = brush;
                }
            }
            //txtChartName
            if (txtChartName != null)
            {
                if ((txtChartName.Text.Contains('/')) || (txtChartName.Text.Contains('*')) || (txtChartName.Text.Contains('?')) || (txtChartName.Text.Contains('^'))
                || (txtChartName.Text.Contains('¨')) || (txtChartName.Text.Contains(',')) || (txtChartName.Text.Contains('.'))
                || (txtChartName.Text.Contains('+')) || (txtChartName.Text.Contains('=')) || (txtChartName.Text.Contains('€')))
                {
                    txtChartName.BorderBrush = Brushes.Red;
                    lstProducten.IsEnabled = false;
                    lstChart.IsEnabled = false;
                    btnPrintChart.IsEnabled = false;
                    btnSave.IsEnabled = false;
                }
                else
                {
                    SolidColorBrush brush = new SolidColorBrush();
                    brush.Color = Color.FromRgb(96, 96, 96);
                    txtChartName.BorderBrush = brush;
                }
            }
            //Details selecteren/onselecteren
            if ((lstProducten.SelectedIndex == -1) && (lstChart.SelectedIndex == -1))
            {
                ClearWindow(false, false, false, true, false);
            }

            if (mbEditingDetails == true)
            {
                cboCategories.IsEnabled = false;
                txbShoppingApp.IsEnabled = false;
            }
            else
            {
                cboCategories.IsEnabled = true;
                txbShoppingApp.IsEnabled = true;
            }
        }

    }
}
