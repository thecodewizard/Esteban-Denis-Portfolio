﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ShoppingApp
{
    /// <summary>
    /// Interaction logic for EditWindow.xaml
    /// </summary>
    public partial class EditWindow : Window
    {
        /* Editwindow heeft de volgende hoofdmethodes:
         * LoadWindow
         * ImportProductData
         * ExportProductData
         * LoadProducts
         * LoadDetails
         * InitialiseWindowElements
         * InterpretData
         * LoadCategories
         * ClearProductArrays
         * ClearWindow
         * CheckProductCount
         * CloseWindow
         * AddToArray
         * GuaranteeFileExistance
         * FindProducts
         * SortProducts
         * ListProducts
         * GoToMenu
         * EnableDisableControls   */

        /* Opslag gebeurd door bestanden in de root van de applicatie.:
         * Lijsten: | TXT-bestand | bestand per lijst: lijstnaam.txt | productnr;productaantal;bslider;selectedcategorie;categorysorted;selectedproduct;productsorted;productview;
         * Producten: | CSV-bestand | 1 bestand: producten.csv | productnr;productnaam;productprijs;categorie;shop;aantalgeselecteerd;
         */


        public EditWindow()
        {
            InitializeComponent();
        }

        //Declareren op moduleniveau
        //Arrays
        private String[] marrsProducten = new String[0];
        private int[] marriProductnr = new int[0];
        private String[] marrsProductNaam = new String[0];
        private double[] marrdproductprijs = new double[0];
        private String[] marrsProductprijsType = new String[0];
        private String[] marrsCategorie = new String[0];
        private String[] marrsTempCat = new String[0];
        private String[] marrsShop = new String[0];
        private int[] marriPopularity = new int[0];
        private int[] marriInProductList = new int[0];
        //Variabelen
        private String msProducten = AppDomain.CurrentDomain.BaseDirectory + "/AppData/Producten.csv";
        private int miTEMPdetails = 0;
        private bool mbCatAdd = false;
        private bool mbCatDel = false;
        private bool mbCatEdit = false;
        private bool mbDetAdd = false;
        private bool mbDatDel = false;
        private bool mbDatEdit = false;
        private bool mbCatEditing = false;
        //Objecten
        private Random moRandomGenerator = new Random();

        private void LoadWindow()
        {
            //Deze methode zal bij het starten de window klaarzetten voor gebruik.
            EnableDisableControls();    //Window Klaarzetten
            ImportProductData();    //Haal alle begindata uit de arrays
        }   //H. Laden van Window

        private void ImportProductData()
        {
            //Deze methode zal de data uit product.csv inladen in de juiste arrays.
            ClearProductArrays();   //Verwijder te schrijven arrays.
            ImportFile(ref marrsProducten, msProducten);    //Importeer alle producten in de productarray.
            InterpretData(marrsProducten); //Sorteer de gegevens naar de juiste subarrays.
            LoadCategories(); //Toon de juiste categoriën in de combobox.
        }   //H. Productarrays Vullen.

        private void ExportProductData()
        {
            //Deze methode zal de productenarray herschrijven
            //Het te schrijven bestand leegmaken.
            GuaranteeFileExistance(msProducten);    //Zeker van zijn dat het bestaat alvorens te verwijderen om crashfouten tegen te gaan.
            File.Delete(msProducten);   //Het bestand verwijderen
            File.Create(msProducten).Close();   //Het bestand opnieuw aanmaken.
            using (StreamWriter initialiser = new StreamWriter(msProducten, false))
            {
                String sInit = "PRODUCTDATA SHOPPINGAPP V2.0, WRITTEN ON " + System.DateTime.Today.ToShortDateString() + ": ";
                initialiser.WriteLine(sInit);
            }
            //Per product de volledige lijn aanmaken en wegschrijven naar een tijdelijke array.
            for (int i = 0; i < marriProductnr.Length; i++)
            {
                String sLine = marriProductnr[i].ToString();
                sLine += ";" + marrsProductNaam[i].Replace(' ', '_');
                sLine += ";" + marrdproductprijs[i] + marrsProductprijsType[i].Replace(' ', '_').Replace('€', '&');
                sLine += ";" + marrsCategorie[i].Replace(' ', '_');
                sLine += ";" + marrsShop[i].Replace(' ', '_');
                sLine += ";" + marriPopularity[i].ToString() + ";";
                //De gegenereerde lijn wegschrijven naar het productenbestand
                using (StreamWriter writer = new StreamWriter(msProducten, true))
                {
                    writer.WriteLine(sLine);
                }
            }
        } //H. Exporteer de productenarrays.

        private void LoadProducts()    //H. Vul de productenlijst.
        {
            //Deze methode zal bij een keuze van de categorie de juiste producten in de productenlijst plaatsen.
            //eerst de lijsten leegmaken alvorens ze te vullen.
            ClearWindow(false, true);
            Array.Resize(ref marriInProductList, 0);

            int[] arriTemp = new int[0]; //De categorieën en de bijhorende producten in een tijdelijke array laden.
            if (cboCategories.SelectedIndex >= 0)  //Deze waarde kan negatief worden tijdens het verversen van de lijst.
            {
                String sSelectedCategory = cboCategories.SelectedItem.ToString();

                //De producten behorend tot de categorie ophalen.
                FindProducts(ref arriTemp, sSelectedCategory);     //Vind alle producten in de categorie.
                SortProducts(ref arriTemp); //Sorteer alle producten zoals gevraagd mbv. Radiobuttons
                ListProducts(arriTemp);     //Vul de listbox met de gesorteerde producten.
            }
            EnableDisableControls();
        }

        private void LoadDetails()
        {
            //Deze methode zal de details van een geselecteerd item opvragen.
            //Initieer de benodigde variabelen
            int iSelectedIndex = -1; int iProductNr = -1;
            //Verwijder de details alvorens ze te vullen.
            ClearWindow(false, false, true);
            //Data ophalen van de sender.
            iSelectedIndex = lstProducten.SelectedIndex;
            if (iSelectedIndex >= 0) iProductNr = marriInProductList[iSelectedIndex];
            if (iProductNr != -1)
            {
                //Data invullen in de details
                int iPositie = Array.IndexOf(marriProductnr, iProductNr);
                txtDetName.Text = marrsProductNaam[iPositie];
                txtDetPrice.Text = marrdproductprijs[iPositie] + marrsProductprijsType[iPositie];
                txtDetShop.Text = marrsShop[iPositie];
                cboDetCat.SelectedItem = marrsCategorie[iPositie];
                miTEMPdetails = iProductNr;
            }
        } //H. Laad de details van een geselecteerd product.

        private void ImportFile(ref String[] arrsResultaat, String sFilePath)   //De eerste lijn is altijd commentaar
        {
            //Deze methode haalt de gegevens op uit de gevraagde file en geeft ze door aan de opgegeven array.
            Array.Resize(ref arrsResultaat, 0); //De resultaatarray leegmaken.

            using (StreamReader reader = new StreamReader(sFilePath))
            {
                String sLine = reader.ReadLine();   //Lees de eerste lijn, en lees onmiddellijk tweede lijn.
                sLine = reader.ReadLine();

                while (sLine != null)
                {
                    sLine = sLine.Replace('&', ' ');
                    //Lees data en vul aan in array.
                    AddToArray(ref arrsResultaat, sLine);

                    //initeer volgende loop
                    sLine = reader.ReadLine();
                }
            }
        }

        private void InterpretData(String[] arrsDataPool)   // Productarray verdelen in subarrays.
        {
            //Deze methode zal de data uit de opgegeven array wegschrijven naar de juiste subarrays.
            //Subarrays zijn: marriproductnummer, marrsproductnaam, marrfproductprijs, marrsproductprijstype, marrscategorie, marrfquot 
            bool bSucceeded = false;
            try
            {
                foreach (String sData in arrsDataPool)
                {
                    String[] arrsTemp = sData.Split(';');

                    //1. Sorteer het productnummer.
                    int iProductnummer;
                    bool bTest = int.TryParse(arrsTemp[0], out iProductnummer);
                    if (bTest == true) AddToArray(ref marriProductnr, iProductnummer);

                    //2. Sorteer productnaam & marrscategorie & shop
                    if (bTest == true) AddToArray(ref marrsProductNaam, arrsTemp[1].Replace('_', ' '));
                    if (bTest == true) AddToArray(ref marrsCategorie, arrsTemp[3].Replace('_', ' '));
                    if (bTest == true) AddToArray(ref marrsShop, arrsTemp[4].Replace('_', ' '));

                    //3. Sorteer Productprijs & productprijstype
                    double dProductPrijs = -1; String sProductPrijsType = null;
                    bool bConvert = true;
                    for (int i = 0; i < arrsTemp[2].Length; i++)
                    {
                        if (bConvert == true)
                        {
                            String sTest = arrsTemp[2].Substring(0, i + 1);
                            bConvert = double.TryParse(sTest, out dProductPrijs);
                        }
                        else
                        {
                            if (sProductPrijsType == null)
                            {
                                bool bConvert2 = double.TryParse(arrsTemp[2].Substring(0, i - 1), out dProductPrijs);
                                sProductPrijsType = arrsTemp[2].Substring(i - 1, arrsTemp[2].Length - i + 1);
                            }
                        }
                    }
                    if ((bTest == true) && (sProductPrijsType != null))
                    {
                        AddToArray(ref marrdproductprijs, dProductPrijs);
                        AddToArray(ref marrsProductprijsType, sProductPrijsType.Replace('_', ' '));
                    }

                    //4. Sorteer Productpopulariteit
                    int iPopularity;
                    bool bTest2 = int.TryParse(arrsTemp[5], out iPopularity);
                    if ((bTest == true) && (bTest2 == true) && (sProductPrijsType != null)) AddToArray(ref marriPopularity, iPopularity);

                    //Succes Bepalen
                    if ((bTest == true) && (bTest2 == true) && (sProductPrijsType != null))
                    {
                        if ((marriPopularity.Length == marrdproductprijs.Length) && (marriProductnr.Length == marrdproductprijs.Length) && (marrsProductNaam.Length == marrsProductprijsType.Length))
                        {
                            bSucceeded = true;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("S101. An error occured whilst Sorting the data array. Please check the products.csv file for inconsistencies. Thanks." + System.Environment.NewLine + "Error details: " + ex.ToString(), "Error Occurred", MessageBoxButton.OK, MessageBoxImage.Error, MessageBoxResult.OK);
            }
            finally
            {
                if (bSucceeded == false)
                {
                    ClearProductArrays();
                    MessageBox.Show("S102. Error. The Sorting has failed." + System.Environment.NewLine + "Details: The arrays are not equal in length. Please check the saving syntax.", "error in sorting", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void LoadCategories()
        {
            //Deze Methode scant naar alle categorieën en geeft ze weer in alle categoriecomboboxen.
            //Eerst Alle Comboboxen leegmaken voordat er naar geschreven wordt.
            ClearWindow(true, true);
            //Alle categoriën afgaan en enkel de nieuwe toevoegen.
            String[] arrsTempCatArray = new String[0];
            foreach (String sCategorie in marrsCategorie)
            {
                if (arrsTempCatArray.Contains(sCategorie) == false)
                {
                    AddToArray(ref arrsTempCatArray, sCategorie);
                }
            }
            //Alle nieuwe categoriën wegschrijven in de comboboxes.
            mbCatEditing = true;
            foreach (String sCat in arrsTempCatArray)
            {
                cboCategories.Items.Add(sCat);
                cboDetCat.Items.Add(sCat);
            }
            AddTempCat();
            mbCatEditing = false;
            EnableDisableControls();
        }

        private void ClearProductArrays()
        {
            //Deze methode zal de arrays gebruikt voor basisdata leegmaken.
            Array.Resize(ref marrsProducten, 0);
            Array.Resize(ref marrsProductNaam, 0);
            Array.Resize(ref marrsProductprijsType, 0);
            Array.Resize(ref marrsShop, 0);
            Array.Resize(ref marrsCategorie, 0);
            Array.Resize(ref marriProductnr, 0);
            Array.Resize(ref marriPopularity, 0);
            Array.Resize(ref marrdproductprijs, 0);
        }

        private void ClearWindow(bool bComboBoxes = false, bool bProductList = false, bool bDetails = false)
        {
            if (bComboBoxes == true)
            {
                cboCategories.Items.Clear();
                cboDetCat.Items.Clear();
            }
            if (bProductList == true)
            {
                lstProducten.Items.Clear();
            }
            if (bDetails == true)
            {
                txtDetName.Text = "";
                txtDetPrice.Text = "";
                txtDetShop.Text = "";
                cboDetCat.Text = "";
            }
        }

        private void AddToArray(ref String[] arrs, string sToAdd)
        {
            //Deze methode zal de array met 1 plaats vergroten en de gevraagde String toevoegen.
            Array.Resize(ref arrs, arrs.Length + 1);
            arrs[arrs.GetUpperBound(0)] = sToAdd;
        }

        private void AddToArray(ref int[] arri, int iToAdd)
        {
            //Deze methode zal de array met 1 plaats vergroten en de gevraagde Integer toevoegen.
            Array.Resize(ref arri, arri.Length + 1);
            arri[arri.GetUpperBound(0)] = iToAdd;
        }

        private void AddToArray(ref double[] arrd, double dToAdd)
        {
            //Deze methode zal de array met 1 plaats vergroten en de gevraagde double toevoegen.
            Array.Resize(ref arrd, arrd.Length + 1);
            arrd[arrd.GetUpperBound(0)] = dToAdd;
        }

        private void GuaranteeFileExistance(String sFilePath, Int16 iTeller = 0)
        {
            //Deze methode garandeerd het bestaan van een bestand. Indien mislukt geeft dit een foutmelding weer.
            if (File.Exists(sFilePath) == false)
            {
                if (iTeller <= 3)
                {
                    File.Create(sFilePath).Close();
                    GuaranteeFileExistance(sFilePath, iTeller++);
                }
                else
                {
                    MessageBox.Show("ERROR" + System.Environment.NewLine + "Het programma is er na enkele pogingen nog steeds niet in geslaagd een bestand aan te maken op deze computer. Gelieve te controleren ofdat het uitvoerbestand zich in een map met schrijfrechten bevind. Indien dit probleem aanhoud, probeer dit te starten met administratorpermissie. (rechtsklik op de hyperlink en kies voor 'run as administrator' of 'voer uit als administrator')", "Error Encountered", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void FindProducts(ref int[] arriTemp, String sSelectedCategory)
        {
            for (int i = 0; i < marrsCategorie.Length; i++)
            {
                String sCategory = marrsCategorie[i];   //Indien het product dezelfde category heeft als gezocht
                if (sCategory == sSelectedCategory)
                {
                    int iProductnummer = marriProductnr[i];
                    AddToArray(ref arriTemp, iProductnummer);
                }
            }
        }   //Haal de beschikbare producten v.d. categorie op

        private void SortProducts(ref int[] arriTemp)   //Sorteer de producten op basis van gevraagd criterium.
        {
            //Deze methode sorteerd de array van productnummers van lstproducten op basis van de sorteerselectie.
            //Vind het vereiste sorteercriterium
            String sSortOn = null;
            if (rbtAlphabet.IsChecked == true) sSortOn = "Alfabet";
            if (rbtPopul.IsChecked == true) sSortOn = "Populariteit";
            if (rbtPrijs.IsChecked == true) sSortOn = "Prijs";
            if (rbtShop.IsChecked == true) sSortOn = "Winkel";
            //Laat de array gesorteerd worden op basis van het gevonden criterium.
            SortProducts(ref arriTemp, sSortOn);
        }

        private void SortProducts(ref int[] arriToSort, String sSortingMechanismn)  //SortingSlave
        {
            String[] arrsTemp = new String[0];
            //Het bepalen van de juiste sorteersyntax.
            foreach (int iProdnr in arriToSort)
            {
                //Elk te sorteren productnummer herschrijven met te sorteren gegeven in de tijdelijke array.
                int iProductPositie = Array.IndexOf(marriProductnr, iProdnr);
                switch (sSortingMechanismn)
                {
                    case "Populariteit":
                        AddToArray(ref arrsTemp, marriPopularity[iProductPositie] + ";" + iProdnr);
                        break;
                    case "Prijs":
                        AddToArray(ref arrsTemp, marrdproductprijs[iProductPositie] + ";" + iProdnr);
                        break;
                    case "Winkel":
                        AddToArray(ref arrsTemp, marrsShop[iProductPositie] + ";" + iProdnr);
                        break;
                    default:
                        AddToArray(ref arrsTemp, marrsProductNaam[iProductPositie] + ";" + iProdnr);
                        break;
                }
            }
            //Sorteren m.b.v. de naam en de gegeven array leegmaken voor herschrijven.
            Array.Sort(arrsTemp);
            Array.Resize(ref arriToSort, 0);
            //De te sorteren array herschrijven met gesorteerde waarden.
            foreach (String sProd in arrsTemp)
            {
                int iPositie = sProd.IndexOf(';');
                int iGesorteerdProductNummer = 0;

                bool bTest = int.TryParse(sProd.Substring(iPositie + 1, sProd.Length - iPositie - 1), out iGesorteerdProductNummer);
                AddToArray(ref arriToSort, iGesorteerdProductNummer);
            }
        }

        private void ListProducts(int[] arriTemp)   //Schrijf de gevonden producten weg.
        {
            //Deze methode zal de gesorteerde producten vertalen naar de juiste syntax en ze weergeven in de lijst.
            ClearWindow(false, true, true);
            foreach (int iProductnr in arriTemp)
            {
                int iProductPositie = Array.IndexOf(marriProductnr, iProductnr);
                String sLine = marrsProductNaam[iProductPositie];
                sLine += " - " + marrdproductprijs[iProductPositie].ToString("C") + " " + marrsProductprijsType[iProductPositie];
                sLine += " - " + marrsShop[iProductPositie];
                AddToArray(ref marriInProductList, iProductnr);
                lstProducten.Items.Add(sLine);
            }
        }

        private void CatConfirm()
        {
            if (mbCatAdd == true)
            {
                String sNewCat = txtCatName.Text;
                AddToArray(ref marrsTempCat, sNewCat);
                LoadCategories();
                mbCatAdd = false;
            }
            if (mbCatDel == true)
            {
                String sDelCat = txtCatName.Text;
                int iSelectedCat = cboCategories.SelectedIndex;
                for (int i = 0; i < marrsCategorie.Length; i++)
                {
                    String sElement = marrsCategorie[i];
                    if (sElement == sDelCat)
                    {
                        marrsCategorie[i] = "Zonder Categorie";
                    }
                }
                LoadCategories();
                mbCatDel = false;
            }
            if (mbCatEdit == true)
            {
                String sOldCat = (String)cboCategories.SelectedItem;
                String sNewCat = txtCatName.Text;
                int iSelectedCat = cboCategories.SelectedIndex;
                for (int i = 0; i < marrsCategorie.Length; i++)
                {
                    String sElement = marrsCategorie[i];
                    if (sElement == sOldCat)
                    {
                        marrsCategorie[i] = sNewCat;
                    }
                }
                LoadCategories();
                cboCategories.SelectedIndex = iSelectedCat;
                mbCatEdit = false;
            }
            EnableDisableControls();
            ExportProductData();
        }

        private void Confirm()
        {
            if (mbDetAdd == true)
            {
                //De gegevens uit het programma halen.
                int iProductNummer;
                do
                {
                    iProductNummer = moRandomGenerator.Next(0, 10000);
                } while (Array.IndexOf(marriProductnr, iProductNummer) != -1);
                String sProdNaam = txtDetName.Text;
                String sProdPrijsEnType = txtDetPrice.Text.Replace('€', ' ');
                //Aanpassen van de prijs
                double dProductPrijs = -1; String sProductPrijsType = null; double dPrijs = 0; String sType = "";
                bool bConvert = true;
                for (int i = 0; i < txtDetPrice.Text.Length; i++)
                {
                    if (bConvert == true)
                    {
                        String sTest = txtDetPrice.Text.Substring(0, i + 1);
                        bConvert = double.TryParse(sTest, out dProductPrijs);
                    }
                    else
                    {
                        if (sProductPrijsType == null)
                        {
                            bool bConvert2 = double.TryParse(txtDetPrice.Text.Substring(0, i - 1), out dProductPrijs);
                            sProductPrijsType = txtDetPrice.Text.Substring(i - 1, txtDetPrice.Text.Length - i + 1);
                        }
                    }
                }
                if (sProductPrijsType != null)
                {
                    dPrijs = dProductPrijs;
                    sType = sProductPrijsType.Replace('€', ' ');
                }
                String sProdShop = txtDetShop.Text;
                String sCategory = (String)cboDetCat.SelectedItem;
                //De gegevens wegschrijven
                AddToArray(ref marriProductnr, iProductNummer);
                AddToArray(ref marrsProductNaam, sProdNaam);
                AddToArray(ref marrdproductprijs, dPrijs);
                AddToArray(ref marrsProductprijsType, sType);
                AddToArray(ref marrsCategorie, sCategory);
                AddToArray(ref marrsShop, sProdShop);
                AddToArray(ref marriPopularity, 0);
                mbDetAdd = false;
            }
            if (mbDatDel == true)
            {
                //Gegevens Ophalen
                String sSelectedProduct = txtDetName.Text;
                int iSelectedProductPosition = Array.IndexOf(marrsProductNaam, sSelectedProduct);
                if (iSelectedProductPosition != -1)
                {
                    int iSelectedProductNumber = marriProductnr[iSelectedProductPosition];
                    //Tijdelijke arrays declareren
                    int[] arriProductnr = marriProductnr;
                    String[] arrsProductNaam = marrsProductNaam;
                    double[] arrdproductprijs = marrdproductprijs;
                    String[] arrsProductprijsType = marrsProductprijsType;
                    String[] arrsCategorie = marrsCategorie;
                    String[] arrsShop = marrsShop;
                    int[] arriPopularity = marriPopularity;
                    //Arrays Leegmaken
                    ClearProductArrays();
                    //Arrays wegschrijven
                    for (int i = 0; i <= arriPopularity.GetUpperBound(0); i++)
                    {
                        if (arriProductnr[i] != iSelectedProductNumber)
                        {
                            AddToArray(ref marriProductnr, arriProductnr[i]);
                            AddToArray(ref marrsProductNaam, arrsProductNaam[i]);
                            AddToArray(ref marrdproductprijs, arrdproductprijs[i]);
                            AddToArray(ref marrsProductprijsType, arrsProductprijsType[i]);
                            AddToArray(ref marrsCategorie, arrsCategorie[i]);
                            AddToArray(ref marrsShop, arrsShop[i]);
                            AddToArray(ref marriPopularity, arriPopularity[i]);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Het te verwijderen product is niet gevonden.", "Geen resultaat", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                mbDatDel = false;
            }
            if (mbDatEdit == true)
            {
                WriteDetails();
                mbDatEdit = false;
            }
            //Standaardacties
            ExportProductData();
            LoadCategories();
            EnableDisableControls();
        }

        private void WriteDetails()
        {
            //Deze methode zal de wijzigingen aangebracht in het detailvenster opslaan.
            //Bepalen van geselecteerd product & bijhorend productnummer
            int iProductNummer = miTEMPdetails;
            int iGeselecteerdProduct = Array.IndexOf(marriProductnr, iProductNummer);

            //Aanpassen van gegevens in de arrays
            //Aanpassen van de strings
            marrsProductNaam[iGeselecteerdProduct] = txtDetName.Text;
            marrsCategorie[iGeselecteerdProduct] = (String)cboDetCat.SelectedItem;
            marrsShop[iGeselecteerdProduct] = txtDetShop.Text;
            //Aanpassen van de prijs
            double dProductPrijs = -1; String sProductPrijsType = null; double dPrijs = 0; String sPrijsType = "";
            bool bConvert = true;
            for (int i = 0; i < txtDetPrice.Text.Length; i++)
            {
                if (bConvert == true)
                {
                    String sTest = txtDetPrice.Text.Substring(0, i + 1);
                    bConvert = double.TryParse(sTest, out dProductPrijs);
                }
                else
                {
                    if (sProductPrijsType == null)
                    {
                        bool bConvert2 = double.TryParse(txtDetPrice.Text.Substring(0, i - 1), out dProductPrijs);
                        sProductPrijsType = txtDetPrice.Text.Substring(i - 1, txtDetPrice.Text.Length - i + 1);
                    }
                }
            }
            if (sProductPrijsType != null)
            {
                dPrijs = dProductPrijs;
                sPrijsType = sProductPrijsType.Replace('€', ' ');
            }
            marrdproductprijs[iGeselecteerdProduct] = dPrijs;
            marrsProductprijsType[iGeselecteerdProduct] = sPrijsType;

            //Aanpassingen Finaliseren
            ClearWindow(false, false, true);
        } // Sla de gemaakte wijzigingen in de details op.

        private void GoToMenu()
        {
            //Deze methode zorgt ervoor dat de gebruiker terug kan gaan naar het hoofdmenu.
            //Er wordt bevestiging vereist.
            MessageBoxResult mbr = new MessageBoxResult();
            mbr = MessageBox.Show("Bent u zeker? Alle niet opgeslagen data gaat verloren als u dit venster verlaat.", "Bevestiging vereist", MessageBoxButton.OKCancel, MessageBoxImage.Question, MessageBoxResult.Cancel);
            if (mbr.Equals(MessageBoxResult.OK))
            {
                //Indien de gebruker heeft goedgekeurd, doorgaan naar het hoofdmenu.
                HomeWindow hwin = new HomeWindow();
                hwin.Show();
                this.Close();
            }
        } //Keer terug naar het hoofdmenu (bevestiging vereist)

        private void AddCategory()
        {
            //Deze methode voegt een product toe aan het programma
            mbCatAdd = true;
            txtCatName.Text = "";
            EnableDisableControls();
        }

        private void AddTempCat()
        {
            String[] arrsTEMP = new String[0];
            foreach (String fe in cboDetCat.Items)
            {
                String sCat = fe.ToString();
                AddToArray(ref arrsTEMP, sCat);
            }
            foreach (String s in marrsTempCat)
            {
                AddToArray(ref arrsTEMP, s);
            }
            cboDetCat.Items.Clear();
            foreach (String sCategory in arrsTEMP)
            {
                cboDetCat.Items.Add(sCategory);
            }
        }

        private void DeleteCategory()
        {
            //Deze methode verwijderd een product aan het programma
            mbCatDel = true;
            txtCatName.Text = "";
            EnableDisableControls();
        }

        private void EditCategory()
        {
            //Deze methode laat de gebruiker toe de categorie-waarden te veranderen.
            mbCatEdit = true;
            if (cboCategories.SelectedIndex != -1) txtCatName.Text = cboCategories.SelectedItem.ToString();
            EnableDisableControls();
        }

        private void AddProduct()
        {
            //Deze methode voegt een product toe aan het programma.
            mbDetAdd = true;
            txtDetName.Text = "";
            txtDetPrice.Text = "";
            txtDetShop.Text = "";
            cboCategories.SelectedIndex = -1;
            EnableDisableControls();
        }

        private void DeleteProduct()
        {
            //Deze methode verwijderd een product uit het programma.
            mbDatDel = true;
            txtDetName.Text = "";
            txtDetPrice.Text = "";
            txtDetShop.Text = "";
            cboCategories.SelectedIndex = -1;
            EnableDisableControls();
        }

        private void EditProduct()
        {
            //Deze methode laat de gebruikers toe een category te wijzigen.
            mbDatEdit = true;
            EnableDisableControls();
        }

        private void Shopping_Click(object sender, MouseButtonEventArgs e)
        {
            GoToMenu();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadWindow();
        }

        private void cboCategories_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cboCategories.SelectedIndex != -1)
            {
                if (mbCatEditing == false) LoadProducts();
                txtCatName.Text = (String)cboCategories.SelectedItem;
            }
        }

        private void lstProducten_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (lstProducten.SelectedIndex != -1)
            {
                if (lstProducten.SelectedIndex >= 0) LoadDetails();
                EnableDisableControls();
            }
        }

        private void rbtPrijs_Checked(object sender, RoutedEventArgs e)
        {
            if (cboCategories != null) LoadProducts();
        }

        private void rbtAlphabet_Checked(object sender, RoutedEventArgs e)
        {
            if (cboCategories != null) LoadProducts();
        }

        private void rbtShop_Checked(object sender, RoutedEventArgs e)
        {
            if (cboCategories != null) LoadProducts();
        }

        private void rbtPopul_Checked(object sender, RoutedEventArgs e)
        {
            if (cboCategories != null) LoadProducts();
        }

        private void btnCatAdd_Click(object sender, RoutedEventArgs e)
        {
            AddCategory();
        }

        private void btnCatDel_Click(object sender, RoutedEventArgs e)
        {
            DeleteCategory();
        }

        private void btnCatEdit_Click(object sender, RoutedEventArgs e)
        {
            EditCategory();
        }

        private void btnProdAdd_Click(object sender, RoutedEventArgs e)
        {
            AddProduct();
        }

        private void btnConfirm2_Click(object sender, RoutedEventArgs e)
        {
            CatConfirm();
        }

        private void btnProdDel_Click(object sender, RoutedEventArgs e)
        {
            DeleteProduct();
        }

        private void btnProdEdit_Click(object sender, RoutedEventArgs e)
        {
            EditProduct();
        }

        private void btnConfirm_Click(object sender, RoutedEventArgs e)
        {
            Confirm();
        }

        private void txtDetName_TextChanged(object sender, TextChangedEventArgs e)
        {
            EnableDisableControls();
        }

        private void txtDetPrice_TextChanged(object sender, TextChangedEventArgs e)
        {
            EnableDisableControls();
        }

        private void txtDetShop_TextChanged(object sender, TextChangedEventArgs e)
        {
            EnableDisableControls();
        }

        private void cboDetCat_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            EnableDisableControls();
        }

        private void txtCatName_Click(object sender, MouseButtonEventArgs e)
        {
            txtCatName.Text = "";
        }

        private void EnableDisableControls()
        {
            //Standaardwaarden definiëren
            cboCategories.IsEnabled = true;
            lstProducten.IsEnabled = true;
            btnCatAdd.IsEnabled = true;
            btnCatDel.IsEnabled = true;
            btnCatEdit.IsEnabled = true;
            btnCatConfirm.IsEnabled = false;
            btnProdAdd.IsEnabled = true;
            btnProdDel.IsEnabled = true;
            btnProdEdit.IsEnabled = true;
            btnConfirm.IsEnabled = false;
            txtCatName.IsEnabled = false;
            txtDetName.IsEnabled = false;
            txtDetPrice.IsEnabled = false;
            txtDetShop.IsEnabled = false;
            cboDetCat.IsEnabled = false;
            btnCancel1.Visibility = Visibility.Hidden;
            btnCancel2.Visibility = Visibility.Hidden;

            //Afwijkingen analyseren
            if (mbCatAdd == true)
            {
                btnCatDel.IsEnabled = false;
                btnCatEdit.IsEnabled = false;
            }

            if (mbCatDel == true)
            {
                btnCatAdd.IsEnabled = false;
                btnCatEdit.IsEnabled = false;
            }

            if (mbCatEdit == true)
            {
                btnCatAdd.IsEnabled = false;
                btnCatDel.IsEnabled = false;
            }

            if ((mbCatAdd == true) || (mbCatDel == true) || (mbCatEdit == true))
            {
                txtCatName.IsEnabled = true;
                btnCatConfirm.IsEnabled = true;
                btnCancel1.Visibility = Visibility.Visible;
            }

            if (mbDetAdd == true)
            {
                btnProdDel.IsEnabled = false;
                btnProdEdit.IsEnabled = false;
            }

            if (mbDatDel == true)
            {
                btnProdAdd.IsEnabled = false;
                btnProdEdit.IsEnabled = false;
            }

            if (mbDatEdit == true)
            {
                btnProdAdd.IsEnabled = false;
                btnProdDel.IsEnabled = false;
            }

            if ((mbDatEdit == true) || (mbDetAdd == true) || (mbDatDel == true))
            {
                txtDetName.IsEnabled = true;
                txtDetPrice.IsEnabled = true;
                txtDetShop.IsEnabled = true;
                cboDetCat.IsEnabled = true;
                btnConfirm.IsEnabled = true;
                btnCancel2.Visibility = Visibility.Visible;
            }

            if (txtDetPrice.Text.Length >= 1)
            {
                int iTest;
                bool bTest = int.TryParse(txtDetPrice.Text.Substring(0, 1), out iTest);
                if (bTest == false)
                {
                    btnConfirm.IsEnabled = false;
                }
            }

            if (lstProducten.SelectedIndex == -1)
            {
                if ((mbDatDel == true) ^ (mbDetAdd == true)) { }
                else
                {
                    txtDetName.Text = "";
                    txtDetPrice.Text = "";
                    txtDetShop.Text = "";
                    cboDetCat.SelectedIndex = -1;
                }
            }

            if (cboCategories.SelectedIndex == -1)
            {
                txtCatName.Text = "";
            }
        }

        private void btnCancel1_Click(object sender, RoutedEventArgs e)
        {
            mbCatAdd = false;
            mbCatDel = false;
            mbCatEdit = false;
            EnableDisableControls();
        }

        private void btnCancel2_Click(object sender, RoutedEventArgs e)
        {
            mbDetAdd = false;
            mbDatDel = false;
            mbDatEdit = false;
            EnableDisableControls();
        }
    }
}
