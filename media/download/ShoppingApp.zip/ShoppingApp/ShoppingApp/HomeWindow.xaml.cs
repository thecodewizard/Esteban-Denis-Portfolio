﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ShoppingApp
{
    /// <summary>
    /// Interaction logic for HomeWindow.xaml
    /// </summary>
    public partial class HomeWindow : Window
    {

        /* De pagina Homewindow heeft de volgende hoofdklasses:
         *  1. Open Mainwindow
         *  2. Open EditWindow
         *  3. Load List
         *      -> Add To Array
         */

        public HomeWindow()
        {
            InitializeComponent();
        }

        //Declareren op moduleniveau
        //Arrays
        private String[] marrsLists = new String[0];
        //Variabelen
        public String pmsLoadedFile = "";

        private void OpenMainWindow()
        {
            //Deze methode zal ervoor zorgen dat de mainwindow geopend wordt.
            //Initialiseer Mainwindow
            MainWindow mw = new MainWindow(pmsLoadedFile);
            cboLists.Visibility = Visibility.Hidden;
            //Wissel van scherm
            mw.Show();
            this.Close();
        }

        private void OpenEditWindow()
        {
            //Deze methode zal ervoor zorgen dat de Editwindow geopend wordt.
            //Initialiseer Editwindow
            EditWindow ew = new EditWindow();
            cboLists.Visibility = Visibility.Hidden;
            //Wissel van scherm
            ew.Show();
            this.Close();
        }

        private void LoadList()
        {
            //Deze methode zal de gekozen lijst laden in mainwindow.
            //Computer generated waarden wegfilteren
            if (cboLists.SelectedIndex >= 0)
            {
                int iSelectedItem = cboLists.SelectedIndex;
                pmsLoadedFile = marrsLists[iSelectedItem];
                OpenMainWindow();
            }
        }

        private void AddToArray(ref String[] arrs, String sToAdd)
        {
            //Deze methode voegt de gevraagde string toe aan de opgegeven array.
            Array.Resize(ref arrs, arrs.Length + 1);
            arrs[arrs.GetUpperBound(0)] = sToAdd;
        }

        private void LoadWindow()
        {
            //Deze methode zal de lijsten laden bij het opstarten van het venster.
            String[] arrsTemp = Directory.GetFiles(AppDomain.CurrentDomain.BaseDirectory + "/AppData/");
            foreach (String sFile in arrsTemp)
            {
                if (sFile.EndsWith(".txt"))
                {
                    AddToArray(ref marrsLists, sFile);
                }
            }
            foreach (String sElement in marrsLists)
            {
                if (sElement != null)
                {
                    String sFile = System.IO.Path.GetFileNameWithoutExtension(sElement);
                    cboLists.Items.Add(sFile);
                }
            }
            cboLists.Visibility = Visibility.Hidden;
            if (cboLists.Items.Count <= 0)
            {
                btnLoadLists.IsEnabled = false;
            }
            else
            {
                btnLoadLists.IsEnabled = true;
            }
        }

        private void btnNewLists_Click(object sender, RoutedEventArgs e)
        {
            OpenMainWindow();
        }

        private void btnLoadLists_Click(object sender, RoutedEventArgs e)
        {
            cboLists.Visibility = Visibility.Visible;
        }

        private void btnEditLists_Click(object sender, RoutedEventArgs e)
        {
            OpenEditWindow();
        }

        private void cboLists_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            LoadList();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            LoadWindow();
        }
    }
}