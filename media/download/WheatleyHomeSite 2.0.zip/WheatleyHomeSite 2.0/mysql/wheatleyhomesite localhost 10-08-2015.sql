-- phpMyAdmin SQL Dump
-- version 4.2.11
-- http://www.phpmyadmin.net
--
-- Machine: 127.0.0.1
-- Gegenereerd op: 10 aug 2015 om 21:39
-- Serverversie: 5.6.21
-- PHP-versie: 5.6.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Databank: `wheatleyhomesite`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `contact`
--

CREATE TABLE IF NOT EXISTS `contact` (
`id` int(11) NOT NULL,
  `sender` varchar(100) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `message` varchar(10000) NOT NULL,
  `time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `coockies`
--

CREATE TABLE IF NOT EXISTS `coockies` (
`coockie_id` int(11) NOT NULL,
  `uid` int(11) NOT NULL,
  `coockie_user` varchar(100) NOT NULL,
  `coockie_hash` varchar(767) NOT NULL,
  `time_to_die` int(11) NOT NULL,
  `created_on` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `coockies`
--

INSERT INTO `coockies` (`coockie_id`, `uid`, `coockie_user`, `coockie_hash`, `time_to_die`, `created_on`) VALUES
(5, 1, 'wheatley', '$2y$10$qfiIvSxA79A1FeuH41ns/OU6gquYq09QnxG0TOEUpawpDNWkBuHBq', 1441442588, 1439023388);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `permissions`
--

CREATE TABLE IF NOT EXISTS `permissions` (
  `permission_id` int(11) NOT NULL,
  `short_name` varchar(10) NOT NULL,
  `name` varchar(1000) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `permissions`
--

INSERT INTO `permissions` (`permission_id`, `short_name`, `name`) VALUES
(1, 'ADMIN', 'Administrator'),
(2, 'PREF', 'Preferred User'),
(3, 'USER', 'User'),
(4, 'GUEST', 'Guest | Restricted User');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `status`
--

CREATE TABLE IF NOT EXISTS `status` (
`status_id` int(11) NOT NULL,
  `status` varchar(100) NOT NULL,
  `account_allowed` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `status`
--

INSERT INTO `status` (`status_id`, `status`, `account_allowed`) VALUES
(1, 'Active', 1),
(2, 'Pending Registration', 0),
(3, 'Marked for Deletion', 0);

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `users`
--

CREATE TABLE IF NOT EXISTS `users` (
`uid` int(11) NOT NULL,
  `permission_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(1000) NOT NULL,
  `password` varchar(1000) NOT NULL,
  `salt` varchar(1000) NOT NULL,
  `last_logged_in` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `users`
--

INSERT INTO `users` (`uid`, `permission_id`, `username`, `email`, `password`, `salt`, `last_logged_in`, `status`) VALUES
(1, 1, 'wheatley', 'wheatley@estebandenis.ddns.net', 'e968e7870f27f388308a0602f3b99503', '$2y$10$Fi7.BTlZ32F6jhvnxB2rU.6MbglhQA6fWlWUPRN2t8QHck.h5Y.Sm', 1424554, 1),
(2, 4, 'the_bano', 'esteban.denis.ed@gmail.com', '12d1d03ae2109f2d65411b2fa3c88fdc', '$2y$10$td/kKZ.q5ENLiXz9t3Le7.IU74k6KGCx3WwVMiFaNEgagtAbiqJVi', 1424554, 2),
(3, 4, 'root', 'nick.dhondt38@gmail.com', 'd7d0f46ef11ac262b7279c3aedca94e7', '$2y$10$CKml1syhzuU0NOS6edPZy.88RQfw3aOAzH5FNeDNBE49pNBzviybe', 1424554, 1);

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `contact`
--
ALTER TABLE `contact`
 ADD PRIMARY KEY (`id`);

--
-- Indexen voor tabel `coockies`
--
ALTER TABLE `coockies`
 ADD PRIMARY KEY (`coockie_id`), ADD UNIQUE KEY `coockie_hash` (`coockie_hash`);

--
-- Indexen voor tabel `permissions`
--
ALTER TABLE `permissions`
 ADD PRIMARY KEY (`permission_id`), ADD UNIQUE KEY `short_name` (`short_name`);

--
-- Indexen voor tabel `status`
--
ALTER TABLE `status`
 ADD PRIMARY KEY (`status_id`), ADD UNIQUE KEY `status` (`status`);

--
-- Indexen voor tabel `users`
--
ALTER TABLE `users`
 ADD PRIMARY KEY (`uid`), ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `contact`
--
ALTER TABLE `contact`
MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT voor een tabel `coockies`
--
ALTER TABLE `coockies`
MODIFY `coockie_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT voor een tabel `status`
--
ALTER TABLE `status`
MODIFY `status_id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT voor een tabel `users`
--
ALTER TABLE `users`
MODIFY `uid` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=4;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
