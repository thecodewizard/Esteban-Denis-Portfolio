<?php

function make_mysql_connection(){
    $con = new mysqli('localhost', 'root', 'Ll04021995', 'wheatleyhomesite', 3306);

    if(!$con){
        return false;
    } else return $con;
}

function return_data($con, $data){
    $con->close();
    return $data;
}

function unixToTime($unix){
    if(!empty($unix)){
        $dtT = new DateTime("@$unix");
        return $dtT->format('Y-m-d H:i:s');
    } else return $unix;
}