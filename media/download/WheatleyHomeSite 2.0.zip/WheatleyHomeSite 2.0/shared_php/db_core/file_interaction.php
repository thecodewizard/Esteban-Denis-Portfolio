<?php
require_once "db_interaction.php";

function upload_file($target_dir, $file, $expected_extention){
    //Create the needed variables
    $data = array();
    $data["success"] = false;
    $data["error"] = "";

    //Check input data
    if(empty($target_dir) || empty($file)){
        $data["success"] = false;
        $data["error"] = "The input data was not deemed valid";
        return $data;
    }

    //Prepare file upload variables
    $filename = $file["name"];
    $filesize = $file["size"];

    $target_file = $target_dir.basename($filename);
    $imageFiletype = pathinfo($target_file, PATHINFO_EXTENSION);

    //Check if the extention matches
    if($imageFiletype !== $expected_extention){
        $data["success"] = false;
        $data["error"] = "The file-extention was not deemed valid".$imageFiletype;
        return $data;
    }

    //Check if the file already exists
    if(file_exists($target_file)){
        $data["success"] = false;
        $data["error"] = "The file already exists";
        return $data;
    }

    //Check the file size
    if($filesize > 1000000){
        $data["success"] = false;
        $data["error"] = "The file cannot be bigger than 1MB";
        return $data;
    }

    //If the form survived until here, try to upload the file
    if(move_uploaded_file($file["tmp_name"], $target_file)){
        $data["success"] = true;
        return $data;
    } else {
        $data["success"] = false;
        $data["error"] = "An error occured while uploading your file";
        return $data;
    }

} //DATA