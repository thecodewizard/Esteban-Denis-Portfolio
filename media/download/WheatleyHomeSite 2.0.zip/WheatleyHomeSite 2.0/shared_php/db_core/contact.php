<?php
require_once "db_interaction.php";

function save_contact($sender, $subject, $message, $time){
    //Declare variables
    $data = array();
    $data["success"] = false;
    $data["error"] = "";

    //Make the connection
    $con = make_mysql_connection();
    if($con === false) $data["error"] = "Connection Failed";

    //Check whether the given data is valid
    if(empty($sender) || empty($subject) || empty($message) || empty($time)){
        $data["error"] = "The given data is not valid";
    }

    //Temp. Validation
    if(!empty($data["error"])){
        $data["success"] = false;
        return return_data($con, $data);
    }

    //Save the data
    $stmt = $con->prepare("INSERT INTO contact(sender, subject, message, time) VALUES (?,?,?,?)");
    $stmt->bind_param('sssi', $sender, $subject, $message, $time);
    $stmt->execute();

    //Check if the insertion went OK
    if($con->affected_rows !== 1){
        if($con->affected_rows == 0) $data["error"] = "No rows were affected";
        else $data["error"] = "Too many rows were affected";
    }

    //Final validation
    if(!empty($data["error"])) $data["success"] = false;
    else $data["success"] = true;

    //If everything went OK, mail the administrator in order to notify of the new contact request.
    notify_admin($time, $sender, $subject, $message);

    //Return values and end connection
    return return_data($con, $data);
}

function notify_admin($time, $sender, $subject, $message){
    //Include the file
    include_once (__DIR__."/../mail.php");

    //Send the mail
    $title = array(); $paragraph = array();
    $title[] = $sender." has filed a new contact request with the subject '".$subject."'";
    $paragraph[] = "The message: \r\n".$message;
    send_email("wheatley@estebandenis.ddns.net", "A new contact request filed at ".unixToTime($time), $sender." has filed a new contact request", $title, $paragraph);

}