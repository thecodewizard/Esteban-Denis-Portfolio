<?php
require_once "db_interaction.php";
require_once "file_interaction.php";

function prepare_title($type, $subtype, $title, $options){
    //This function returns a valid title for the requested extention

    //Make the needed variables
    $data = array();
    $data["success"] = false;
    $data["error"] = "";

    //Check the input data
    if(empty($type) || empty($subtype) || empty($title) || !is_array($options)){
        $data["success"] = false;
        $data["error"] = "The input data was invalid.";
        return $data;
    }

    //Determine the title by analysing the type and subtype
    switch($type){
        case "audio":
            //For audio, give the downloaded content the title as name.
            $data["title"] = $title;
            break;
        case "image":
            //For image, give the downloaded content the title as name.
            $data["title"] = $title;
            break;
        case "other":
            //For other, give the downloaded content the title as name.
            $data["title"] = $title;
            break;
        case "video":
            //For Video, base the name on the subtype
            switch($subtype){
                case "movie":
                    //For a movie use the following syntax: title (quality) - year
                    if(!empty($options["quality"]) && !empty($options["year"])){
                        $data[$title] = $title." (".$options["quality"].") - ".$options["year"];
                    } else $data["title"] = $title;
                    break;
                case "serie":
                    //For a serie use the following syntax: seriename Sxx title
                    if(!empty($options["serie"]) && !empty($options["season"])){
                        $data["title"] = $options["serie"]." S".$options["season"]." E".$title;
                    } else $data["title"] = $title;
                    break;
                case "undefined":
                    //For undefined, give the downloaded content the title as name
                    $data["title"] = $title;
                    break;
                default:
                    //If basic check should fail, give the downloaded content the title as name
                    $data["title"] = $title;
                    break;
            }
    }

    //Return the title
    if(!empty($data["title"])){
        $data["success"] = true;
    } else {
        $data["success"] = false;
        $data["error"] = "No title has been generated. - Unexpected Error";
    }

    return $data;
} //DATA

function upload_torrent($file){
    //Create the needed variables
    $data = array();
    $data["success"] = false;
    $data["error"] = "";

    //Check input data
    if(empty($file)){
        $data["success"] = false;
        $data["error"] = "The input was not correct.";
        return $data;
    }

    //Open a database connection
    $con = make_mysql_connection();
    if($con === false){
        $data["success"] = false;
        $data["error"] = "The db connection could not be initiated";
        return $data;
    }

    //Prepare the upload data
    $target_dir = __DIR__."/../../users/extentions/file_handling/upload_cache/";
    $extention = "torrent";

    //Try the upload
    $upload = upload_file($target_dir, $file, $extention);

    //Validate the upload
    if(is_array($upload)){
        if($upload["success"]){
            //The upload has succeeded.
        } else $data["error"] = $upload["error"];
    } else $data["error"] = "The server gave an unexpected upload exception";

    //Final validation
    if(!empty($data["error"])) $data["success"] = false;
    else $data["success"] = true;

    return return_data($con, $data);
}//DATA

