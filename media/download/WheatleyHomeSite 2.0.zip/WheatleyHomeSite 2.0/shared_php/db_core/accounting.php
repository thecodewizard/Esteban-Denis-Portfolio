<?php
require_once "db_interaction.php";

/* MAIN FUNCTIONS */
function set_logged_session($uid){
    //This function fetches the basic info of the logged user and stores it in session.

    //First, delete all current sessions
    if(session_status() !== PHP_SESSION_ACTIVE) { session_start(); }

    $_SESSION = array();
    session_unset();

    //Secondly, fetch the data of the user
        //Make the needed variables
    $data = array();
    $data["success"] = false;
    $data["error"] = "";

        //open connection
    $con = make_mysql_connection();
    if($con === false) $data["error"] = "No connection could be made.";

        //Make sure the user exists
    if($con !== false){
        $username = get_username($uid, $con);
        if($username["error"] !== false && !empty($username["username"])) {
            $exists = user_exists($username["username"], $con);
            if($exists === false) $data["error"] = "User doesn't exist";
        } else $data["error"] = "Could not fetch a valid username".$username["error"];
    }

        //Temp. Validation
    if(!empty($data["error"])){
        $data["success"] = "false";
        return return_data($con, $data);
    }

        //Fetch the data from the user.
    $sql = $con->query("SELECT u.uid, u.username, u.email, u.last_logged_in, s.status, p.short_name as 'permission_short', p.name as 'permission' FROM users u
                  INNER JOIN status s ON u.status = s.status_id INNER JOIN permissions p ON u.permission_id = p.permission_id WHERE u.uid = '".$uid."'");

    if(!empty($sql)){
        //Get the results
        $result = array();
        while($row = $sql->fetch_assoc()) $result[] = $row;

        //Check if the count matches the expected
        if(count($result) === 1){
            //Check if all the data has been received correctly
            $result = $result[0];
            foreach($result as $entry){
                if(!isset($entry)){
                    $data["error"] = "Not all the data has been received from the database.";
                }
            }
        } else {
            if(count($result) > 1) $data["error"] = "More then one user found for the given uid";
            else $data["error"] = "No user matched the UID.";
        }

        //Temp Validation
        if(!empty($data["error"])){
            $data["success"] = false;
            return return_data($con, $data);
        }

        //Save the found data in sessions
        $_SESSION["uid"] = $result["uid"];
        $_SESSION["username"] = $result["username"];
        $_SESSION["email"] = $result["email"];
        $_SESSION["last_logged_in"] = $result["last_logged_in"];
        $_SESSION["status"] = $result["status"];
        $_SESSION["permission_short"] = $result["permission_short"];
        $_SESSION["permission"] = $result["permission"];

        //Pass along the essential data to the outbound data array
        $data["username"] = $result["username"];
        $data["last_logged_in"] = $result["last_logged_in"];
        $data["permission"] = $result["permission"];

        //Check if the outbound array is filled correctly
        if(empty($data["username"]) || empty($data["last_logged_in"]) || !isset($data["permission"]))
            $data["error"] = "Not all outbound data has been send correctly";

        //Temp. Validation
        if(!empty($data["error"])){
            $data["success"] = false;
            return return_data($con, $data);
        }

        //Now that the data has been fetched correctly, update the last logged in
        $update = update_last_logged_in($uid, $con);
        if(is_array($update)){
            if($update["success"] = false){
                if(!empty($update["error"])) $data["error"] = $update["error"];
                else $data["error"] = "Something went horribly wrong with updating the lli.";
            }
        } else $data["error"] = "Updating the lli didn't go as expected";

        //Final Validation
        if(!empty($data["error"])) $data["success"] = false;
        else $data["success"] = true;
        return return_data($con, $data);
    }
} //DATA

function validate_login($username, $password){
    //Declare variables
    $data = array();
    $data["success"] = false;
    $data["error"] = "";

    //Make the connection
    $con = make_mysql_connection();
    if($con === false) $data["error"] = "Connection failed";

    //Check whether the given data is valid
    if(empty($username) || empty($password)){
        $data["error"] = "The given data is not valid";
    }

    //Temp. Validation 1
    if(!empty($data["error"])){
        $data["success"] = false;
        return return_data($con, $data);
    }

    //Check if the user exists
    if(!user_exists($username, $con)) $data["error"] = "username";
    else {
        //Check if the found user has an active account
        if(!account_allowed($username, $con)){
            $data["error"] = "active";
        }
    }

    //Temp. Validation 2
    if(!empty($data["error"])){
        $data["success"] = false;
        return return_data($con, $data);
    }

    //Attempt the login
    $sql = $con->query("SELECT uid, username, password as 'dbpwd', salt FROM users WHERE username = '".$username."'");

    if(!empty($sql)){
        //Get the results
        $result = array();
        while($row = $sql->fetch_assoc()) $result[] = $row;

        //Check if passwords match
        if(count($result) > 1){
            //More than 1 username matched
            $data["error"] = "Unexpected db_core error.";
        } else if(count($result) == 1) {
            //Check if all the data is received correctly
            foreach($result as $entry){
                if(empty($entry)){
                    $data["error"] = "Not all the data has been received from the db_core.";
                    $data["success"] = false;
                    return return_data($con, $data);
                }
            }

            //Encrypt the password
            $pwd = encrypt_password($password, $result[0]["salt"]);
            if($pwd === false) {
                $data["error"] = "Salt not found in database";
            } else if($pwd !== $result[0]["dbpwd"]) {
                //The password doesn't match
                $data["error"] = "password";
            }
        } else {
            $data["error"] = "username";
        }
    } else {
        $data["error"] = "Unexpected Database Error";
    }

    //Final Validation
    if(!empty($data["error"])) $data["success"] = false;
    else {
        //If the login succeeded, pass along the UID for future reference
        if(!empty($result[0]["uid"])) {
            $data["success"] = true;
            $data["logged_uid"] = $result[0]["uid"];
        } else {
            $data["success"] = false;
            $data["error"] = "No UID found for logged user";
        }
    }

    //Return the values and end the connection
    return return_data($con, $data);
} //DATA

function create_coockie($uid, $username){
    //Declare variables
    $data = array();
    $data["success"] = false;
    $data["error"] = "";

    //Make the connection
    $con = make_mysql_connection();
    if($con === false) $data["error"] = "Connection failed";

    //Check whether the given data is valid
    if(empty($username)) $data["error"] = "The given data is not valid";

    //Check if the user exists
    if(empty($username) && user_exists($username, $con)) $data["error"] = "The user is unknown";

    //Temp.validation
    if(!empty($data["error"])){
        $data["success"] = false;
        return return_data($con, $data);
    }

    //Before baking the new coockie, check if the user already has a coockie.
    if(isset($_COOKIE["wheatley_remembers_user"]) && isset($_COOKIE["wheatley_remembers_hash"])){
        //Validate the current found coockie. If it matches (if it is a not tampered coockie for the current logging user)
        //Then the validation process will eat the coockie naturally, so the new made coockies can be saved.
        validate_coockie($_COOKIE["wheatley_remembers_user"], str_replace('%24', '$', $_COOKIE["wheatley_remembers_hash"]));
    }

    //Make the coockie hash
    $coockie = $username.time().rand(0, rand(100,999));
    $hashed_coockie = password_hash($coockie, PASSWORD_BCRYPT);

    //Set the TTL
    $ttl = time() + (60*60*24*7*4); //Coockie blijft 4 weken geldig.
    $time = time();

    //Write to the coockie database
    $stmt = $con->prepare("INSERT INTO coockies(uid, coockie_user, coockie_hash, time_to_die, created_on) VALUES (?,?,?,?,?)");
    $stmt->bind_param('issii', $uid, $username, $hashed_coockie, $ttl, $time);
    $stmt->execute();

    //Check if the insertion went OK
    if($con->affected_rows !== 1){
        if($con->affected_rows === 0) $data["No rows were affected."];
        else $data["error"] = "Too many rows were affected";
    }

    //Final validation
    if(!empty($data["error"])) $data["success"] = false;
    else $data["success"] = true;

    //After successful insertion, make the actual coockies
    setcookie('wheatley_remembers_user', $username, $ttl, "/");
    setcookie('wheatley_remembers_hash', $hashed_coockie, $ttl, "/");

    //Return values and end connection
    return return_data($con, $data);
} //DATA

function validate_coockie($username, $hash, $eat = true){
    //Declare variables
    $data = array();
    $data["success"] = false;
    $data["error"] = "";

    //Make the connection
    $con = make_mysql_connection();
    if($con === false) $data["error"] = "Connection failed";

    //Check whether the given data is valid
    if(empty($username) || empty($hash)){
        $data["error"] = "The given data was not valid";
    } else {
        //If not empty, check if the given hash exists.
        if(coockie_exists($hash, $con) === false) $data["error"] = "The given hash is not valid";
    }

    //Temp. Validation 1
    if(!empty($data["error"])){
        $data["success"] = false;
        return return_data($con, $data);
    }

    //Get all the coockies for the requested user
    $sql = $con->query("SELECT coockie_id, uid, coockie_user, coockie_hash, time_to_die, created_on FROM coockies WHERE coockie_user = '".$username."'");

    if(empty($sql)){
        $data["error"] = "The query gave no results.";
    } else {
        //Get the results
        $result = array();
        while($row = $sql->fetch_assoc()) $result[] = $row;

        //Check if results are received
        if(count($result) < 1){
            $data["error"] = "No results are received";
        }
    }

    //Temp. Validation
    if(!empty($data["error"])){
        $data["success"] = false;
        return return_data($con, $data);
    }

    //Check whether the hash and the user match
    $match_found = false;
    foreach($result as $entry){
        if(!$match_found){
            if($entry["time_to_die"] > time()){
                if($username === $entry["coockie_user"] && $hash === $entry["coockie_hash"]){
                    $match_found = true;
                }
            }
        }
    }

    if(!$match_found){
        $data["error"] = "The given coockie could not be validated.";
    } else if($eat){
        //When a match is found for current coockie name and hash, delete that coockie in order to overcome coockie_theft.
        delete_coockie($hash, $con);
    }

    //Final validation
    if(!empty($data["error"])) $data["success"] = false;
    else $data["success"] = true;
    return return_data($con, $data);
} //DATA

function register_user($username, $password, $type_id, $email){
    //Declare variables
    $data = array();
    $data["success"] = false;
    $data["error"] = "";

    //Make the connection
    $con = make_mysql_connection();
    if($con === false) $data["error"] = "Connection Failed";

    //Check whether the given data is valid
    if(empty($username) || empty($password) || empty($type_id) || empty($email)){
        $data["error"] = "The given data is not valid";
    }

    //Check if user doesn't exist yet.
    if(user_exists($username, $con)){
        $data["error"] = "username";
    } else {
        //Check if the requested email adress is already in use.
        $adress = email_exists($email, $con);
        if($adress["success"] == "true"){
            if(!empty($adress["username"])){
                $data["error"] = "email";
            }
        } else {
            $data["error"] = "Couldn't access email database";
        }
    }

    //Temp. Validation
    if(!empty($data["error"])){
        $data["success"] = false;
        return return_data($con, $data);
    }

    //Calculate the needed variables
        //Calculate unique salt
    $salt = md5($username).time().rand(0, rand(1000,9999));
    $salt = password_hash($salt, PASSWORD_BCRYPT);

    //Hash password
    $pwd = encrypt_password($password, $salt);

    //Prepare the needed variables
    $stmt = $con->prepare("INSERT INTO users(uid, permission_id, username, email, password, salt, last_logged_in, status) VALUES(NULL ,?,?,?,?,?,0,2)");
    $stmt->bind_param("issss", $type_id, $username, $email, $pwd, $salt);
    $stmt->execute();

    //Check if the insertion went OK
    if($con->affected_rows !== 1){
        if($con->affected_rows === 0) $data["No rows were affected."];
        else $data["error"] = "Too many rows were affected";
    }

    //Final validation
    if(!empty($data["error"])) $data["success"] = false;
    else $data["success"] = true;

    //Return values and end connection
    return return_data($con, $data);
} //DATA


/* HELPER FUNCTIONS */
function get_username($uid, $con = false){
    //Make needed variables
        //Connection info
    if($con === false) $server_connection = true;
    else $server_connection = false;
        //Return values
    $data = array();
    $data["success"] = false;
    $data["error"] = "";

    if(!empty($uid)){
        //Make sure a connection is active
        if($con === false){
            $con = make_mysql_connection();
            if($con === false) return $data["error"] = "No connection could be made";
        }

        //Temp. Validation
        if(!empty($data["error"])){
            $data["success"] = false;
            if($server_connection === true) $con->close();
            return $data;
        }

        //Get DB results
        $sql = $con->query("SELECT uid, username FROM users WHERE uid = '".$uid."'");
        $result = array();

        while($row = $sql->fetch_assoc()) $result[] = $row;

        //Close the connection if it was opened by the system
        if($server_connection === true) $con->close();

        //Analyse the results
        if(count($result) == 1){
            if($result[0]["uid"] != $uid) $data["error"] = "The db_uid did not match.";
            else $data["username"] = $result[0]["username"];
        } else $data["error"] = "The DB returned multiple entries.";
    } else return $data["error"] = "The given data is empty";

    //Final validation
    if(!empty($data["error"])) $data["success"] = false;
    else $data["success"] = true;

    return $data;
} //DATA

function user_exists($username, $con = false, $feed_uid = false){
    if($con === false) $server_connection = true;
    else $server_connection = false;

    if(!empty($username)){
        //Make sure a connection is active
        if($con === false){
            $con = make_mysql_connection();
            if($con === false) return false;
        }

        //Get DB results
        $sql = $con->query("SELECT uid, username FROM users WHERE username = '".$username."'");
        $result = array();

        if(!$sql) return false;
        while($row = $sql->fetch_assoc()) $result[] = $row;

        //Close the connection if it was opened by the system
        if($server_connection === true) $con->close();

        //Analyse the results
        if(count($result) == 1){
            $result = $result[0];

            if(!empty($result["uid"]) && !empty($result["username"])){
                if($result["username"] === $username) {
                    if($feed_uid) return $result["uid"];
                    else return true;
                }
            } else return false;
        } else return false;
    } else return false;
    return false;
} //BOOL

function account_allowed($username, $con = false){
    if($con === false) $server_connection = true;
    else $server_connection = false;

    if(!empty($username)){
        //Make sure a connection is active
        if($con === false){
            $con = make_mysql_connection();
            if($con === false) return false;
        }

        //Get DB results
        $sql = $con->query("SELECT s.account_allowed as 'aa' FROM status s
            INNER JOIN users u ON u.status = s.status_id WHERE u.username = '".$username."'");
        $result = array();

        while($row = $sql->fetch_assoc()) $result[] = $row;
        //Make sure the required data has been acquired.
        if(count($result) === 1){
            if(empty($result[0]["aa"])){
                return false;
            } else {
                $aa = $result[0]["aa"];
            }
        } else return false;

        //Close the connection if it was opened by the system
        if($server_connection === true) $con->close();

        //Analyse the results
        if(($aa == 1) || ($aa == 0)){
            switch($aa){
                case 1: return true; break;
                case 0: return false; break;
            }
        } else return false;
    } else return false;
    return false;
} //BOOL

function check_permission($uid, $sec_level, $con = false){
    if($con === false) $server_connection = true;
    else $server_connection = false;

    if(!empty($uid) && !empty($sec_level)){
        //Make sure a connection is active
        if($con === false){
            $con = make_mysql_connection();
            if($con === false) return false;
        }

        //Get the DB results
        $sql = $con->query("SELECT permission_id as 'pid' FROM users WHERE uid='".$uid."'");
        $result = array();
        if(empty($sql)) return false;

        while($row = $sql->fetch_assoc()) $result[] = $row;

        //Close the connection if it was opened by the system
        if($server_connection === true) $con->close();

        //Analyse the results
        if(count($result) == 1){
            $result = $result[0];
            if(!empty($result["pid"])){
                if($result["pid"] <= $sec_level) return true;
                else return false;
            } else return false;
        } else return false;
    } else return false;
} //BOOL

function email_exists($email, $con = false){
    //data["success"] with data["username"] if email found
    //data["success"] if no email matched
    //false if db error.
    if($con === false) $server_connection = true;
    else $server_connection = false;

    //Make the needed variables
    $data = array();
    $data["success"] = "false";
    $data["username"] = "";

    if(!empty($email)){
        //Make sure a connection is active
        if($con === false){
            $con = make_mysql_connection();
            if($con === false){
                $data["success"] = "false";
                return $data;
            }
        }

        //Get DB results
        $sql = $con->query("SELECT username, email FROM users WHERE email = '".$email."'");
        $result = array();

        while($row = $sql->fetch_assoc()) $result[] = $row;

        //Close the connection if it was opened by the system
        if($server_connection === true) $con->close();

        //Analyse the results
        if(count($result) == 1){
            if($result[0]["email"] === $email){
                $data["success"] = "true";
                $data["username"] = $result[0]["username"];
            } else {
                $data["success"] = "false";
            }
        } else $data["success"] = "true";
    } else $data["success"] = "false";
    return $data;
} //DATA

function encrypt_password($password, $salt){
    if(empty($password) || empty($salt)){
        return false;
    } else {
        //MD5 the password
        $pwdcrypt = md5($password);
        //Make total password with salt
        $pwd = md5($pwdcrypt.$salt);
        //Return the password
        return $pwd;
    }
} //BOOL

function coockie_exists($coockie_hash, $con = false){
    if($con === false) $server_connection = true;
    else $server_connection = false;

    if(!empty($coockie_hash)) {
        //Make sure a connection is active
        if ($con === false) {
            $con = make_mysql_connection();
            if ($con === false) return false;
        }

        //Get DB results
        $sql = $con->query("SELECT count(coockie_id) as 'number' FROM coockies WHERE coockie_hash = '" . $coockie_hash . "'");
        $result = array();

        if(!$sql) return false;
        while($row = $sql->fetch_assoc()) $result[] = $row;

        //Close the connection if it was opened by the system
        if($server_connection === true) $con->close();

        //Analyse the results
        if(count($result) == 1){
            //We do expect that only one answer returns. Now check the amount given by mysql.
            if($result[0]["number"] == 1) return true;
            else return false;
        } else return false;
    } else return false;
} //BOOL

function update_coockie($coockie_hash, $con = false){
    if($con === false) $server_connection = true;
    else $server_connection = false;

    if(!empty($coockie_hash)){
        //Make sure a connection is active
        if($con === false){
            $con = make_mysql_connection();
            if($con === false) return false;
        }

        //Get the DB results
        $sql = $con->query("SELECT coockie_id as 'cid', created_on, time_to_die as 'ttl' FROM coockies WHERE coockie_hash = '".$coockie_hash."'");
        $result = array();

        if(!$sql) return false;
        while($row = $sql->fetch_assoc()) $result[] = $row;

        //Close the connection if it was opened by the system
        if($server_connection === true) $con->close();

        //Analyse the results
        if(count($result) == 1 && isset($result[0]["cid"])){
            $result = $result[0];
            $cid = $result["cid"];
            $ttl = intval($result["ttl"]);
            $created_on = intval($result["created_on"]);
            $time_left = (time() - $created_on) - $ttl; //This will result in the negative value of seconds to live.

            if($time_left <= 0){
                $time_left = abs($time_left);

                //Calculate the new update time.
                    $new_time = time();

                    //If there are still 3 weeks left, reset it to four weeks.
                    if($time_left > (60*60*24*7*3)) $new_time += (60*60*24*7*4);

                    //If there is any more than a week left, ADD it for two weeks.
                    else if($time_left > (60*60*24*7)) $new_time += ((60*60*24*14) + $time_left);

                    //If the coockie has yet a week to live, renew it for another week.
                    else $new_time += (60*60*24*7);

                //Update the coockie
                $stmt = $con->prepare("UPDATE coockies SET time_to_die=?, created_on=?  WHERE coockie_id = '".$cid."'");
                $stmt->bind_param('ii', $new_time, time());
                $stmt->execute();

                //Check if the update went OK
                if($con->affected_rows !== 1) return false;

                //Close the connection if it was opened by the system
                if($server_connection === true) $con->close();

                //If the system has got to this point, this means that the coockie has been updated succesfully
                return true;
            } else return false;
        } else return false;
    } else return false;
} //BOOL

function purge_coockies($coockie_hash, $con = false){
    if($con === false) $server_connection = true;
    else $server_connection = false;

    if(!empty($coockie_hash)) {
        //Make sure a connection is active
        if ($con === false) {
            $con = make_mysql_connection();
            if ($con === false) return false;
        }

        //Trigger the deletions
        $stmt = $con->prepare("DELETE FROM coockies WHERE (time_to_die > ?)");
        $stmt->bind_param('i', time());
        $stmt->execute();

        //Close the connection if it was opened by the system
        if($server_connection === true) $con->close();

        //There is no way to check if only the right records were deleted, so return true.
        return true;
    } else return false;
} //BOOL

function delete_coockie($coockie_hash, $con = false){
    if($con === false) $server_connection = true;
    else $server_connection = false;

    if(!empty($coockie_hash)){
        //Make sure a connection is active
        if($con === false){
            $con = make_mysql_connection();
            if($con === false) return false;
        }

        //Get the DB results
        $stmt = $con->prepare("DELETE FROM coockies WHERE (coockie_hash = ?)");
        $stmt->bind_param('s', $coockie_hash);
        $stmt->execute();

        //Check if the update went OK
        if($con->affected_rows !== 1) return false;

        //Close the connection if it was opened by the system
        if($server_connection === true) $con->close();

        //If the system has got to this point, that means that it has succeeded it's goal.
        return true;
    } else return false;
} //BOOL

function update_last_logged_in($uid, $con = false){
    $data = array();
    $data["success"] = true;
    return $data;
}   //DATA