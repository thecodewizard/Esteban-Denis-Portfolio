<?php

/* CORE FUNCTIONS */

function send_email($receiver, $subject, $h2, $h3_array, $article_array)
{
    //Set Headers
    $to = htmlentities($receiver);
    $subject = htmlentities($subject);
    $headers = "MIME-Version: 1.0\r\n";
    $headers .= "Content-Type: text/html; charset=ISO-8859-1\r\n";
    $headers .= "From:no-reply@wheatley.com\r\n";

    //Make the message
    $message = "";
    $message = '
        <html>
            <body style="background-color: #0A2535;">
                <header style="background-color: #0A2535; display: block; width: 110%; margin: -10px; height: 100px;">
                    <h1 style="color: #2187e7; font-weight: bold; font-size: 3em; text-align: center; line-height: 100px; border-bottom: 1px #ff8525 solid;">Wheatley HomeSite Mail</h1>
                </header>
                <section>
                    <h2 style="display: block; text-align: center; color: #ff8525; font-size: 2.2em; margin: 50px 25px 75px; font-family: sans-serif; font-weight: lighter; border-bottom: 1px solid #ff8525;">';

    $message .= $h2;

    $message .= '</h2>';

    for ($i = 0; $i < count($h3_array); $i++) {
        $message .= "<article style='padding: 10px 50px; width: 100%; height: auto; display: inline-block;'>
                        <h3 style='color: #ff8525; font-size: 1.5em; font-weight: lighter; margin-bottom: 15px;'>" . $h3_array[$i] . "</h3>";

        $message .= "<p style='font-family: sans-serif; margin-bottom: 25px; font-size: 1.2em; color: darkgray;'>" . $article_array[$i] . "</p></article>";
    };

    $message .= "</section>";
    $message .= '<a href="http://estebandenis.ddns.net" style="color: #ff8525; text-decoration:none; background-color: #383838; border-top: 1px #ff8525 solid; border-bottom: 1px #ff8525 solid; font-size: 1.25em;
                    font-weight: bold; width: 100%; display: inline-block; text-align: center; padding: 10px 0;">Visit Wheatley Homesite</a>
            </body>
        </html>
    ';

    //Send The Mail
    if(mail($to, $subject, $message, $headers)) return true;
    else return false;
}

/* HELPER FUNCTIONS */
function send_thank_you_registration($receiver){
    //Check if the recepient exists in local database.
    if(!empty($receiver) && email_exists($receiver)){
        //Make the contents of the mail.
            //Subject and main title
        $subject = "Wheatley Welcomes You!";
        $h2 = "Thank you for your registration!";

            //Articles and their titles
        $h3 = array(); $articles = array();
        $h3[] = "Welcome on Wheatley. We're glad you're here!";
        $articles[] = "We are glad to see you subscribing to our site. Please, have a little patience. Our team will review your registration. When you've been approved, you'll receive an email from our dev-team with an activation link. Until then, keep refreshing your mail.";

        $h3[] = "WheatleyHomeSite... A Work in Progress...";
        $articles[] = "We at GLADOS workgroup know that technology is always moving on and that patience is rarely valued. But this site really is still under some serious development. I'd like to urge for your patience regarding the progress. For now, your application will be considered 'pre-registrated'. When your personal homepage has been developed by our overworked one-man dev-team, we'll look into activating your account. Untill then, i can only advise you to stay a frequent user of the site. </br>
            As a working team, we'd like to give you some relaxating tips in order to overcome that horrible period of unfinished wheatleys. Please have a seat, take a nice cup of tea and enjoy yourself with some relaxing music. Maybe, while you're at it, visit one of our esteemed parters. See the links on the website (click on the link below). A warm thank you is in place to our partners from the (not-that-massive)MMO.";

        $h3[] = "Ready? Set? Contact!";
        $articles[] = "Please, if you have any questions, seen any bugs or even if you're just very lonely, contact us! Now that our mailserver and html mail has been set up properly, we are ready to answer to all your needs. <br/> GLADOS at your service.";

        //Send confirmation to the administrator
        $title = array(); $paragraph = array();
        $title[] = "The recepient, ".$receiver." has received his thank you mail.";
        $paragraph[] = "The mail has been send at this date: ".date('d-m-Y H:i:s');
        send_email("wheatley@estebandenis.ddns.net", "New Registration", $receiver." has been emailed thanks", $title, $paragraph);

        //Send the mail to the newly registred user.
        return send_email($receiver, $subject, $h2, $h3, $articles);

    } else return false;
}