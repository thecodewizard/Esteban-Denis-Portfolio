<?php

echo "<!-- THIS HAS TO BE CLEANED THOUROUGHLY _ RUFF CODE BUT IT DOES THE JOB
    //My favorite quote of all times is to be applied on this:
    //'It's like using an atom bomb to keep the fox from killing your chickens.
    //You will succeed, the fox will be dead.
    //But so will be the chickens, ... and the entire neighbourhood.' -->";

include_once "./db_core/accounting.php";

if(session_status() !== PHP_SESSION_ACTIVE) { session_start(); }

if(isset($_SESSION["uid"]) || isset($_COOKIE["wheatley_remembers_user"])){

    //Delete all the coockies - from database and from clientside.
    if(isset($_COOKIE["wheatley_remembers_user"]) || isset($_COOKIE["wheatley_remembers_hash"])){

        delete_coockie(str_replace('%24', '$', ($_COOKIE["wheatley_remembers_hash"])));

        unset($_COOKIE["wheatley_remembers_user"]);
        unset($_COOKIE["wheatley_remembers_hash"]);
        setcookie("wheatley_remembers_user", null, 1, "/");
        setcookie("wheatley_remembers_hash", null, 1, "/");
    }

    //Delete all current sessions
    if(isset($_SESSION["uid"])){
        $_SESSION = array();
        $_SESSION["uid"] = null;
        session_destroy();
        session_unset();
        unset($_SESSION);
    }

    //Redirect to itself
    //Debug info
    print_r($_SESSION);
    print_r($_COOKIE);

    $_SESSION = array();
    header("location:../shared_php/logout.php");
    die;
} else {
    header("location:../shared_php/logout.php?redirect=true");
}

if(isset($_GET["redirect"])) header("location:../index.html");