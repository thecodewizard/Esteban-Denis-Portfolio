//Global Variables
    //Namespaces
var dashboard = dashboard || {};
var request = request ||{};
var shfe = shfe || {};
    //Caches and global variabels
var data_cache = [];
var clientSEQ = 0;

dashboard = {
    init: function(){
        //Bind the eventlisteners
            //HEADERBUTTONS
        browser_support.addEvent(document.getElementById("headerlogout"), "click", function(){shfe.logout_user();});
        browser_support.addEvent(document.getElementById("headerhome"), "click", function(){shfe.return_home();});
        if(document.getElementById("headerdashboard") != undefined) browser_support.addEvent(document.getElementById("headerdashboard"), "click", function(){shfe.return_dashboard();});
            //FLYERBUTTONS
        var linkcontainer = document.getElementById('flyer').getElementsByTagName('aside')[0].getElementsByTagName('div')[0].getElementsByTagName('div');
        for(var i=0; i<linkcontainer.length; i++){
            browser_support.addEvent(linkcontainer[i], 'click', function(event){dashboard.show_article(event);});
        }

        //Set the needed timers
        setInterval(function(){shfe.count_time()}, 1000);

        //Execute the needed functions
        dashboard.prepare_articles();

        //Acknowledge that the init has completed
        console.log("init executed.");
    },

    prepare_articles: function(){
        //Get the needed elements
        var elements = []; var article = document.getElementById('dashboard').getElementsByTagName('article');
        for(var ii=0; ii<article.length; ii++) elements.push(article[ii]);

        //Loop through all the found articles.
        var style = document.createElement('style'); style.textContent = "";
        for(var i=0; i<elements.length; i++){
            //Color the article
                //Get the colors from the HTML
                var color; var lightcolor;
                var parent = elements[i].parentNode;
                if(parent.hasAttribute('data-color' + parseInt(i + 1))) color = parent.getAttribute('data-color' + parseInt(i + 1));
                if(parent.hasAttribute('data-color' + parseInt(i + 1) + 'b')) lightcolor = parent.getAttribute('data-color' + parseInt(i + 1) + 'b');

                //Calcutate the linear colors
                var linear = 'linear-gradient(to right, transparent, ' + color + ', transparent)';
                var linear_angle = 'linear-gradient(45deg, ' + color + ', transparent)';

                //Color the h2
                elements[i].getElementsByTagName('h2')[0].style.borderBottom = "1px solid " + color;
                elements[i].getElementsByClassName('close')[0].style.borderColor = color;

            //Color the buttons
            var buttons = elements[i].getElementsByClassName('btn');
            for(var j=0; j<buttons.length; j++){
                if(buttons[j].className.indexOf('disabled') <= -1) buttons[j].style.background = linear;
            }

            //Set the hover over the buttons
            style.textContent += '#' + elements[i].id + ' .btn:hover{ background-color: ' + lightcolor + ' !important;}';
            style.textContent += '#' + elements[i].id + ' .close:hover{ background: ' + linear_angle + ' ;}';

            //Bind the close button on each article
            browser_support.addEvent(elements[i].getElementsByClassName('close')[0], "click", function(event){dashboard.hide_article(event);});
        }

        //Save the styles and elements.
        document.getElementsByTagName('body')[0].appendChild(style);
    },

    show_article: function(evt){
        //Get the needed id.
        var id = 'dashboard' + evt.target.id.substr(3);

        //Get the needed elements
        var element = document.getElementById(id);
        var aside = document.getElementById("dashboard").getElementsByTagName('aside')[0];

        //If present, remove the aside.
        if(!aside.hasAttribute('hidden')){
            aside.setAttribute('hidden', 'hidden');
            document.getElementById('dashboard').style.display = "block";
        }

        //Cut the article out and paste it at the top.
        var parent = element.parentNode;
        parent.removeChild(element);
        parent.insertBefore(element, parent.firstChild);

        //Change the display status
        element.style.display = "block";
    },

    hide_article: function(evt){
        //Get the needed id.
            //Check if the user clicked on the 'span' or on the 'div'
        var id;
        if(evt.target.className == 'close'){
            id = evt.target.parentNode.id;
        } else {
            id = evt.target.parentNode.parentNode.id;
        }

        //Get the needed element
        var element = document.getElementById(id);
        var aside = document.getElementById('dashboard').getElementsByTagName('aside')[0];

        //If needed, show the aside
        var alone = 0; var children = document.getElementById('dashboard').getElementsByTagName('article');
        for(var i=0; i<children.length; i++){
            if(children[i].style.display === 'block') alone++;
        }

        //If alone, show the aside
        if(aside.hasAttribute('hidden') && aside.getAttribute('hidden') == 'hidden' && alone == 1){
            aside.removeAttribute('hidden');
            document.getElementById('dashboard').style.display = "flex";
        }

        //Change the display status
        element.style.display = "none";
    }
};

request = {
    init: function(){
        //Bind the eventlisteners
            //HEADERBUTTONS
        browser_support.addEvent(document.getElementById("headerlogout"), "click", function(){shfe.logout_user();});
        browser_support.addEvent(document.getElementById("headerhome"), "click", function(){shfe.return_home();});
        if(document.getElementById("headerdashboard") != undefined) browser_support.addEvent(document.getElementById("headerdashboard"), "click", function(){shfe.return_dashboard();});

            //NEXT and PREV buttons
        for(var j=0; j<document.getElementById("add_request").getElementsByTagName('div')[0].getElementsByTagName('section').length; j++){
            for(var i=0; i<document.getElementById("add_request").getElementsByTagName('div')[0].getElementsByTagName('section')[j].getElementsByClassName('btn').length; i++){
                var button = document.getElementById("add_request").getElementsByTagName('div')[0].getElementsByTagName('section')[j].getElementsByClassName('btn')[i];
                if(button.hasAttribute('data-type')){
                    switch (button.getAttribute('data-type')){
                        case 'prev':
                            browser_support.addEvent(button, 'click', function(){request.previous_form();});
                            break;
                        case 'next':
                            browser_support.addEvent(button, 'click', function(){request.next_form();});
                    }
                }
            }
        }

            /* Counter */
        for(var ii= 0; ii<document.getElementById("counter").getElementsByTagName('div').length; ii++){
            browser_support.addEvent(document.getElementById('counter').getElementsByTagName('div')[ii], 'click', function(event){request.move_form(event);});
        }

            //Form Inputs
        browser_support.addEvent(document.getElementById('txt_link'), 'keydown', function(){request.check_step_one();});
        browser_support.addEvent(document.getElementById('txt_link'), 'click', function(){this.select();});
        browser_support.addEvent(document.getElementById('txt_file'), 'change', function(){request.check_step_one();});
        browser_support.addEvent(document.getElementById('btn_torrent'), 'click', function(){request.show_torrent_form();});
        browser_support.addEvent(document.getElementById('btn_link'), 'click', function(){request.show_link_form();});
        browser_support.addEvent(document.getElementById('button-step-one'), 'click', function(){request.check_step_two();});
        browser_support.addEvent(document.getElementById('button-step-two'), 'click', function(){request.check_step_three();});
        browser_support.addEvent(document.getElementById('button-step-three'), 'click', function(){request.check_step_four();});
        browser_support.addEvent(document.getElementById('cbo_types'), 'change', function(){document.getElementById('cbo_subtypes').selectedIndex = 0; request.check_step_two();});
        browser_support.addEvent(document.getElementById('cbo_subtypes'), 'change', function(){request.check_step_two();});
        browser_support.addEvent(document.getElementById('cbo_quality'), 'change', function(){request.check_step_three();});
        browser_support.addEvent(document.getElementById('txt_title'), 'keydown', function(){request.check_step_three();});
        browser_support.addEvent(document.getElementById('txt_artist'), 'keydown', function(){request.check_step_three();});
        browser_support.addEvent(document.getElementById('txt_album'), 'keydown', function(){request.check_step_three();});
        browser_support.addEvent(document.getElementById('txt_year_audio'), 'change', function(){request.check_step_three();});
        browser_support.addEvent(document.getElementById('txt_year_video'), 'change', function(){request.check_step_three();});
        browser_support.addEvent(document.getElementById('txt_serie'), 'keydown', function(){request.check_step_three();});
        browser_support.addEvent(document.getElementById('txt_season'), 'change', function(){request.check_step_three();});
        browser_support.addEvent(document.getElementById('txt_comments'), 'keydown', function(){request.check_step_four();});
        browser_support.addEvent(document.getElementById('chk_mail'), 'change', function(){request.check_step_four();});
        browser_support.addEvent(document.getElementById('btn_confirm'), 'click', function(){request.send_confirmation_request();});

        //Prepare the overlay
        request.prepare_add_request();

        //Acknowledge that the init has completed
        console.log("init executed.");
    },

    display_status: function(message){
        document.getElementById('status').textContent = message;
    },

    move_form: function(event){
        var sections = document.getElementById('add_request').getElementsByTagName('div')[0].getElementsByTagName('section');
        var target = event.target;
        var targetform = parseInt(target.getAttribute('data-number'));
        var currentform;

        //Get the current active window
        for(var i=0; i<sections.length; i++){
            if(sections[i].style.display == 'block'){
                currentform = i;
                break;
            }
        }

        //Scroll to the desired window
        if(currentform > targetform) do{
                request.previous_form();
                currentform--;
            } while(currentform > targetform);
    },

    prepare_add_request: function(){
        //Prepare the first section
        document.getElementById('add_request').getElementsByTagName('div')[0].getElementsByTagName('section')[0].style.display = "block";

        //Prepare the second step comboboxes
        var cbo = document.getElementById('cbo_subtypes').getElementsByTagName('option');
        for(var i=0; i<cbo.length; i++){
            cbo[i].style.display = 'none';
        }
        cbo[0].style.display = 'block';

    },

    previous_form: function(){
        var sections = document.getElementById('add_request').getElementsByTagName('div')[0].getElementsByTagName('section');
        var counter = document.getElementById('counter').getElementsByTagName('div');
        for(var i=0; i<sections.length; i++){
            if(sections[i].style.display == 'block' && i>0){
                sections[i-1].style.display = 'block';
                sections[i].style.display = 'none';

                //Let the counter move along
                counter[i-1].className = "active";
                counter[i].className = "";
                break;
            }
        }
    },

    next_form: function(){
        var sections = document.getElementById('add_request').getElementsByTagName('div')[0].getElementsByTagName('section');
        var counter = document.getElementById('counter').getElementsByTagName('div');
        for(var i=0; i<sections.length; i++){
            if(sections[i].style.display == 'block' && i<parseInt(sections.length - 1)){
                sections[i+1].style.display = 'block';
                sections[i].style.display = 'none';

                //Let the counter move along
                if(i < 3) counter[i+1].className = "active";
                counter[i].className = "";
                break;
            }
        }
    },

    show_link_form: function(){
        document.getElementById('link').style.display = "block";
        document.getElementById('torrent').style.display = 'none';
        document.getElementById("p_help").style.color = 'transparent';

        //when the user changes the form type, re-check the validation.
        request.check_step_one();
    },

    show_torrent_form: function(){
        document.getElementById('link').style.display = 'none';
        document.getElementById('torrent').style.display = 'block';
        document.getElementById("p_help").style.color = 'transparent';

        //when the user changes the form type, re-check the validation.
        request.check_step_one();
    },

    check_step_one: function(){
        //Prepare the data_cache to be written
        data_cache["saved_data"] = [];

        //Check the inputs of step one.
        //First, check if the user selected the .torrent or the link.
        var link = document.getElementById('link'); var torrent = document.getElementById("torrent");
        if(link.style.display == 'block'){
            var regex = /^(https?:\/\/)?([\da-z\.-]+)\.([a-z\.]{2,6})([\/\w \.-]*)*\/?$/;
            var match = regex.exec(document.getElementById('txt_link').value);

            //Set the button accordingly
            if(match){
                if(document.getElementById("txt_link").value.indexOf('torcache.net/torrent/') > 0){
                    if(document.getElementById('txt_link').value.indexOf('.torrent') > 0){
                        document.getElementById('button-step-one').className = 'btn';
                        data_cache["saved_data"]["link"] = document.getElementById('txt_link').value;
                    } else {
                        document.getElementById('button-step-one').className = 'btn disabled';
                    }
                } else {
                    document.getElementById('button-step-one').className = 'btn disabled';
                }
            } else {
                document.getElementById('button-step-one').className = 'btn disabled';
            }
        } else {
            var filename = document.getElementById('txt_file').value;
            if(filename.indexOf('.torrent') > 0){
                document.getElementById('button-step-one').className = 'btn';
                data_cache["saved_data"]["torrent"] = document.getElementById('txt_file').files[0];
            } else {
                document.getElementById('button-step-one').className = 'btn disabled';
            }
        }
    },

    check_step_two: function(){
        //Save the needed variables
        var types = document.getElementById('cbo_types');
        var subtypes = document.getElementById('cbo_subtypes');

        //Manage the content of step two.
        var selected = types.options[types.selectedIndex];
        if(selected.hasAttribute('value')) var value = selected.getAttribute('value');

        for(var i=0; i<subtypes.options.length; i++){
            if(subtypes.options[i].hasAttribute('data-type')){
                if(subtypes.options[i].getAttribute('data-type') == value) subtypes.options[i].style.display = 'block';
                else subtypes.options[i].style.display = 'none';
            } else subtypes.options[i].style.display = 'none';
        }

        //Check the inputs of step two.
        if(types.selectedIndex > 0 && subtypes.selectedIndex > 0){
            if(types.options[types.selectedIndex] != undefined && subtypes.options[subtypes.selectedIndex] != undefined) document.getElementById('button-step-two').className = 'btn';
            else document.getElementById('button-step-two').className = 'btn disabled';
        }
        else document.getElementById('button-step-two').className = 'btn disabled';

        //Save the values
        data_cache["data-type"] = types.options[types.selectedIndex].value;
        data_cache["data-subtype"] = subtypes.options[subtypes.selectedIndex].value;

        //If deemed correct, save the input
        if(document.getElementById('button-step-two').className == 'btn'){
            data_cache["saved_data"]["type"] = types.options[types.selectedIndex].value;
            data_cache["saved_data"]["subtype"] = subtypes.options[subtypes.selectedIndex].value;
        }
    },

    check_step_three: function(){
        //Save the needed variables
        var articles = document.getElementById('add_request').getElementsByTagName('div')[0].getElementsByTagName('section')[2].getElementsByTagName('form')[0].getElementsByTagName('article');

        //Get the elements
        var title = document.getElementById('txt_title');
        var artist = document.getElementById('txt_artist');
        var album = document.getElementById('txt_album');
        var audio_year = document.getElementById('txt_year_audio');
        var quality = document.getElementById('cbo_quality');
        var video_year = document.getElementById('txt_year_video');
        var serie = document.getElementById('txt_serie');
        var season = document.getElementById('txt_season');

        //Manage the content of step three.
        document.getElementById('txt_title').style.display = 'block';
        for (var i = 0; i < articles.length; i++) {
            if (articles[i].hasAttribute('data-type')) {
                if (articles[i].getAttribute('data-type') === data_cache["data-type"]) {
                    //display the article itself
                    articles[i].style.display = 'block';

                    //Check for subtype filtering
                    var divs = articles[i].getElementsByTagName('div');
                    for (var j = 0; j < divs.length; j++) {
                        if (divs[j].hasAttribute('data-subtype')) {
                            if(divs[j].getAttribute('data-subtype') == data_cache['data-subtype']) divs[j].style.display = 'block';
                            else divs[j].style.display = 'none';
                        }
                    }
                } else articles[i].style.display = 'none';
            } else articles[i].style.display = 'none';
        }

        //Check the input
        var valid = true;
        if (title.offsetHeight > 0) if (title.value == '') valid = false;
        if (artist.offsetHeight > 0) if (artist.value == '') valid = false;
        if (album.offsetHeight > 0) if (album.value == '') valid = false;
        if (serie.offsetHeight > 0) if (serie.value == '') valid = false;

        if (audio_year.offsetHeight > 0) if (audio_year.value == '') valid = false;
        if (audio_year.offsetHeight > 0) if (audio_year.value != parseInt(audio_year.value)) valid = false;
        if (video_year.offsetHeight > 0) if (video_year.value == '') valid = false;
        if (video_year.offsetHeight > 0) if (video_year.value != parseInt(video_year.value)) valid = false;
        if (season.offsetHeight > 0) if (season.value == '') valid = false;
        if (season.offsetHeight > 0) if (season.value !== parseInt(season.value)) valid = false;

        if (quality.offsetHeight > 0) if (quality.selectedIndex <= 0 || quality.options[quality.selectedIndex].value == '') valid = false;

        //Validate the outcome
        if (valid) document.getElementById('button-step-three').className = 'btn';
        else document.getElementById('button-step-three').className = 'btn disabled';

        //Save the data
        if(valid){
            if (title.offsetHeight > 0) if (title.value !== '') data_cache["saved_data"]["title"] = title.value;
            if (artist.offsetHeight > 0) if (artist.value !== '') data_cache["saved_data"]["artist"] = artist.value;
            if (album.offsetHeight > 0) if (album.value !== '') data_cache["saved_data"]["album"] = album.value;
            if (serie.offsetHeight > 0) if (serie.value !== '') data_cache["saved_data"]["serie"] = serie.value;
            if (audio_year.offsetHeight > 0) if (audio_year.value !== '') data_cache["saved_data"]["year"] = audio_year.value;
            if (video_year.offsetHeight > 0) if (video_year.value !== '') data_cache["saved_data"]["year"] = video_year.value;
            if (season.offsetHeight > 0) if (season.value !== '') data_cache["saved_data"]["season"] = season.value;
            if (quality.offsetHeight > 0) if (quality.selectedIndex <= 0 || quality.options[quality.selectedIndex].value == '') data_cache["saved_data"]["quality"] = quality.options[quality.selectedIndex].value;
        }
    },

    check_step_four: function(){
        //Get the variables
        var comments = document.getElementById("txt_comments");

        //Save the variables from step 4
        if(comments.textContent.length < 1000) data_cache["saved_data"]["comments"] = comments.value;

        //Get and recheck all variables.
        var valid = true;
        for(var i=0; i<data_cache["saved_data"].length; i++){
            if(data_cache["saved_data"][i] == '') valid = false;
        }

        if(valid) document.getElementById('btn_confirm').className = 'btn';
        else document.getElementById('btn_confirm').className = 'btn disabled';

        //Check Step 4.
        var comments = document.getElementById('txt_comments');
        if(comments.textContent.length > 1000) document.getElementById('btn_confirm').className = 'btn disabled';
    },

    send_confirmation_request: function(){
        //Clear the old datacache
        data_cache["http"] = "";

        //Get the data
        var seq = 1; clientSEQ = 1; //This is the first request to be send out

        //Prepare variables
        var file_upload; var file_info;
        if(data_cache["saved_data"]["torrent"] != undefined && data_cache["saved_data"]["link"] == undefined){
            file_upload = true;
            var file_array = {
                "name": data_cache["saved_data"]["torrent"].name,
                "size": data_cache["saved_data"]["torrent"].size,
                "lastModified": data_cache["saved_data"]["torrent"].lastModified,
                "raw": data_cache["saved_data"]["torrent"]};
            file_info = JSON.stringify(file_array);
        } else {
            file_upload = false;
            file_info = data_cache["saved_data"]["link"];
        }
        var mail = false;
        if(document.getElementById('chk_mail').checked) mail = true;

        //Prepare the data for transfer
        var data = {"SEQ": seq, "File_upload": file_upload, "File_info": file_info, "Type": data_cache["saved_data"]["type"], "Subtype": data_cache["saved_data"]["subtype"],
         "Title": data_cache["saved_data"]["title"], "Comments": data_cache["saved_data"]["comments"], "Mail": mail,
         "Artist": data_cache["saved_data"]["artist"], "Album": data_cache["saved_data"]["album"], "Serie": data_cache["saved_data"]["serie"],
            "Year": data_cache["saved_data"]["year"], "Season": data_cache["saved_data"]["season"], "Quality": data_cache["saved_data"]["quality"]}
        var json = JSON.stringify(data);

        //Save the data in cache
        data_cache["http"] = json;

        //Send the contact Request
        clientSEQ++;
        xhr.sendXHR('post', './../http/users/http_addrequest.php', json, function(response){request.parse_confirmation_response(response);}, function(message){request.display_status(message);});
        console.log(data);
    },

    parse_confirmation_response: function(response){
        //Unpack the response
        var data = null;
        try{
            data = JSON.parse(response);
        } catch(ex) {
            //Due to lack of data, guess a next ServerSEQ
            var currentSEQ = parseInt(data_cache["http"].SEQ);
            var estimated_server_SEQ  = currentSEQ + 1;

            console.log("No Response Received.");
            console.log(response);

            request.retry_confirmation_request(estimated_server_SEQ);
        }

        //Check if the complete response is received
        if((data != null) && (data.hasOwnProperty("SEQ") && data.hasOwnProperty("Success")))
        {
            if(data.Success = "true"){
                if(data.hasOwnProperty('Eid')){
                    //Now the data has been injected properly, start the upload.
                    request.display_status("Server generated clearance codes. Upload imminent.");
                    document.getElementById("txt_eid").value = data.Eid;
                    setTimeout(function(){document.getElementById("torrent").submit();}, 2000);
                }
            } else {
                request.retry_confirmation_request(data_cache["http"].SEQ);
            }
        }
    },

    retry_confirmation_request: function(serverSEQ){
        if(serverSEQ == clientSEQ){
            //Check whether the SEQ isn't overwriting the maximum retry attempts
            if (serverSEQ > 10) {
                request.display_status("REQUEST FAILED. Please close this window and try again.");
            } else {
                //Display Status
                request.display_status('Request Failed. Retrying...');

                //Validate serverSEQ
                if (serverSEQ != parseInt(serverSEQ)) {
                    serverSEQ = 10;
                }

                //Get the data
                var data = JSON.parse(data_cache["http"]);
                data.SEQ = serverSEQ;
                var json = JSON.stringify(data);
                data_cache["http"] = json;

                //Retry the request
                clientSEQ++;
                if (json != "undefined") xhr.sendXHR('post', './../http/users/http_addrequest.php', json, function (response) {
                    request.parse_confirmation_response(response);
                });
            }
        } else {
            //Safety precaution, set the client SEQ double as the server SEQ
            if(clientSEQ > 20){
                request.display_status("REQUEST FAILED. Please close this window and try again.");
            } else {
                request.retry_confirmation_request(clientSEQ);
            }
        }
    }
};

shfe = {
    //Shared Header Features
    logout_user: function(){
        window.location.href = "../../shared_php/logout.php";
    },

    return_home: function(){
        window.location.href = "../../index.html";
    },

    return_dashboard: function(){
        window.location.href = "./index.php";
    },

    count_time: function(){
        //Get the needed elements
        var timer = document.getElementById("currenttime");

        //Set the timer
        var d = new Date();
        timer.innerHTML = d.toLocaleTimeString();
    }
};