var animation_allowed = false;
var retry_allowed = false;
var scroll_lock = false;
var ftregister = function(){landing.show_register();};
var ftlogin = function(){landing.show_log_in();};
var datacache; var timecache;  var clientSEQ; var open_element = "";

var landing =  {
    init: function () {
        //Execute the needed functions
        landing.position_aside();
        timecache = "allowed";

        //Check for request to show sponsoring
        if(browser_support.getParameterByName('about') === "more") landing.toggle_about();

        //Assign the eventhandlers
            //Frontpage
        browser_support.addEvent(window, 'deviceorientation', function(){landing.improveResponsiveness();});
        browser_support.addEvent(window, 'resize', function(){landing.viewport_changed_handler();});
        browser_support.addEvent(window, 'scroll', function(){landing.viewport_changed_handler();});
        browser_support.addEvent(document.getElementById('headerlogin'), 'click', ftlogin);
        browser_support.addEvent(document.getElementById('bannerlogin'), 'click', ftregister);
        browser_support.addEvent(document.getElementById('headercontact'), 'click', function(){landing.show_contact();});
        browser_support.addEvent(document.getElementById('footercontact'), 'click', function(){landing.show_contact();});
        browser_support.addEvent(document.getElementById('ref_register'), 'click', ftregister);
        browser_support.addEvent(document.getElementById('toggle_details'), 'click', function(){landing.toggle_about();});
            //Forms
        browser_support.addEvent(document.getElementById('txt_username'), 'keyup', function(){landing.check_login_input();});
        browser_support.addEvent(document.getElementById('txt_password'), 'keyup', function(){landing.check_login_input();});
        browser_support.addEvent(document.getElementById('txt_sender'), 'keyup', function(){landing.check_contact_input();});
        browser_support.addEvent(document.getElementById('txt_subject'), 'keyup', function(){landing.check_contact_input();});
        browser_support.addEvent(document.getElementById('txt_message'), 'keydown', function(){landing.check_contact_input();});
        browser_support.addEvent(document.getElementById('txt_reg_username'), 'keyup', function(){landing.check_registration_input();});
        browser_support.addEvent(document.getElementById('txt_reg_password'), 'keyup', function(){landing.check_registration_input();});
        browser_support.addEvent(document.getElementById('txt_reg_password_check'), 'keyup', function(){landing.check_registration_input();});
        browser_support.addEvent(document.getElementById('txt_reg_email'), 'keyup', function(){landing.check_registration_input();});
        browser_support.addEvent(document.getElementById('close'), 'click', function(){landing.hide_overlay();});
            //XHR buttons
        browser_support.addEvent(document.getElementById('btn_login'), 'click', function(event){landing_http_handler.send_login_request(event)});
        browser_support.addEvent(document.getElementById('btn_send'), 'click', function(event){landing_http_handler.send_contact_request(event)});
        browser_support.addEvent(document.getElementById('btn_register'), 'click', function(event){landing_http_handler.send_register_request(event);});

        //Check if there are user credentials present
            //Use a timeout to simulate an asynchronous function
        setTimeout(function() {landing_http_handler.send_remember_request();}, 1);

            //Acknowledge the init
        console.log("init executed");
    },

    improveResponsiveness: function(){
        if((parseInt(window.innerWidth) > parseInt(window.innerHeight)) && (parseInt(window.innerHeight) < 400)) {
            if((parseInt(window.scrollX) == 0) && (scroll_lock == false)) {
                scroll_lock = true;
                animations.scrollDown(0, 100);
            }
        }
    },

    stop_loadicon: function(){
        //Stop the loading icon
        document.getElementById('processing').getElementsByClassName('loadicon')[0].className = "loadicon stop";
    },

    prepare_overlay: function(){
        landing.hide_overlay();
        document.getElementsByTagName('body')[0].className = "scroll_lock";
        document.getElementById('overlay').style.display = "block";
    },

    show_success: function(){
        landing.prepare_overlay();
        document.getElementById('message_success').style.display = 'block';
        landing.position_close('message_success');
    },

    show_processing: function(){
        landing.prepare_overlay();
        document.getElementById('processing').style.display = "block";
        document.getElementById('processing').getElementsByTagName('div')[0].className = "loadicon";
        landing.position_close('processing');

        retry_allowed = true;
        animation_allowed = true;
    },

    show_log_in: function(){
        landing.prepare_overlay();
        document.getElementById('login').removeAttribute('hidden');
        landing.position_close('login');

        animation_allowed = true;
        animations.init();

        landing.check_login_input();
    },

    show_contact: function(){
        landing.prepare_overlay();
        document.getElementById('contact').removeAttribute('hidden');
        landing.position_close('contact');

        animation_allowed = true;
        animations.init();
    },

    show_register: function(){
        landing.prepare_overlay();
        document.getElementById('register').removeAttribute('hidden');
        landing.position_close('register');

        animation_allowed = true;
        animations.init();
    },

    hide_overlay: function(){
        document.getElementsByTagName('body')[0].className = "";
        document.getElementById("overlay").style.display = "none";
        document.getElementById('processing').style.display = "none";
        document.getElementById('message_success').style.display = "none";
        document.getElementById('login').setAttribute('hidden', 'hidden');
        document.getElementById('contact').setAttribute('hidden', 'hidden');
        document.getElementById('register').setAttribute('hidden', 'hidden');

        open_element = "";
        animation_allowed = false;
        retry_allowed = false;
    },

    position_aside: function () {
        var decorations = document.getElementsByClassName('par');
        for(var i=0;i<decorations.length;i++){
            var other = decorations[i].parentNode.getElementsByTagName('article')[0];
            landing.set_center(decorations[i], other);
            landing.set_equal_ratio(decorations[i]);
        }
    },

    position_overlay: function (){
        var overlay_children = document.getElementById("overlay").getElementsByTagName('div');
        for(var i=0; i< overlay_children.length; i++){
            var child = overlay_children[i];
            if(child.id == open_element){
                //Get data
                var height_child = parseInt(child.clientHeight);
                var totalheight = parseInt(window.innerHeight);
                var margin = parseInt(parseInt(totalheight-height_child)/2);

                //Do not set negative margins
                if(margin < 5) margin = 5;

                //Set data
                child.style.marginTop = margin + "px";
                child.style.marginBottom = margin + "px";

                //Reset the animation
                var anim = document.getElementById("loading_animation");
                anim.style.marginTop = margin + "px";
                anim.style.marginBottom = margin + "px";
            }
        }
    },

    position_close: function(opened_element) {
        //Wait a few milliseconds in order for the html renderer to make up the element that has to be positioned here
        setTimeout(function(){

            //Set the opened element for future reference
            open_element = opened_element;

            //Position the entire overlay
            landing.position_overlay();

            //Get the dimentions
            var overlay = document.getElementById(opened_element);
            var left = parseInt(overlay.offsetLeft);
            var width = parseInt(overlay.offsetWidth);
            var top = parseInt(overlay.offsetTop);

            //Position the element
            var close = document.getElementById("close");
            close.style.left = parseInt(parseInt(left + width) - 50) + "px";
            close.style.top = parseInt(top + 10) + "px";

        }, 10);
    },

    toggle_about: function(){
        //Get current status
        var details = document.getElementById("about_left");
        var sponsors = document.getElementById("about_right");
        var btn = document.getElementById("toggle_details");

        if(details.hasAttribute("hidden")){
            //Make the details visible
            details.removeAttribute('hidden');
            sponsors.removeAttribute('hidden');

            //Change the text of the a.
            btn.textContent = "Hide Details";

        } else {
            //Hide the details
            details.setAttribute("hidden", "hidden");
            sponsors.setAttribute('hidden', 'hidden');

            //Change the text of the a.
            btn.textContent = "Show Details";
        }
    },

    set_equal_ratio: function(parent){
        var subject = parent.getElementsByTagName('div')[0];
        var width = parseInt(subject.offsetWidth);
        subject.style.height = width + "px";
    },

    set_center: function(subject, other){
        var deltaX = parseInt(parseInt(other.offsetHeight) - parseInt(subject.offsetHeight));
        if(deltaX < 0){
            other.style.marginTop = parseInt((-deltaX)/2) + "px";
        } else {
            subject.style.marginTop = parseInt(deltaX/2) + "px";
        }
    },

    viewport_changed_handler: function(){
        //Get the needed data
        var scrlpos = parseInt(window.scrollY);

        //Determine the action
            //For each resize, recalculate the images.
        landing.position_aside();
        if(open_element != "") landing.position_close(open_element);

            //When scrolling 'under' the picture, change the theme of the header
        if(scrlpos < 325){
            document.getElementsByTagName('header')[0].className = "";
        } else {
            document.getElementsByTagName('header')[0].className = "light";
        }
    },

    check_login_input: function(){
        //Get the needed elements
        var parent = document.getElementById('login');
        var username = document.getElementById('txt_username');
        var password = document.getElementById('txt_password');

        var lblusername = document.getElementById('lbl_username');
        var lblpassword = document.getElementById('lbl_password');

        //Make the error messages:
        var username_error = "";
        var password_error = "";


        //Check the subject
        if(username.value.length <= 2){
            username_error = "Username too short";
        } else if (username.value.length >= 100){
            username_error = "Username too long";
        }

        //Check message
        if(password.value.length <= 2){
            password_error = "Password too short.";
        } else if (password.value.length >= 100){
            password_error = "Password too long";
        }

        //Validation
        if(username_error != ""){
            lblusername.textContent = username_error;
            parent.getElementsByTagName('form')[0].getElementsByTagName('div')[0].className = "error";
        } else {
            lblusername.textContent = "Username";
            parent.getElementsByTagName('form')[0].getElementsByTagName('div')[0].className = "";
        }

        if(password_error != ""){
            lblpassword.textContent = password_error;
            parent.getElementsByTagName('form')[0].getElementsByTagName('div')[1].className = "error";
        } else {
            lblpassword.textContent = "Password";
            parent.getElementsByTagName('form')[0].getElementsByTagName('div')[1].className = "";
        }

        //Check for username availability
        landing_http_handler.send_usercheck_request('txt_username');

        if(username_error == "" && password_error == ""){
            document.getElementById('btn_login').className = "btn";
        } else {
            document.getElementById('btn_login').className = "btn disabled";
        }
    },

    check_contact_input: function(){
        //Get the needed elements
        var parent = document.getElementById('contact');
        var email = document.getElementById('txt_sender');
        var subject = document.getElementById('txt_subject');
        var message = document.getElementById('txt_message');

        var lblemail = document.getElementById('lbl_sender');
        var lblsubject = document.getElementById('lbl_subject');
        var lblmessage = document.getElementById('lbl_message');

        //Make the error messages:
        var email_error = "";
        var subject_error = "";
        var message_error = "";

        //Check the email
        if(email.value.length <= 2){
            email_error = "Email too short";
        } else if (email.value.length >= 100) {
            email_error = "Email too long";
        } else {
            var regex = /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/;
            var email_valid = regex.test(email.value);
            if(email_valid == false){
                email_error = "Email doesn't comply. Check your input.";
            }
        }

        //Check the subject
        if(subject.value.length <= 2){
            subject_error = "Subject too short";
        } else if (subject.value.length >= 100){
            subject_error = "Subject too long.";
        }

        //Check message
        if(message.value.length <= 10){
            message_error = "Message too short.";
        } else if (message.value.length >= 10000){
            message_error = "Message too long.";
        }

        //Validation
        if(email_error != ""){
            lblemail.textContent = email_error;
            parent.getElementsByTagName('form')[0].getElementsByTagName('div')[0].className = "error";
        } else {
            lblemail.textContent = "Your E-Mailadress";
            parent.getElementsByTagName('form')[0].getElementsByTagName('div')[0].className = "";
        }

        if(subject_error != ""){
            lblsubject.textContent = subject_error;
            parent.getElementsByTagName('form')[0].getElementsByTagName('div')[1].className = "error";
        } else {
            lblsubject.textContent = "Subject";
            parent.getElementsByTagName('form')[0].getElementsByTagName('div')[1].className = "";
        }

        if(message_error != ""){
            lblmessage.textContent = message_error;
            parent.getElementsByTagName('form')[0].getElementsByTagName('div')[2].className = "error";
        } else {
            lblmessage.textContent = "Your Message";
            parent.getElementsByTagName('form')[0].getElementsByTagName('div')[2].className = "";
        }

        if(email_error == "" && subject_error == "" && message_error == ""){
            document.getElementById('btn_send').className = "btn";
        } else {
            document.getElementById('btn_send').className = "btn disabled";
        }
    },

    check_registration_input: function(){
        //Get the needed elements
        var parent = document.getElementById('register');
        var username = document.getElementById('txt_reg_username');
        var password = document.getElementById('txt_reg_password');
        var password_check = document.getElementById('txt_reg_password_check');
        var email = document.getElementById('txt_reg_email');

        var lblusername = document.getElementById('lbl_reg_username');
        var lblpassword = document.getElementById('lbl_reg_password');
        var lbl_password_check = document.getElementById('lbl_reg_password_check');
        var lbl_email = document.getElementById('lbl_reg_email');

        //Make the error messages:
        var username_error = "";
        var password_error = "";
        var password_check_error = "";
        var email_error = "";

        //Check the subject
        if(username.value.length <= 2){
            username_error = "Username too short";
        } else if (username.value.length >= 100){
            username_error = "Username too long";
        }

        //Check message
        if(password.value.length <= 2){
            password_error = "Password too short.";
        } else if (password.value.length >= 100){
            password_error = "Password too long";
        }

        //Check the password check match
        if(password.value.length == password_check.value.length){
            if(password.value != password_check.value) password_check_error = "The passwords doesn't match";
        } else {
            password_check_error = "The passwords doesn't match";
        }

        //Check the email
        if(email.value.length <= 2){
            email_error = "Email too short";
        } else if (email.value.length >= 100) {
            email_error = "Email too long";
        } else {
            var regex = /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/;
            var email_valid = regex.test(email.value);
            if(email_valid == false){
                email_error = "Email doesn't comply. Check your input.";
            }
        }

        //Validation
        if(username_error != ""){
            lblusername.textContent = username_error;
            parent.getElementsByTagName('form')[0].getElementsByTagName('div')[0].className = "error";
        } else {
            lblusername.textContent = "Username";
            parent.getElementsByTagName('form')[0].getElementsByTagName('div')[0].className = "";
        }

        if(password_error != ""){
            lblpassword.textContent = password_error;
            parent.getElementsByTagName('form')[0].getElementsByTagName('div')[1].className = "error";
        } else {
            lblpassword.textContent = "Password";
            parent.getElementsByTagName('form')[0].getElementsByTagName('div')[1].className = "";
        }

        if(password_check_error != ""){
            lbl_password_check.textContent = password_check_error;
            parent.getElementsByTagName('form')[0].getElementsByTagName('div')[2].className = "error";
        } else {
            lbl_password_check.textContent = "Confirm Password";
            parent.getElementsByTagName('form')[0].getElementsByTagName('div')[2].className = "";
        }

        if(email_error != ""){
            lbl_email.textContent = email_error;
            parent.getElementsByTagName('form')[0].getElementsByTagName('div')[3].className = "error";
        } else {
            lbl_email.textContent = "Your E-Mailadress";
            parent.getElementsByTagName('form')[0].getElementsByTagName('div')[3].className = "";
        }

        //Check for username availability
        landing_http_handler.send_usercheck_request('txt_reg_username');

        if(username_error == "" && password_error == "" && password_check_error == "" && email_error == ""){
            document.getElementById('btn_register').className = "btn";
        } else {
            document.getElementById('btn_register').className = "btn disabled";
        }
    },
    
    login: function (username, last_logged_in, permission) {
        //This function transforms the page to meet the new logged-in user's demand.

        //Welcome the user by his name.
        var title = document.getElementsByTagName('h1')[0];
        title.textContent = title.textContent.replace('you', username);

        //When on desktop, show username and permission in the head.
        var continue_text = "";
        if(parseInt(window.innerWidth) > 1500){
            var head = document.getElementsByTagName('header')[0].getElementsByTagName('p')[0];
            head.textContent = head.textContent + " - " + username + " (" + permission + ")";
            continue_text = "Continue to the User pages";
        } else continue_text = "Continue";

        //Change the big center button to a continue button
        var banner_button = document.getElementById("bannerlogin");
        banner_button.textContent = continue_text;
        banner_button.removeEventListener('click', ftregister);
        browser_support.addEvent(banner_button, 'click', function(){window.location.href = "./users/index.php";});

        //Add a log out button in the head.
        var header_button = document.getElementById("headerlogin");
            if(parseInt(window.innerWidth) < 980){
                //On mobile, change the login button to logout.
                header_button.textContent = "logout";
                header_button.removeEventListener('click', ftlogin);
                browser_support.addEvent(header_button, 'click', function(){window.location.href = "./shared_php/logout.php";});
                document.getElementsByTagName('body')[0].className += "headerlogout";

            } else {
                //On desktop, add a logout button and change the login button to continue
                var header = document.getElementsByTagName("header")[0];
                var button = document.createElement('div');
                browser_support.addEvent(button, 'click', function(){window.location.href = './shared_php/logout.php'});
                button.className = "btn";
                button.textContent = "Logout";
                button.id = "headerlogout";
                header.insertBefore(button, header.childNodes[0]);

                header_button.textContent = "Continue";
                header_button.removeEventListener('click', ftlogin);
                browser_support.addEvent(header_button, 'click', function(){window.location.href = "./users/index.php";});
            }
    }
};

var animations = {
    init: function(){
        //Check allowance
        if(!animation_allowed) return;

        //Check processing status
        var processing;
        if(document.getElementById('processing').style.display == "none") processing = false;
        else processing = true;

        //Get the needed elements
        var anim = document.getElementById('loading_animation');
        var login = document.getElementById('login');
        var contact = document.getElementById('contact');
        var register = document.getElementById('register');

        //Set for start
        animations.reset(anim);

        //Start the animation
        var pos = parseInt(anim.style.top);
        var speed; var max;
        if(login.hasAttribute("hidden") == false){
            max = parseInt(login.offsetHeight);
            if(isNaN(max)) max = parseInt(login.style.height);
            speed = 5;
        } else if (contact.hasAttribute("hidden") == false){
            max = parseInt(contact.offsetHeight);
            if(isNaN(max)) max = parseInt(contact.style.height);
            speed = 50;
        } else if (register.hasAttribute("hidden") == false){
            max = parseInt(register.offsetHeight);
            if(isNaN(max)) max = parseInt(register.style.height);
            speed = 10;
        }

        if(processing){
            processing = document.getElementById('processing');
            speed = 25;
            max = parseInt(processing.offsetHeight);
            if(isNaN(max)) max = parseInt(processing.style.height);
        }

        //Start the animation
        animations.move_down(anim, pos, max, speed);

        //Acknowledge Startup
        console.clear();
        console.log("animation started");
    },

    move_down: function(anim, pos, max, speed_in_ms){
        var newpos = parseInt(pos + 1);
        if(newpos <= eval(max - 100)){
            anim.style.top = newpos + "px";
            if(animation_allowed) setTimeout(function(){animations.move_down(anim, newpos, max, speed_in_ms);}, speed_in_ms);
        } else {
            if(animation_allowed) animations.move_up(anim, pos, speed_in_ms);
        }
    },

    move_up: function(anim, pos, speed_in_ms){
        var newpos = parseInt(pos - 1);
        if(newpos > 0){
            anim.style.top = newpos + "px";
            if(animation_allowed) setTimeout(function(){animations.move_up(anim, newpos, speed_in_ms)}, speed_in_ms);
        } else {
            animations.init();
        }
    },

    scrollDown: function(height, Goal){
        if(height <= Goal){
            window.scrollTo(0, height);
            setTimeout(function(){animations.scrollDown(height + 2, Goal);}, 5);
        }
    },

    reset: function(anim){
        //Set the div ready
        var border = "1px #ff8525 solid";
        anim.style.border = "0";
        anim.style.borderLeft = border;
        anim.style.borderRight = border;
        anim.style.height = 100 + "px";
        anim.style.zIndex = -10;
        anim.style.minHeight= 50 + "px";
        anim.style.boxSizing = "border-box";

        //Make the div invisible
        anim.style.background = "none";

        //Set the div in the correct place
        anim.style.position = "absolute";
        anim.style.top = 0;
        anim.style.left = 0;
    }
};

var landing_http_handler = landing_http_handler || {};
landing_http_handler = {
    display_status: function(status){
        document.getElementById('status').textContent = status;
    },

    send_contact_request: function(evt){
        //Check if this form is requested legally
        if(evt.target.id === "btn_send"){
            //Show the processing interface
            landing_http_handler.display_status("Contacting Server");
            landing.show_processing();

            //Clear the old cache
            datacache = "";

            //Get the data
            var seq = 1; clientSEQ = 1;   //This is the first request to be send out
            var sender = document.getElementById('txt_sender').value;
            var subject = document.getElementById('txt_subject').value;
            var message = document.getElementById('txt_message').value;

            //Prepare the data for transfer
            var data = {"SEQ":seq, "sender": sender, "subject": subject, "message": message};
            var json = JSON.stringify(data);

            //Save the data in cache
            datacache = json;

            //Send the contact Request
            clientSEQ++;
            xhr.sendXHR('post', './http/http_contact.php', json, function(response){landing_http_handler.parse_contact_response(response);}, function(status){landing_http_handler.display_status(status);});
        }
    },

    parse_contact_response: function(response){
        //Unpack the response
        var data = null;
        try{
            data = JSON.parse(response);
        } catch(ex) {
            //Due to lack of data, guess a next ServerSEQ
            var currentSEQ = parseInt(datacache.SEQ);
            var estimated_server_SEQ  = currentSEQ + 1;

            console.log("No Response Received.");
            console.log(response);

            landing_http_handler.retry_contact_request(estimated_server_SEQ);
        }

        //Check if the complete response is received
        if((data != null) && (data.hasOwnProperty("SEQ") && data.hasOwnProperty("Success")))
        {
            //Check whether the data is successfull
                if(data.Success == "true"){
                    //Stop the loading icon
                    landing.stop_loadicon();

                    //Show the success page
                    landing_http_handler.display_status("Message Saved To Database");
                    landing.show_success();

                    //Clear values for next messages
                    document.getElementById("txt_sender").value = "";
                    document.getElementById("txt_subject").value = "";
                    document.getElementById("txt_message").value = "";

                    //Clear the cache
                    datacache = "";
                } else {
                    landing_http_handler.retry_contact_request(data.SEQ);
                    console.log(data.Message);
                }
        }
        else{
            //Due to lack of data, guess a next ServerSEQ
            var currentSEQ = parseInt(datacache.SEQ);
            var estimated_server_SEQ  = currentSEQ + 1;
            landing_http_handler.retry_contact_request(estimated_server_SEQ);
        }
    },

    retry_contact_request: function(serverSEQ){
        //Check whether retry is allowed or not
        if(retry_allowed) {
            if(serverSEQ == clientSEQ){
                //Check whether the SEQ isn't overwriting the maximum retry attempts
                if (serverSEQ > 10) {
                    landing_http_handler.display_status("REQUEST FAILED. Please close this window and try again.");
                    landing.stop_loadicon();
                } else {
                    //Display the status
                    landing_http_handler.display_status('Request Failed. Retrying...');

                    //Validate serverSEQ
                    if (serverSEQ != parseInt(serverSEQ)) {
                        serverSEQ = 10;
                    }

                    //Get the data
                    var data = JSON.parse(datacache);
                    data.SEQ = serverSEQ;
                    var json = JSON.stringify(data);
                    datacache = json;

                    //Retry the request
                    clientSEQ++;
                    if (json != "undefined") xhr.sendXHR('post', './http/http_contact.php', json, function (response) {
                        landing_http_handler.parse_contact_response(response);
                    });
                }
            } else {
                //Safety precaution, set the client SEQ double as the server SEQ
                if(clientSEQ > 20){
                    landing_http_handler.display_status("REQUEST FAILED. Please close this window and try again.");
                    landing.stop_loadicon();
                } else {
                    landing_http_handler.retry_contact_request(clientSEQ);
                }
            }
        }
    },

    send_login_request: function(evt){
        //Check if this form is requested legally
        if(evt.target.id === "btn_login"){
            //Show the processing interface
            landing_http_handler.display_status("Contacting Login Server");
            landing.show_processing();

            //Clear the old cache
            datacache = "";

            //Get the data
            var seq = 1; clientSEQ = 1;   //This is the first request to be send out
            var username = document.getElementById('txt_username').value;
            var password = document.getElementById('txt_password').value;
            var remember = document.getElementById('chk_remember').checked;

            //Validate the remember variable
            if(remember) remember = "true";
            else remember = "false";

            //Secure the password
            var sha512_pwd = CryptoJS.SHA512(password);

            //Prepare the data for transfer
            var data = {"SEQ": seq, "username":username, "password":sha512_pwd.toString(), "remember":remember};
            var json = JSON.stringify(data);

            //Save the data in cache
            datacache = json;

            //Send the login Request
            clientSEQ++;
            xhr.sendXHR('post', './http/http_login.php', json ,function(response){landing_http_handler.parse_login_response(response);}, function(status){landing_http_handler.display_status(status);});
        }
    },

    parse_login_response: function(response){
        //Unpack the response
        var data = null;
        try{
            data = JSON.parse(response);
        } catch(ex) {
            //Due to lack of data, guess a next ServerSEQ
            var currentSEQ = parseInt(datacache.SEQ);
            var estimated_server_SEQ  = currentSEQ + 1;

            console.log("No Response Received.");
            console.log(response);

            landing_http_handler.retry_login_request(estimated_server_SEQ);
        }

        //Check if the complete response is received
        if((data != null) && (data.hasOwnProperty("SEQ") && data.hasOwnProperty("Success")))
        {
            //Check whether the data is successfull
            if(data.Success == "true" && data.hasOwnProperty("User_data")){
                //Stop the loading icon
                landing.stop_loadicon();

                //Show the success page
                    //Redirect the user to another page.
                landing_http_handler.display_status("Login Successful");
                    //Stop the animation
                animation_allowed = false;
                animations.reset(document.getElementById('loading_animation'));
                    //Get the values from the response and login.
                landing.login(data.User_data["username"], data.User_data["last_logged_in"], data.User_data["permission"]);
                    //Close the overlay
                landing.hide_overlay();

                //Clear values for next messages
                document.getElementById("txt_username").value = "";
                document.getElementById("txt_password").value = "";

                //Clear the cache
                datacache = "";
            } else {
                //When server returns false, check for system error, or validation error.
                switch (data.Message){
                    case "username":
                        //If the username is wrong:
                            //Re-display the loginform
                        landing.show_log_in();

                            //Set the username to error
                        document.getElementById('login').getElementsByTagName('form')[0].getElementsByTagName('div')[0].className = "error";
                        document.getElementById('lbl_username').textContent = "Username Wrong";

                            //Clear the username field
                        document.getElementById("txt_username").value = "";

                        break;
                    case "password":
                        //If the password is wrong:
                            //Re-display the loginform
                        landing.show_log_in();

                            //Set the password to error
                        document.getElementById('login').getElementsByTagName('form')[0].getElementsByTagName('div')[1].className = "error";
                        document.getElementById('lbl_password').textContent = "Password Wrong";

                            //Clear the password field
                        document.getElementById("txt_password").value = "";

                        break;
                    case "active":
                        //If the account hasn't been activated.
                            //Stop the loading icon
                        landing.stop_loadicon();
                        animation_allowed = false;
                        animations.reset(document.getElementById("loading_animation"));

                            //Display the message
                        landing_http_handler.display_status("Account not (yet) activated.");

                        break;
                    default:
                        console.log(data.Message);
                        landing_http_handler.retry_login_request(data.SEQ);
                }
            }
        }
        else{
            //Due to lack of data, guess a next ServerSEQ
            var currentSEQ = parseInt(datacache.SEQ);
            var estimated_server_SEQ  = currentSEQ + 1;
            landing_http_handler.retry_login_request(estimated_server_SEQ);
        }
    },

    retry_login_request: function(serverSEQ){
        //Check whether retry is allowed or not
        if(retry_allowed) {
            if(serverSEQ == clientSEQ){
                //Check whether the SEQ isn't overwriting the maximum retry attempts
                if (serverSEQ > 5) {
                    landing_http_handler.display_status("LOGIN FAILED. Please close this window and try again.");
                    landing.stop_loadicon();
                } else {
                    //Display the status
                    landing_http_handler.display_status('Login Failed. Retrying...');

                    //Validate serverSEQ
                    if (serverSEQ != parseInt(serverSEQ)) {
                        serverSEQ = 10;
                    }

                    //Get the data
                    var data = JSON.parse(datacache);
                    data.SEQ = serverSEQ;
                    var json = JSON.stringify(data);

                    //Retry the request
                    clientSEQ++;
                    if (json != "undefined") xhr.sendXHR('post', './http/http_login.php', json, function (response) {
                        landing_http_handler.parse_login_response(response);
                    });
                }
            } else {
                //Safety precaution, set the client SEQ double as the server SEQ
                if(clientSEQ > 10){
                    landing_http_handler.display_status("LOGIN FAILED. Please close this window and try again.");
                    landing.stop_loadicon();
                } else {
                    landing_http_handler.retry_login_request(clientSEQ);
                }
            }
        }
    },

    send_register_request: function(evt){
        //Check if this form is requested legally
        if(evt.target.id === "btn_register"){
            //Show the processing interface
            landing_http_handler.display_status("Contacting Server");
            landing.show_processing();

            //Clear the old data cache
            datacache = "";

            //Get the data
            var seq = 1; clientSEQ = 1; //This is the first request to be send out.
            var username = document.getElementById("txt_reg_username").value;
            var password = document.getElementById("txt_reg_password").value;
            var email = document.getElementById("txt_reg_email").value;

            //Prepare the password for unsecure transportation
            var crypwd = CryptoJS.SHA512(password);

            //Prepare the data for transfer
            var data = {"SEQ": seq, "username": username, "password": crypwd.toString(), "email": email};
            var json = JSON.stringify(data);

            //Save the data in cache
            datacache = json;

            //Send the contact Request
            clientSEQ++;
            xhr.sendXHR('post', './http/http_register.php', json, function(response){landing_http_handler.parse_register_response(response);}, function(status){landing_http_handler.display_status(status);});
        }
    },

    parse_register_response: function(response){
        //Unpack the response
        var data = null;
        try{
            data = JSON.parse(response);
        } catch(ex) {
            //Due to lack of data, guess a next ServerSEQ
            var currentSEQ = parseInt(datacache.SEQ);
            var estimated_server_SEQ = currentSEQ + 1;

            console.log("No Response Received");
            console.log(response);

            landing_http_handler.retry_register_request(estimated_server_SEQ);
        }

        //Check if the complete response is received
        if((data != null) && (data.hasOwnProperty("SEQ")) && (data.hasOwnProperty("Success"))){
            //Check whether the data is successfull
                if(data.Success == "true"){
                    //Stop the loading icon
                    landing.stop_loadicon();
                    animation_allowed = false;
                    animations.reset(document.getElementById('loading_animation'));

                    //Display the success message
                    landing_http_handler.display_status("Registration Successful");

                    //Clear values for next registration
                    document.getElementById('txt_reg_username').value = "";
                    document.getElementById('txt_reg_password').value = "";
                    document.getElementById('txt_reg_password_check').value = "";
                    document.getElementById('txt_reg_email').value = "";

                    //Clear the cache
                    datacache = "";
                } else {
                    //When the server returns false, check for system error, or validation errors
                    console.log(data.Message);
                    switch(data.Message){
                        case "username":
                            //If the username is wrong:
                                //Re-Display the registration form
                            landing.show_register();

                                //Set the username to error
                            document.getElementById('register').getElementsByTagName('form')[0].getElementsByTagName('div')[0].className = "error";
                            document.getElementById('lbl_reg_username').textContent = "Username Already Exists";

                                //Clear the username field
                            document.getElementById('txt_reg_username').value = "";

                            break;

                        case "email":
                            //If the email adress is wrong:
                                //Re-Display the registration form
                            landing.show_register();

                                //Set the email to error
                            document.getElementById('register').getElementsByTagName('form')[0].getElementsByTagName('div')[3].className = "error";
                            document.getElementById('lbl_reg_email').textContent = "Registration already requested.";

                                //Clear the email field
                            document.getElementById('txt_reg_email').value = "";

                            break;

                        default:
                            console.log(data.Message);
                            landing_http_handler.retry_register_request(data.SEQ);
                    }
                }
        } else {
            //Due to lack of data, guess a next ServerSEQ
            var currentSEQ = parseInt(datacache.SEQ);
            var estimated_server_SEQ = currentSEQ + 1;
            landing_http_handler.retry_register_request(estimated_server_SEQ);
        }
    },

    retry_register_request: function(serverSEQ){
        //Check whether the retry is allowed or not
        if(retry_allowed){
            if(serverSEQ == clientSEQ){
                //Check whether the SEQ isn't overwriting the maximum retry attempts
                if(serverSEQ > 10){
                    landing_http_handler.display_status("REQUEST FAILED. Please close this window and try again.");
                    landing.stop_loadicon();
                } else {
                    //Display the status
                    landing_http_handler.display_status('Request Failed. Retrying...');
                }

                //Validate serverSEQ
                if(serverSEQ != parseInt(serverSEQ)) serverSEQ = 10;

                //Get the data
                var data = JSON.parse(datacache);
                data.SEQ = serverSEQ;
                var json = JSON.stringify(data);
                datacache = json;

                //Retry the request
                clientSEQ++;
                if(json != "undefined") xhr.sendXHR('post', './http/http_register.php', json, function(response){landing_http_handler.parse_register_response(response);});
            } else {
                //Safety Precaution, set the client SEQ double as the server SEQ
                if(clientSEQ > 20){
                    landing_http_handler.display_status('REQUEST FAILED. Please close this window and try again.');
                    landing.stop_loadicon();
                } else {
                    landing_http_handler.retry_register_request(clientSEQ);
                }
            }
        }
    },

    send_usercheck_request: function(evt){
        //Check if timecache allows new checkup
        if(timecache == "allowed"){
            //Check if this form is requested legally
            if(evt == "txt_reg_username" || evt == "txt_username"){
                //Send a transfer request to check the username.
                    //Get the username
                var user;
                if(evt === "txt_reg_username") user = document.getElementById('txt_reg_username').value;
                else user = document.getElementById('txt_username').value;

                    //Send the request
                xhr.sendXHR('post', './http/http_usercheck.php', user, function(response){landing_http_handler.parse_usercheck_response(response);});

                    //Set the caches
                timecache = "refused";
                datacache = evt;
                setTimeout(function(){timecache = "allowed";}, 100);
            }
        }
    },

    parse_usercheck_response: function(response){
        if(response == "true" || response == "false"){
            switch (datacache){
                case "txt_reg_username":
                    if(response == "true"){
                        document.getElementById('register').getElementsByTagName('form')[0].getElementsByTagName('div')[0].className = "error";
                        document.getElementById('lbl_reg_username').textContent = "Username already Exists";
                    }
                    break;
                case "txt_username":
                    if(response == "false"){
                        document.getElementById('login').getElementsByTagName('form')[0].getElementsByTagName('div')[0].className = "error";
                        document.getElementById('lbl_username').textContent = "User does not exist.";
                    }
            }
        }
    },

    send_remember_request: function(){
        //This will be initiated on page load.
            //This will request the server to check for coockies and session, and log the user if they are found.

        //Clear the old cache
        datacache = "";

        //Get the data
        var seq = 1; clientSEQ = 1; //The first request to be send.

        //Prepare the data for transfer
        var data = {"SEQ": seq};
        var json = JSON.stringify(data);

        //Save the data in cache
        datacache = json;

        //Send the remember Request
        clientSEQ++;
        xhr.sendXHR('post', './http/http_remember.php', json, function(response){landing_http_handler.parse_remember_response(response);});
    },

    parse_remember_response: function(response){
        //Unpack the response
        var data = null;
        try{
            data = JSON.parse(response);
        } catch(ex){
            //Due to lack of data, guess a next ServerSEQ
            var currentSEQ = parseInt(datacache.SEQ);
            var estimated_server_SEQ = currentSEQ + 1;

            console.log("No Response Received.");
            console.log(response);

            landing_http_handler.retry_remember_request(estimated_server_SEQ);
        }

        //Check if the complete response is received
        if((data != null) && (data.hasOwnProperty("SEQ")) && (data.hasOwnProperty("Success")) && (data.hasOwnProperty("Message"))){
            //Check whether the data is successfull
            if(data.Success == "true" && data.hasOwnProperty("User_data")){
                //Clear the cache
                datacache = "";

                //Take action in according to the found validation.
                switch (data.Message){
                    case "session":
                        landing.login(data.User_data["username"], data.User_data["last_logged_in"], data.User_data["permission"]);
                        //window.location.href = "./users/index.php";
                        break;
                    case "coockie":
                        landing.login(data.User_data["username"], data.User_data["last_logged_in"], data.User_data["permission"]);
                        break;
                }
            } else {
                landing_http_handler.retry_remember_request(data.SEQ);
            }
        } else {
            //Due to the lack of data, guess a next ServerSEQ
            var currentSEQ = parseInt(datacache.SEQ);
            var estimated_server_SEQ = currentSEQ + 1;
            landing_http_handler.retry_remember_request(estimated_server_SEQ);
        }
    },

    retry_remember_request: function(serverSEQ){
        //Retry only if there is no overlay detected
        if(document.getElementById("overlay").style.display == "block"){
            if(serverSEQ == clientSEQ){
                //Check whether the SEQ isn't overwriting the maximum retry attempts.
                if(serverSEQ > 5){
                    console.log("System Notice: The user has no valid coockies and sessions active. The system has re-checked 5 times.");
                } else {
                    //Validate serverSEQ
                    if(serverSEQ != parseInt(serverSEQ)){
                        serverSEQ = 10; //If the serverSEQ isn't an int, set it to a value which won't pass twice if not updated by the system.
                    }

                    //Get the data
                    var data = JSON.parse(datacache);
                    data.SEQ = serverSEQ;
                    var json = JSON.stringify(data);

                    //Retry the request
                    clientSEQ++;
                    if (json != "undefined") xhr.sendXHR('post', './http/http_remember.php', json, function(response){landing_http_handler.parse_remember_response(response);});
                }
            } else {
                //For  safety precaution, set the client SEQ double as the server SEQ
                if(clientSEQ < 10){
                    landing_http_handler.retry_login_request(clientSEQ);
                }
            }
        }
    }
};