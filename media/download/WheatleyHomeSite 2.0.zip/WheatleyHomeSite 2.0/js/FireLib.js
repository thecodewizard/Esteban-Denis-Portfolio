var xhr = xhr || {};
xhr = {
    sendXHR: function(method, url, data, responseHandler, feedbackHandler){
        //Make a new request
        var xhr;
        //Support for old browsers
        if(window.XMLHttpRequest){
            xhr = new XMLHttpRequest();
        } else xhr = new ActiveXObject("Microsoft.XMLHTTP");

        //When
        xhr.onreadystatechange = function(){
            var message;
            if(xhr.readyState == 1) message = "Server Connection Established";

            if(xhr.readyState == 2) message = "Request Received";

            if(xhr.readyState == 3) message = "Server is processing the Request";

            if((xhr.readyState == 4) && (xhr.status == 200)){
                if(xhr.responseText != "") var response = xhr.responseText;
                else message = "The server gave and empty response. Please Try again.";

                //At this point, a not-empty response has been received
                message = "Analysing Server Response";

                //Hand the response to the handler.
                var send_data = true;

            } else if (xhr.status == 404){
                message = "Server not found. Try again.";
            }

            //Return feedback to the user
            if(typeof feedbackHandler != "undefined") feedbackHandler(message);

            //The data is returned here if the server has set the send_data in readystate 4.
                //This because the server MUST parse the request only AFTER giving the feedback to the handlers
            if(typeof send_data != "undefined" && send_data === true)
                if(typeof responseHandler != "undefined" && response != "undefined") responseHandler(response);
        };

        xhr.onerror = function(){ if(typeof feedbackHandler != "undefined") feedbackHandler("An unknown error occured. Please Try again.");};

        xhr.open(method, url);

        if(method == "post"){
            xhr.setRequestHeader('content-type', 'application/x-www-form-urlencoded');
            xhr.send("data="+data);
        } else if (method == "get") {
            xhr.send();
        } else {
            if(typeof feedbackHandler != "undefined") feedbackHandler("This request type isn't authorised. Please Try again.");
        }
    }
};

var browser_support = browser_support || {};
browser_support = {
    addEvent: function(element, evt, ftion){
        //Check if element exists
        if(element == undefined) return false;

        //For new Browsers
        if(element.addEventListener){
            element.addEventListener(evt, ftion, false);
            return true;
        }

        //For IE
        else if(element.attachEvent){
            element.attachEvent('on' + evt, ftion);
            return true;
        }

        //For Very very old browsers
        else{
            evt = 'on'+evt;
            if(typeof element[evt] === 'function'){
                //if the object already has a listener for another function
                ftion = (function(f1, f2){
                    return function(){
                        f1.apply(this, arguments);
                        f2.apply(this, arguments);
                    }
                })(element[evt], ftion);
            }
            //Assign the function to the object
            element[evt] = ftion;
            return true;
        }
    },

    getParameterByName: function(name) {
        name = name.replace(/[\[]/, "\\[").replace(/[\]]/, "\\]");
        var regex = new RegExp("[\\?&]" + name + "=([^&#]*)"),
        results = regex.exec(location.search);
        return results === null ? "" : decodeURIComponent(results[1].replace(/\+/g, " "));
    }
};
