var send_mail = send_mail || {};
var clientSEQ;

send_mail = {
    init: function () {
        //This is the init for the "admin/send_mail.php" page.
        send_mail.send_permission_check();

        //Bind the eventlisteners
        browser_support.addEvent(document.getElementById('btn_sendmail'), 'click', function(event){send_mail.send_mail(event);});
        browser_support.addEvent(document.getElementById('txt_receiver'), 'keyup', function(){send_mail.check_input();});
        browser_support.addEvent(document.getElementById('txt_subject'), 'keyup', function(){send_mail.check_input();});
        browser_support.addEvent(document.getElementById('txt_title'), 'keyup', function(){send_mail.check_input();});
        browser_support.addEvent(document.getElementById('txt_h3_array'), 'keyup', function(){send_mail.check_input();});
        browser_support.addEvent(document.getElementById('txt_p_array'), 'keyup', function(){send_mail.check_input();});
    },

    check_input: function(){
        //Get the needed elements
        var parent = document.getElementsByTagName('body')[0];
        var receiver = document.getElementById("txt_receiver");
        var subject = document.getElementById("txt_subject");
        var title = document.getElementById("txt_title");
        var headers = document.getElementById("txt_h3_array");
        var message = document.getElementById("txt_p_array");

        var lblreceiver = document.getElementById("lbl_receiver");
        var lblsubject = document.getElementById("lbl_subject");
        var lbltitle = document.getElementById("lbl_title");
        var lblheaders = document.getElementById("lbl_h3");
        var lblmessage = document.getElementById("lbl_p");

        //Make the error messages:
        var receiver_error = "";
        var subject_error = "";
        var message_error = "";
        var title_error = "";
        var headers_error = "";

        //Check the receiver
        if(receiver.value.length <= 2){
            receiver_error = "Email too short";
        } else if (receiver.value.length >= 100) {
            receiver_error = "Email too long";
        } else {
            var regex = /[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?/;
            var email_valid = regex.test(receiver.value);
            if(email_valid == false){
                receiver_error = "Email doesn't comply. Check your input.";
            }
        }

        //Check the subject
        if(subject.value.length <= 2){
            subject_error = "Subject too short";
        } else if (subject.value.length >= 100){
            subject_error = "Subject too long.";
        }

        //Check the title
        if(title.value.length <= 2){
            title_error = "Title too short";
        } else if (title.value.length >= 100){
            title_error = "Title too long.";
        }

        //Check the headers
        if(headers.value.length <= 2){
            headers_error = "Headers too short";
        } else if (headers.value.length >= 100){
            headers_error = "Headers too long.";
        }

        //check the Message
        if(message.value.length <= 10){
            message_error = "Message too short.";
        } else if (message.value.length >= 10000){
            message_error = "Message too long.";
        }

        //Check if the h3 and the message are of equal length
        if(parseInt(headers.value.split(';').length) != parseInt(message.value.split(';').length)){
            headers_error = "Header must have an equal number of messages";
            message_error = "Message must have an equal number of headers";
        }

        //Validation
        if(receiver_error != ""){
            lblreceiver.textContent = receiver_error;
            parent.getElementsByTagName('form')[0].getElementsByTagName('div')[0].className = "error";
        } else {
            lblreceiver.textContent = "To:";
            parent.getElementsByTagName('form')[0].getElementsByTagName('div')[0].className = "";
        }

        if(subject_error != ""){
            lblsubject.textContent = subject_error;
            parent.getElementsByTagName('form')[0].getElementsByTagName('div')[1].className = "error";
        } else {
            lblsubject.textContent = "Subject:";
            parent.getElementsByTagName('form')[0].getElementsByTagName('div')[1].className = "";
        }

        if(title_error != ""){
            lbltitle.textContent = title_error;
            parent.getElementsByTagName('form')[0].getElementsByTagName('div')[2].className = "error";
        } else {
            lbltitle.textContent = "Title:";
            parent.getElementsByTagName('form')[0].getElementsByTagName('div')[2].className = "";
        }

        if(headers_error != ""){
            lblheaders.textContent = headers_error;
            parent.getElementsByTagName('form')[0].getElementsByTagName('div')[3].className = "error";
        } else {
            lblheaders.textContent = "Subtitle Array: (;-delimiter)";
            parent.getElementsByTagName('form')[0].getElementsByTagName('div')[3].className = "";
        }

        if(message_error != ""){
            lblmessage.textContent = message_error;
            parent.getElementsByTagName('form')[0].getElementsByTagName('div')[4].className = "error";
        } else {
            lblmessage.textContent = "Paragraph Array: (;-delimiter)";
            parent.getElementsByTagName('form')[0].getElementsByTagName('div')[4].className = "";
        }

        if(subject_error == "" && receiver_error == "" && title_error == "" && headers_error == "" && message_error == ""){
            document.getElementById('btn_sendmail').className = 'btn';
        } else {
            document.getElementById('btn_sendmail').className = 'btn disabled';
        }
    },

    send_permission_check: function(){
        //This function redirects this page to the admin index page for further authentication.
            //This will be initiated on page load.
            //This will request the server to check for coockies and session, and log the user if they are found.
            //This will return true if the user is logged and permitted.

        //Clear the old cache
        datacache = "";

        //Get the data
        var seq = 1; clientSEQ = 1; //The first request to be send.

        //Prepare the data for transfer
        var data = {"SEQ": seq};
        var json = JSON.stringify(data);

        //Save the data in cache
        datacache = json;

        //Send the remember Request
        clientSEQ++;
        xhr.sendXHR('post', '../../http/users/http_permission.php', json, function(response){send_mail.parse_permission_check(response);});
    },

    parse_permission_check: function(response){
        console.log(response);
        //Unpack the response
        var data = null;
        try{
            data = JSON.parse(response);
        } catch(ex){
            //Due to lack of data, guess a next ServerSEQ
            var currentSEQ = parseInt(datacache.SEQ);
            var estimated_server_SEQ = currentSEQ + 1;

            console.log("No Response Received.");
            console.log(response);

            send_mail.retry_permission_check(estimated_server_SEQ);
        }

        //Check if the complete response is received
        if((data != null) && (data.hasOwnProperty("SEQ")) && (data.hasOwnProperty("Success")) && (data.hasOwnProperty("Message"))) {
            //Check whether the data is successfull
            if (data.Success == "true") {
                //Clear the cache
                datacache = "";
            } else {
                //Take action in according to the found validation.
                switch (data.Message) {
                    case "permission":
                        window.location.href = "../index.php";
                        break;
                    case "session":
                        window.location.href = "../../index.html";
                        break;
                    default :
                        send_mail.retry_permission_check(data.SEQ);
                        break;
                }
            }
        } else {
            //Due to the lack of data, guess a next ServerSEQ
            var currentSEQ = parseInt(datacache.SEQ);
            var estimated_server_SEQ = currentSEQ + 1;
            send_mail.retry_permission_check(estimated_server_SEQ);
        }
    },

    retry_permission_check: function(serverSEQ){
        if(serverSEQ == clientSEQ){
            //Check whether the SEQ isn't overwriting the maximum retry attempts.
            if(serverSEQ > 5){
                console.log("System Notice: The user has no valid coockies and sessions active. The system has re-checked 5 times.");
            } else {
                //Validate serverSEQ
                if(serverSEQ != parseInt(serverSEQ)){
                    serverSEQ = 10; //If the serverSEQ isn't an int, set it to a value which won't pass twice if not updated by the system.
                }

                //Get the data
                var data = JSON.parse(datacache);
                data.SEQ = serverSEQ;
                var json = JSON.stringify(data);

                //Retry the request
                clientSEQ++;
                if (json != "undefined") xhr.sendXHR('post', '../../http/users/http_permission.php', json, function(response){send_mail.parse_permission_check(response);});
            }
        } else {
            //For  safety precaution, set the client SEQ double as the server SEQ
            if(clientSEQ < 10){
                send_mail.retry_permission_check(clientSEQ);
            }
        }
    },

    send_mail: function(evt){
        //Check if this form is requested legally
        if(evt.target.id === "btn_sendmail"){
            //Clear the old cache
            datacache = "";

            //Get the data
            var seq = 1; clientSEQ = 1;   //This is the first request to be send out
            var receiver = document.getElementById('txt_receiver').value;
            var subject = document.getElementById('txt_subject').value;
            var title = document.getElementById('txt_title').value;
            var h3 = document.getElementById('txt_h3_array').value;
            var message = document.getElementById('txt_p_array').value;

            //Prepare the data for transfer
            var data = {"SEQ":seq, "receiver": receiver, "subject": subject, "title":title, "h3":h3, "message": message};
            var json = JSON.stringify(data);

            //Save the data in cache
            datacache = json;

            //Send the contact Request
            clientSEQ++;
            xhr.sendXHR('post', '../../http/users/http_sendmail.php', json, function(response){send_mail.parse_mail(response);});
        }
    },

    parse_mail: function(response){
        //Unpack the response
        var data = null;
        try{
            data = JSON.parse(response);
        } catch(ex) {
            //Due to lack of data, guess a next ServerSEQ
            var currentSEQ = parseInt(datacache.SEQ);
            var estimated_server_SEQ  = currentSEQ + 1;

            console.log("No Response Received.");
            console.log(response);

            send_mail.retry_mail(estimated_server_SEQ);
        }

        //Check if the complete response is received
        if((data != null) && (data.hasOwnProperty("SEQ") && data.hasOwnProperty("Success")))
        {
            //Check whether the data is successfull
            if(data.Success == "true"){
                //Clear values for next messages
                document.getElementById("txt_receiver").value = "";
                document.getElementById("txt_subject").value = "";
                document.getElementById("txt_title").value = "";
                document.getElementById("txt_h3_array").value = "";
                document.getElementById("txt_p_array").value = "";

                //Clear the cache
                datacache = "";
            } else {
                send_mail.retry_mail(data.SEQ);
                console.log(data.Message);
            }
        }
        else{
            //Due to lack of data, guess a next ServerSEQ
            var currentSEQ = parseInt(datacache.SEQ);
            var estimated_server_SEQ  = currentSEQ + 1;
            send_mail.retry_mail(estimated_server_SEQ);
        }
    },

    retry_mail: function(serverSEQ){
        if(serverSEQ == clientSEQ){
            //Check whether the SEQ isn't overwriting the maximum retry attempts
            if (serverSEQ > 10) {
                //Do nothing
            } else {
                //Validate serverSEQ
                if (serverSEQ != parseInt(serverSEQ)) {
                    serverSEQ = 10;
                }

                //Get the data
                var data = JSON.parse(datacache);
                data.SEQ = serverSEQ;
                var json = JSON.stringify(data);
                datacache = json;

                //Retry the request
                clientSEQ++;
                if (json != "undefined") xhr.sendXHR('post', '../../http/users/http_sendmail.php', json, function (response) {
                    send_mail.parse_mail(response);
                });
            }
        } else {
            //Safety precaution, set the client SEQ double as the server SEQ
            if(clientSEQ <= 20){
                send_mail.retry_mail(clientSEQ);
            }
        }
    }
};