<?php
require (__DIR__."/pageparts/page_header.php");
$js_reference = "dashboard";
$auth_level = 1;
require (__DIR__."/../shared_php/authentication.php");
?>
<div id="placeholder">
    <main>
        <section id="flyer">
            <aside>
                <div>
                    <div id="btn_request_extention">Request Extention</div>
                    <div id="btn_browse_media">Browse Media</div>
                    <div id="btn_file_handling">File Handling</div>
                    <div id="btn_host_at_glados">Host@Glados</div>
                </div>
            </aside>
            <article>
                <div>
                    <h1>Ah, <?php echo (isset($username) ? ($username) : ("you again")); ?>, how nice of you to finally visit.</h1>
                </div>
            </article>
        </section>
        <div>
            <section id="dashboard" data-color1="rgba(255,0,0,0.8)" data-color1b="rgba(255,0,0,0.3)" data-color2="rgba(252,194,0,0.8)" data-color2b="rgba(252,194,0,0.2)"
                     data-color3="#6495ED" data-color3b="rgba(100,147,239,0.3)" data-color4="#008000" data-color4b="rgba(0,128,0,0.4)">
                <aside>
                    <h2>It's empty here!</h2>
                    <h3>Add some new content to this page</h3>
                    <p>Click on the links in the flyer to add its window.</p>
                    <h3>Or... just manage what you already have!</h3>
                    <p>Soon you will be able to change your account settings</p>
                </aside>
                <article id="dashboard_request_extention">
                    <h2>Request Extention</h2>
                    <div class="close"><span>X</span></div>
                    <p>Wheatley offers a variety of media content, but we cannot simply have anything. If you like something we don't have yet, you can request an extention to our media database.</p>
                    <p>Make your choice:</p>
                    <div>
                        <div><div class="btn" onclick="window.location.href='./request_extention.php'">Add Request</div></div>
                        <p>Upload or link any .torrent file to add to wheatleys database</p>
                    </div>
                    <div>
                        <div><div class="btn disabled">View Pending Requests</div></div>
                        <p>Follow up on your pending requests.</p>
                    </div>
                    <div>
                        <div><div class="btn disabled">Completed Requests</div></div>
                        <p>Watch, Listen or Download your completed requested extentions.</p>
                    </div>
                </article>
                <article id="dashboard_browse_media">
                    <h2>Browse Media</h2>
                    <div class="close"><span>X</span></div>
                    <p>Enjoy our medialibrary trough Mediabrowser!</p>
                    <p>Why take up your local space on your expensive hard drives if you can watch the vast library of Wheatley? Be ready to be soaked in our library full of intreguing movies, immersive series and touching music.</p>
                    <div>
                        <div><div class="btn" onclick="window.location.href='http://estebandenis.ddns.net:23424/mediabrowser'">Visit Mediabrowser</div></div>
                        <p>Go to our mediabrowser. <?php if($permission_short != "GUEST") echo " When prompted use the password 'ikstreamgraag'.";  ?></p>
                    </div>
                    <div>
                        <div><div class="btn" onclick="window.location.href='ftp://estebandenis.ddns.net:21'">Use FTP-Services</div></div>
                        <p>Using Streamingtools (like VLC), you can stream directly to your Smart TV using your FTP credentials.</p>
                    </div>
                </article>
                <article id="dashboard_file_handling">
                    <h2>Under Development</h2>
                    <div class="close"><span>X</span></div>
                    <p>Wheatley is still fully under construction. Day by day, we progress. Right now we are doing our very best to develop this part right here. <br/>
                        Please have some patience, and soon you will be able to browse this part as well.</p>
                </article>
                <article id="dashboard_host_at_glados">
                    <h2>Under Development</h2>
                    <div class="close"><span>X</span></div>
                    <p>Wheatley is still fully under construction. Day by day, we progress. Right now we are doing our very best to develop this part right here. <br/>
                        Please have some patience, and soon you will be able to browse this part as well.</p>
                </article>
            </section>
        </div>
    </main>
</div>
<?php
require (__DIR__."/pageparts/page_footer.php");
?>