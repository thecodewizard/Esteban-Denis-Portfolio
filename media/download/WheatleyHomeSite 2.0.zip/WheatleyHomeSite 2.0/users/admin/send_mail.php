<?php
session_start();

if(empty($_SESSION["uid"]) || empty($_SESSION["username"]) || empty($_SESSION["last_logged_in"]) || empty($_SESSION["permission"])
    || empty($_SESSION["email"]) || !isset($_SESSION["status"]) || empty($_SESSION["permission_short"])){
    header("location:".__DIR__."./../../index.html");
    die;
} else {
    if($_SESSION["permission_short"] != "ADMIN"){
        header("location:".__DIR__."./../index.php");
        die;
    }
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Wheatley Sendmail</title>

    <!-- General Heads -->
    <meta charset="UTF-8">
    <title>Wheatley HomeSite</title>
    <link rel="icon" href="../../images/icons/temp_icon.jpeg.jpg">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">

    <!-- Stylesheets and Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="../../css/normalize.css"/>
    <link rel="stylesheet" href="../../css/iframe.css"/>

    <!-- Scripts -->
    <script src="../../js/iframe.js"></script>
    <script src="../../js/FireLib.js"></script>
</head>
<body>
    <h3>Send An Email</h3>
    <form>
        <div>
            <label id="lbl_receiver" for="txt_receiver">To:</label><br/>
            <input type="email" name="receiver" id="txt_receiver"/>
        </div>
        <div>
            <label id="lbl_subject" for="txt_subject">Subject:</label><br/>
            <input type="text" name="subject" id="txt_subject"/>
        </div>
        <div>
            <label id="lbl_title" for="txt_title">Title:</label><br/>
            <input type="text" name="title" id="txt_title"/>
        </div>
        <div>
            <label id="lbl_h3" for="txt_h3_array">Subtitle Array: (;-delimiter)</label><br/>
            <input type="text" name="h3_array" id="txt_h3_array"/>
        </div>
        <div>
            <label id="lbl_p" for="txt_p_array">Paragraph Array: (;-delimiter)</label><br/>
            <textarea id="txt_p_array" name="p_array"></textarea>
        </div>
    </form>
    <div class="btn" id="btn_sendmail">Send Email</div>
</body>
<script>
    send_mail.init();
</script>
</html>
