<?php

//Include the needed files
include_once __DIR__."./../../shared_php/db_core/extention_handling.php";
header("location:".$_SERVER["HTTP_REFERER"]."/../index.php");

if(isset($_POST["eid"])){
    //Do control checks on this eid.

    //Upload the File
    $upload = upload_torrent($_FILES["file"]);
}