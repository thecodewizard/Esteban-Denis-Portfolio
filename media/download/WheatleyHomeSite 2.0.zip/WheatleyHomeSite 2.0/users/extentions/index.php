<?php
header("location:".__DIR__."../index.php");
die;