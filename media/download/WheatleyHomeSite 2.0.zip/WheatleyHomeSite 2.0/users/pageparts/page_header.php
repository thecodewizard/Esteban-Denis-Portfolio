<?php
session_start();
$start = microtime(true);

if(empty($_SESSION["uid"]) || empty($_SESSION["username"]) || empty($_SESSION["last_logged_in"]) || empty($_SESSION["permission"])
        || empty($_SESSION["email"]) || !isset($_SESSION["status"]) || empty($_SESSION["permission_short"])){
    header("location:../index.html");
    die;
} else {
    //Save the found data from the sessions
    $uid = $_SESSION["uid"];
    $username = $_SESSION["username"];
    $email = $_SESSION["email"];
    $last_logged_in = $_SESSION["last_logged_in"];
    $status = $_SESSION["status"];
    $permission_short = $_SESSION["permission_short"];
    $permission = $_SESSION["permission"];
}
?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dashboard <?php echo $username; ?></title>
    <!-- General Heads -->
    <link rel="icon" href="./../images/icons/temp_icon.jpeg.jpg">
    <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">

    <!-- Stylesheets and Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Open+Sans' rel='stylesheet' type='text/css'>
    <link rel="stylesheet" href="./../css/normalize.css"/>
    <link rel="stylesheet" href="./../css/wheatley.css"/>
    <link rel="stylesheet" href="./../css/wheatley_768.css" media="screen"/>
    <link rel="stylesheet" href="./../css/wheatley_510.css" media="screen"/>

    <!-- Scripts -->
    <script src="./../js/wheatley.js"></script>
    <script src="./../js/FireLib.js"></script>
</head>
<body>
<header>
    <p>Wheatley HomeSite 2.0</p>
    <div class="btn" id="headerlogout">Logout</div>
    <div class="btn"  id="headerhome">Home</div>
    <?php
    if($_SERVER["PHP_SELF"] != "/users/index.php") echo '<div class="btn" id="headerdashboard">Dashboard</div>';
    ?>
</header>