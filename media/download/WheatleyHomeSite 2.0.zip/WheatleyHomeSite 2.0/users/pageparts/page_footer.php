<?php
$end = microtime(true);
$load_time = round(($end - $start) * 1000, 2, PHP_ROUND_HALF_DOWN);
?>
<div id="pre-footer">
    <p>Version 1.1.8 - Page Load Time: <?php echo $load_time; ?> seconds - Local Time: <span id="currenttime"><?php echo date('H:i:s'); ?></span></p>
</div>
<footer>
    <p>This site is hosted on Wheatley - Part of the GLADOS workgroup. &copy;</p>
</footer>
<script>
    //Execute the init if everything is loaded.
    browser_support.addEvent(window, "DOMContentLoaded", function(){<?php if(isset($js_reference)) echo $js_reference; else echo "dashboard"; ?>.init();});
</script>
</body>
</html>