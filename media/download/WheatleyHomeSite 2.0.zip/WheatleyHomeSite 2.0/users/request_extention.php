<?php
require(__DIR__."/pageparts/page_header.php");
$js_reference = "request";
$auth_level = 1;
require (__DIR__."./../shared_php/authentication.php");
?>
<div id="placeholder">
    <!--<section id="banner">
        <h1>Extention Requests</h1>
    </section> -->
    <section id="add_request">
        <div class="overlay">
            <div id="counter" class="trans no-select">
                <div data-number="0" class="active">Step 1</div>
                <div data-number="1">Step 2</div>
                <div data-number="2">Step 3</div>
                <div data-number="3">Step 4</div>
            </div>
            <h2>Add a request</h2>
            <section>
                <h3>Step 1: Add your .torrent file</h3>
                <div>
                    <div class="btn" id="btn_torrent">Upload .torrent file</div>
                    <div class="btn disabled" id="btn_link">Copy torcache link</div>
                </div>
                <p class="trans" id="p_help">Please select one of the upload choices.</p>
                <form id="link" style="display: none">
                    <label for="txt_link">Your Torcache url:</label>
                    <input type="url" id="txt_link" name="link" value="http://torcache.net/torrent/"/>
                </form>
                <form id="torrent" enctype="multipart/form-data" method="post" action="extentions/upload.php">
                    <label for="txt_file">Your .torrent file:</label>
                    <label for="txt_eid" hidden="hidden"></label>
                    <input type="text" id="txt_eid" name="eid" value="" hidden="hidden"/>
                    <input type="file" id="txt_file" accept=".torrent" name="file"/>
                </form>
                <div class="btn disabled" id="button-step-one" data-type="next">Next &#9654</div>
            </section>
            <section>
                <h3>Step 2: Tell us what you are downloading</h3>
                <form>
                    <label for="cbo_types">Select the media type:</label>
                    <select id="cbo_types" name="types">
                        <option selected disabled>Select your type:</option>
                        <option value="audio">Audio File</option>
                        <option value="image">Image File</option>
                        <option value="video">Video File</option>
                        <option value="other">Other</option>
                    </select>
                    <label for="cbo_subtypes">Select your subtype</label>
                    <select id="cbo_subtypes" name="subtypes">
                        <option selected disabled>Select your subtype:</option>
                        <option data-type="audio" value="artist">Artist album</option>
                        <option data-type="audio" value="separate">Just some seperate songs</option>
                        <option data-type="audio" value="undefined">None of the above</option>
                        <option data-type="video" value="movie">Movie</option>
                        <option data-type="video" value="serie">Serie</option>
                        <option data-type="video" value="undefined">None of the above</option>
                        <option data-type="image" value="personal images">Personal Images</option>
                        <option data-type="image" value="wallpapers">Wallpapers</option>
                        <option data-type="image" value="undefined">None of the above</option>
                        <option data-type="other" value="games">Games</option>
                        <option data-type="other" value="documents">Documents</option>
                        <option data-type="other" value="undefined">None of the above</option>
                    </select>
                </form>
                <div class="btn" data-type="prev">&#9664; Previous</div>
                <div class="btn disabled" id="button-step-two" data-type="next">Next &#9654;</div>
            </section>
            <section>
                <h3>Step 3: Help us to keep everything tidy.</h3>
                <form>
                    <label for="txt_title">The title of the media:</label>
                    <input type="text" id="txt_title" name="title"/>
                    <article data-type="audio">
                        <label for="txt_artist">Artist:</label>
                        <input type="text" id="txt_artist" name="artist"/>
                        <label for="txt_album">Album:</label>
                        <input type="text" id="txt_album" name="album"/>
                        <label for="txt_year_audio">Release Year:</label>
                        <input type="number" id="txt_year_audio"  name="year"/>
                    </article>
                    <article data-type="video">
                        <div data-subtype="movie">
                            <label for="cbo_quality">Movie Quality:</label>
                            <select id="cbo_quality" name="quality">
                                <option selected disabled>Select your quality</option>
                                <option value="3D">3D Movie (Vertical Splitted)</option>
                                <option value="4K">4K Movie (.mkv Only)</option>
                                <option value="2K">2K Movie (or >2K but not .mkv)</option>
                                <option value="Full HD">1080p</option>
                                <option value="HD">720p</option>
                                <option value="DVD"><720p or DVDrip</option>
                                <option value="undefined">None of the above</option>
                            </select>
                            <label for="txt_year_video">Release date:</label>
                            <input type="number" id="txt_year_video" name="year"/>
                        </div>
                        <div data-subtype="serie">
                            <label for="txt_serie">Name Serie:</label>
                            <input type="text" id="txt_serie" name="serie"/>
                            <label for="txt_season">Number Season:</label>
                            <input type="number" id="txt_season" name="season"/>
                        </div>
                    </article>
                    <div class="btn" data-type="prev">&#9664; Previous</div>
                    <div class="btn disabled" data-type="next" id="button-step-three">Next &#9654;</div>
                </form>
            </section>
            <section>
                <h3>Step 4: We are ready. Are you?</h3>
                <form>
                    <label for="txt_comments">Would you like to say something to us?</label>
                    <textarea id="txt_comments" name="comments"></textarea>
                    <label for="chk_mail" id="lbl_mail">Do you which to get mailed when the status of the request changes?</label>
                    <input type="checkbox" id="chk_mail" name="mail" value="mail" checked/><br/>
                    <div class="btn" data-type="prev">&#9664; Previous</div>
                    <div class="btn disabled" id="btn_confirm" data-type="next">Send Request &#9660;</div>
                </form>
            </section>
            <section>
                <h3>We are sending everything to the database...</h3>
                <div id="processing">
                    <p>Please relax while our system handles your request.</p>
                    <div class="loadicon">
                        <div></div>
                        <div></div>
                    </div>
                    <p>Current status:</p>
                    <em id="status">Contacting Server</em><br/>
                </div>
            </section>
        </div>
    </section>
</div>
<?php
require (__DIR__."/pageparts/page_footer.php");
?>