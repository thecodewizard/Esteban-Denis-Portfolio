<?php
//The receiving page expects an array:
    //SEQ: 12
    //Success: "true"
    //Message: "The message to be displayed when success is true or false"
        //--> If Message == "session"|"coockie", javascript will work with those values.
//This page is expecting an json encoded array:
    //SEQ: 11

if(session_status() !== PHP_SESSION_ACTIVE) { session_start(); }
include_once (__DIR__."/../shared_php/db_core/accounting.php");
time_nanosleep(0, rand(1000000, 500000000));

//Make the needed variables
$response = array();
$user_data = array();

//Get and check the received data
if(isset($_POST["data"])) $data = json_decode($_POST["data"], true);
else $data = "";
$SEQ = 0;

if(!empty($data)){
    if(!empty($data["SEQ"])){
        $rSEQ = $data["SEQ"];

        //Check input
        if(is_int($rSEQ)){
            //Calculate the next SEQ
            $SEQ = $rSEQ + 1;

            //Check if a user session is active
            if(!empty($_SESSION["uid"]) && !empty($_SESSION["username"]) && !empty($_SESSION["last_logged_in"]) && !empty($_SESSION["permission"])){
                //Check if the found UID exists.
                $username_query = get_username($_SESSION["uid"]);
                if(!empty($username_query["username"])){
                    $exists = user_exists($username_query["username"]);
                    if($exists){
                        //If the found UID is valid, return that a valid session is found.
                        $success = "true";
                        $message = "session";

                        //Save the user data that was send by the logged user session.
                        $user_data["username"] = $_SESSION["username"];
                        $user_data["last_logged_in"] = $_SESSION["last_logged_in"];
                        $user_data["permission"] = $_SESSION["permission"];

                        //A valid session will not trigger a refresh. This forces the system to go past the coockie
                        //authentication at least one each 20 minutes.
                    }
                } else {
                    $success = "false";
                    $message = "The session_uid wasn't translateable into a valid username";
                }
            } else {
                //If no session is present, check for coockies. (Join the dark side)
                if(!empty($_COOKIE["wheatley_remembers_user"]) && !empty($_COOKIE["wheatley_remembers_hash"])){
                    //Save the coockies
                    $username = $_COOKIE["wheatley_remembers_user"];
                    $hash = str_replace("%24", "$", $_COOKIE["wheatley_remembers_hash"]);

                    //Check if the user of the first coockie exists.
                    if(user_exists($username)){
                        //Check if coockies are correct.
                        $validation = validate_coockie($username, $hash);

                        if(is_array($validation)){
                            if(!empty($validation["success"]) && $validation["success"]){
                                //If the coockies are deemed valid, create a new session.
                                    //Get the UID via the feedback funtion on 'user exists'
                                $uid = user_exists($username, false, true); //No validation is needed because of the use of user_exists earlier on.
                                    //Write the new session logs.
                                $session = set_logged_session($uid);

                                if(is_array($session)){
                                    if($session["success"]){
                                        //Save the user data that was send by the logged user session.
                                        $user_data["username"] = $session["username"];
                                        $user_data["last_logged_in"] = $session["last_logged_in"];
                                        $user_data["permission"] = $session["permission"];
                                        
                                        //In order to validate, one must eat the coockie. So we need to make a new one in order to keep eating.
                                        $coockie = create_coockie($uid, $username);

                                        if(is_array($coockie)){
                                            if(!empty($coockie["success"]) && $coockie["success"]){
                                                $success = "true";
                                                $message = "coockie";
                                            } else {
                                                $success = "false";
                                                $message = $coockie["error"];
                                            }
                                        } else {
                                            $success = "false";
                                            $message = "The response of the server was unexpected";
                                        }
                                    } else {
                                        $success = "false";
                                        $message = "failed to create a session";
                                    }
                                } else {
                                    $success = "false";
                                    $message = "The response of the server was unexpected";
                                }
                            } else {
                                $success = "false";
                                $message = $validation["error"];
                            }
                        } else {
                            $success = "false";
                            $message = "The response of the server was unexpected";
                        }
                    } else {
                        $success = "false";
                        $message = "The user found in the coockie doesn't exist.";
                    }
                } else {
                    $success = "false";
                    $message = "The 'remember me' coockies aren't present";
                }
            }
        } else {
            $success = "false";
            $message = "The SEQ received cannot be converted to int.";
        }
    } else {
        $success = "false";
        $message = "Not all the data was received";
    }
} else {
    $success = "false";
    $message = "No data was received";
}

//Compile the response
if(!empty($SEQ)) $response["SEQ"] = $SEQ;
if(!empty($success)) $response["Success"] = $success;
if(!empty($message)) $response["Message"] = $message;
if(!empty($user_data)) $response["User_data"] = $user_data;

print json_encode($response);