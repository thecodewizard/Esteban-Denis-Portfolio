<?php
//The receiving page expects an array:
    //SEQ: 12
    //Success: "true"
    //Message: "The message to be displayed when succes is false"
        //--> If Message == "username"|"password", javascript will see that those values have mismatched.
//This page is expecting an json encoded array:
    //SEQ: 11
    //username: "an username"
    //password: "a password"
    //remember: "true" or "false"

include_once "../shared_php/db_core/accounting.php";
time_nanosleep(0, rand(10000000, 500000000));

//Make the needed variables
$response = array();
$user_data = array();

//Get and check the received data
if(isset($_POST["data"])) $data = json_decode($_POST["data"], true);
else $data = "";
$SEQ = 0;

if(!empty($data)){
    if(!empty($data["SEQ"]) && !empty($data["username"]) && !empty($data["password"]) && !empty($data["remember"])){
        $rSEQ = $data["SEQ"];
        $username = $data["username"];
        $password = $data["password"];
        $remember = $data["remember"];

        //Check input
        if(is_int($rSEQ)){
            //Calculate the next SEQ
            $SEQ = $rSEQ + 1;

            //Check the remember value
            if($remember == "true" || $remember == "false"){
                //Check the lengths
                if((strlen($username) < 100) && (strlen($password) < 1000) ){
                    //Try login
                    $logged_in = validate_login($username, $password);
                    if(is_array($logged_in)){
                        if(!empty($logged_in["success"]) && $logged_in["success"]){
                            //Get the UID for session handling.
                            if(!empty($logged_in["logged_uid"])){
                                $uid = $logged_in["logged_uid"];

                                //When successful, create the sessions
                                $session = set_logged_session($uid);

                                if(is_array($session)){
                                    //Check if the session has been created successfully
                                    if($session["success"]){
                                        if(isset($session["username"]) && isset($session["last_logged_in"]) && isset($session["permission"])){
                                            //Save the user data that was send by the logged user session.
                                            $user_data["username"] = $session["username"];
                                            $user_data["last_logged_in"] = $session["last_logged_in"];
                                            $user_data["permission"] = $session["permission"];

                                            //If requested, make a remember coockie
                                            if($remember == "true"){
                                                //Make the coockie
                                                $coockie = create_coockie($uid, $username);
                                                if(is_array($coockie)){
                                                    if($coockie["success"]){
                                                        $success = "true";
                                                    } else {
                                                        $success = "false";
                                                        $message = $coockie["error"];
                                                    }
                                                } else {
                                                    $success = "false";
                                                    $message = "The response of the server was unexpected (coockie)";
                                                }
                                            } else $success = "true"; //If no coockie is required and the system got to this point, the session was succesfully created.
                                        } else {
                                            $success = "false";
                                            $message = "The sessions did not contain nescessary data";
                                        }
                                    } else {
                                        $success = "false";
                                        $message = $session["error"];
                                    }
                                } else {
                                    $success = "false";
                                    $message = "The response of the server was unexpected (session)";
                                }
                            } else {
                                $success = "false";
                                $message = "Server could not fetch all the data";
                            }
                        } else {
                            $success = "false";
                            $message = $logged_in["error"];
                        }
                    } else {
                        $success = "false";
                        $message = "The response of the server was unexpected (logged-in)";
                    }
                } else {
                    $success = "false";
                    $message = "The input data was too long.";
                }
            } else {
                $success = "false";
                $message = "Remember Checkbox caused error";
            }
        } else {
            $success = "false";
            $message = "The SEQ received cannot be converted to int.";
        }
    } else {
        $success = "false";
        $message = "Not all the data was received";
    }
} else {
    $success = "false";
    $message = "No data was received";
}

//Compile the response
if(!empty($SEQ)) $response["SEQ"] = $SEQ;
if(!empty($success)) $response["Success"] = $success;
if(!empty($message)) $response["Message"] = $message;
if(!empty($user_data)) $response["User_data"] = $user_data;

print json_encode($response);