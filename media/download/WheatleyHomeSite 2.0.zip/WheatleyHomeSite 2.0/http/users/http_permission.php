<?php
//The receiving page expects an array:
    //SEQ: 12
    //Success: "true"
    //Message: "The message to be displayed when success is true or false"
    //If Message = "permission"  || "session" the page will interpret that.
//This page is expecting an json encoded array:
    //SEQ: 11

if(session_status() !== PHP_SESSION_ACTIVE) { session_start(); }
include_once (__DIR__."/../../shared_php/db_core/accounting.php");

//Make the needed variables
$response = array();
$user_data = array();

//Get and check the received data
$data = json_decode($_POST["data"], true);
$SEQ = 0;

if(!empty($data)) {
    if (!empty($data["SEQ"])) {
        $rSEQ = $data["SEQ"];

        //Check input
        if(is_int($rSEQ)) {
            //Calculate the next SEQ
            $SEQ = $rSEQ + 1;

            //Check if the session is active
            if(!empty($_SESSION["uid"]) && !empty($_SESSION["username"]) && !empty($_SESSION["last_logged_in"]) && !empty($_SESSION["permission"])){
                //Assign the variables
                $uid = $_SESSION["uid"];
                $username = $_SESSION["username"];

                //Validate the user.
                $db_username = get_username($uid);  //By name
                if(is_array($db_username) && $db_username["success"]){
                    if($username === $db_username["username"]){
                        $db_uid = user_exists($username, false, true);  //By UID
                        if($db_uid === $uid){
                            //When the user is deemed valid, check the permission.
                            if(check_permission($uid, 1)){
                                $success = "true";
                                $message = "The user is an administrator";
                            } else {
                                $success = "false";
                                $message = "permission";
                            }
                        } else {
                            $success = "false";
                            $message = "The UID validation control did not succeed: ".$db_uid;
                        }
                    } else {
                        $success = "false";
                        $message = "The User validation control did not succeed: ".$db_username["username"];
                    }
                } else {
                    $success = "false";
                    $message = "The DB-fetch of the username failed.";
                }
            } else {
                $success = "false";
                $message = "session";
            }
        } else {
            $success = "false";
            $message = "The SEQ received cannot be converted to int.";
        }
    } else {
        $success = "false";
        $message = "Not all the data was received";
    }
} else {
    $success = "false";
    $message = "No data was received";
}

//Compile the response
if(!empty($SEQ)) $response["SEQ"] = $SEQ;
if(!empty($success)) $response["Success"] = $success;
if(!empty($message)) $response["Message"] = $message;

print json_encode($response);