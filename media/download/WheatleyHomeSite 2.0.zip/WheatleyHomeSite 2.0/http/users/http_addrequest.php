<?php
//The receiving page expects an array:
    //SEQ: 12
    //Success: true
    //Message: "The message to be displayed when succes is false"
//This page is expecting an json encoded array:
    //SEQ: 11
    //File_upload: true (when .torrent), false (when link)
    //File_info: 'filepath when .torrent', 'link when link'
    //Type: "Type of the media"
    //Subtype: "Subtype of the Media"
    //Title: "Title of the Media"
    //Comments: "User comments with download"
    //Mail: true of false
    //Artist (optionary)
    //Album (optionary)
    //Year (optionary)
    //Quality (optionary)
    //Serie (optionary)
    //Season (optionary)

if(session_status() !== PHP_SESSION_ACTIVE) { session_start(); }
include_once (__DIR__."./../../shared_php/db_core/extention_handling.php");
include_once (__DIR__."./../../shared_php/db_core/accounting.php");
sleep(2);

//Make the needed variables
$response = array();
$auth_level = 3;

//Get and check the received data
if(isset($_POST["data"])) $data = json_decode($_POST["data"], true);
else $data = "";
$SEQ = 0;

if(!empty($data)){
    //Check the input
    if(!empty($data["SEQ"]) && is_int($data["SEQ"])){
        //Calculate the next SEQ.
        $SEQ = $data["SEQ"] + 1;

        //Check other input
        if(!empty($data["File_upload"]) && isset($data["File_info"]) && !empty($data["Type"]) && !empty($data["Subtype"]) &&
         !empty($data["Title"]) && isset($data["Comments"]) && isset($data["Mail"])){
            $file_upload = $data["File_upload"];
            if($file_upload) $file_info =  json_decode($data["File_info"], true);
            else $file_info = $data["File_info"];
            $type = $data["Type"];
            $subtype = $data["Subtype"];
            $title = $data["Title"];
            $comments = $data["Comments"];
            $mail = $data["Mail"];

            //Check for options
            $options = array();
            if(!empty($data["Artist"])) $options["artist"] = $data["Artist"];
            if(!empty($data["Album"])) $options["album"] = $data["Album"];
            if(!empty($data["Year"])) $options["year"] = $data["Year"];
            if(!empty($data["Quality"])) $options["quality"] = $data["Quality"];
            if(!empty($data["Serie"])) $options["serie"] = $data["Serie"];
            if(!empty($data["Season"])) $options["season"] = $data["Season"];

            //Check the validity of the input
                //Whole Series of checks on the validity of the data.
            $valid = true;

            if($valid){
                //Get the user's uid
                if(!empty($_SESSION["uid"])){
                    $uid = $_SESSION["uid"];

                    //Check the user's permission to download.
                    if(check_permission($uid, $auth_level)){
                        $title = prepare_title($type, $subtype, $title, $options);

                        if(!empty($title) && is_array($title)){
                            if($title["success"]){
                                $torrent_name = $title["title"];

                                //If torrent, request and process the upload. If link, request and process the download.
                                if($file_upload){
                                    //Write all the info to the database.
                                        //DATABASE INTERACTION

                                    //Expected in return is the extention_id.
                                    $salt = 15 + rand(1000, 999999999);
                                    $extention_id = "15".$salt;
                                    $success = "true";
                                    $eid = base64_encode($extention_id);

                                } else {
                                    //Download the torcache link;
                                    $success = "true";
                                }
                            } else {
                                $success = "false";
                                $message = $title["error"];
                            }
                        } else {
                            $success = "false";
                            $message = "The server gave an unexpected response. - Title";
                        }
                    } else {
                        $success = "false";
                        $message = "Access Denied";
                    }
                } else {
                    $success = "false";
                    $message = "Couldn't fetch the users ID.";
                }
            } else {
                $success = "false";
                $message = "The received data wasn't correct";
            }
        } else {
            $success = "false";
            $message = "Not all the data was received from the request.";
        }
    } else {
        $success = "false";
        $message = "SEQ couldn't be calculated.";
    }
} else {
    $success = "false";
    $message = "No data was received";
}

//Compile the response
if(!empty($SEQ)) $response["SEQ"] = $SEQ;
if(!empty($success)) $response["Success"] = $success;
if(!empty($message)) $response["Message"] = $message;
if(!empty($eid)) $response["Eid"] = $eid;

print json_encode($response);