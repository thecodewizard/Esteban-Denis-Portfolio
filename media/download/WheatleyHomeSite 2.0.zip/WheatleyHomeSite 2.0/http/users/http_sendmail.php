<?php
//The receiving page expects an array:
    //SEQ: 12
    //Success: "true"
    //Message: "The message to be displayed when success is false"
//This page is expecting an json encoded array:
    //SEQ: 11
    //username: "an username"
    //password: "a password"
    //remember: "true" or "false"
//In order to enter this page, a user must be logged in and have
//a clearance level 1.

include_once (__DIR__."/../../shared_php/mail.php");
if(session_status() !== PHP_SESSION_ACTIVE) { session_start(); }

//Make the needed variables
$response = array();

//Get and check the received data
$data = json_decode($_POST["data"], true);
$SEQ = 0;

if(!empty($data)) {
    if (!empty($data["SEQ"]) && !empty($data["receiver"]) && !empty($data["subject"]) && !empty($data["title"]) && !empty($data["h3"]) && !empty($data["message"])) {
        $rSEQ = $data["SEQ"];
        $receiver = $data["receiver"];
        $subject = $data["subject"];
        $title = $data["title"];
        $h3 = $data["h3"];
        $message = $data["message"];

        //Check whether the admin privileges are present for sending mail.
        if(!empty($_SESSION["permission_short"]) && $_SESSION["permission_short"] == "ADMIN"){
            //Check input
            if (is_int($rSEQ)) {
                //Calculate the next SEQ.
                $SEQ = $rSEQ + 1;

                //Check the email
                if (strpos($receiver, '@') > 1) {
                    //Strip the message
                    $message = htmlentities($message);

                    //Check to lenghts of the data before writing to db_core
                    if(strlen($receiver) <= 100 && strlen($subject) <= 100 && strlen($message) <= 10000){
                        if(substr_count($message, ";") == substr_count($h3, ";")){
                            //Make the arrays
                            $h3_array = explode(";", $h3);
                            $message_array = explode(";", $message);

                            //Send the email
                            $success = send_email($receiver, $subject, $title, $h3_array, $message_array);
                            if($success == false) $message = "The mail was not send.";

                            if($success) $success = "true";
                            else $success = "false";

                        } else {
                            $success = "false";
                            $message = "The article arrays didn't contain the same number of pieces.";
                        }
                    } else {
                        $success = "false";
                        $message = "The input data was too long.";
                    }
                } else {
                    $success = "false";
                    $message = "The email adress given does not contain @.";
                }
            } else {
                $success = "false";
                $message = "The SEQ received cannot be converted to int.";
            }
        } else {
            $success = "false";
            $message = "The user was not identified as 'administrator'";
        }
    } else {
        $success = "false";
        $message = "Not all the data was received";
    }
} else {
    $success = "false";
    $message = "No data was received";
}

//Compile the response
if(!empty($SEQ)) $response["SEQ"] = $SEQ;
if(!empty($success)) $response["Success"] = $success;
if(!empty($message)) $response["Message"] = $message;

print json_encode($response);
