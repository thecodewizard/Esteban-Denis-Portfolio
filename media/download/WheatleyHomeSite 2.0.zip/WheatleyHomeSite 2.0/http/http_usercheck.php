<?php
//The receiving page expects the value 'true' or 'false'
//This page expects the username

include_once "../shared_php/db_core/accounting.php";
time_nanosleep(0, rand(10000000, 100000000));

if(isset($_POST["data"])) $data = $_POST["data"];
else $data = "";

if(!empty($data)){
    $username = htmlentities($data);
    $success = user_exists($username);
    if($success) echo "true";
    else echo "false";
} else echo "false";