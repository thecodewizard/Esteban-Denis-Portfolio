<?php
//The receiving page expects an array:
    //SEQ: 12
    //Success: "true"
    //Message: "The message to be displayed when succes is false"
    //--> If Message == "username"|"email", javascript will see that those values have mismatched.
//This page is expecting an json encoded array:
    //SEQ: 11
    //username: "an username"
    //password: "a password"
    //email:  "an emailadress"

include_once "../shared_php/db_core/accounting.php";
time_nanosleep(0, 500000000);

//Make the needed variables
$response = array();

//Get and check the received data
if(isset($_POST["data"])) $data = json_decode($_POST["data"], true);
else $data = "";
$SEQ = 0;

if(!empty($data)){
    if(!empty($data["SEQ"]) && !empty($data["username"]) && !empty($data["password"]) && !empty($data["email"])){
        $rSEQ = $data["SEQ"];
        $username = $data["username"];
        $password = $data["password"];
        $email = $data["email"];

        //Check input
        if(is_int($rSEQ)){
            //Calculate the next SEQ
            $SEQ = $rSEQ + 1;

            //Check the email
            if(strpos($email, '@') > 0) {

                //Check the lengths
                if ((strlen($username) < 100) && (strlen($password) < 1000)) {

                    //All self-registered users will be marked as 'restricted users' with the status 'Pending Registration'.
                    $result = register_user($username, $password, 4, $email);
                    if(is_array($result)){
                        if(!empty($result["success"]) && $result["success"]){
                            $success = "true";

                            //When successful, send a thank you mail to the registered user.
                            include_once "../shared_php/mail.php";
                            $mail_send = send_thank_you_registration($email);

                            if($mail_send == false){
                                $success = "false";
                                $message = "Registration complete but mail not send.";
                            }
                        } else {
                            $success = "false";
                            $message = $result["error"];
                        }
                    } else {
                        $success = "false";
                        $message = "The response of the server was unexpected.";
                    }
                } else {
                    $success = "false";
                    $message = "The input data was too long.";
                }
            } else {
                $success = "false";
                $message = "The email adress given does not contain @.";
            }
        } else {
            $success = "false";
            $message = "The SEQ received cannot be converted to int.";
        }
    } else {
        $success = "false";
        $message = "Not all the data was received";
    }
} else {
    $success = "false";
    $message = "No data was received";
}

//Compile the response
if(!empty($SEQ)) $response["SEQ"] = $SEQ;
if(!empty($success)) $response["Success"] = $success;
if(!empty($message)) $response["Message"] = $message;

print json_encode($response);