<?php
//The receiving page expects an array:
    //SEQ: 12
    //Success: true
    //Message: "The message to be displayed when succes is false"
//This page is expecting an json encoded array:
    //SEQ: 11
    //sender: "an emailadress"
    //subject: "a subject"
    //message: "a message"

include_once "../shared_php/db_core/contact.php";
time_nanosleep(0, rand(50000000, 250000000));

//Make the needed variables
$response = array();

//Get and check the received data
if(isset($_POST["data"])) $data = json_decode($_POST["data"], true);
else $data = "";
$SEQ = 0;

if(!empty($data)){
    if(!empty($data["SEQ"]) && !empty($data["sender"]) && !empty($data["subject"]) && !empty($data["message"])){
        $rSEQ = $data["SEQ"];
        $sender = $data["sender"];
        $subject = $data["subject"];
        $message = $data["message"];

        //Check input
        if(is_int($rSEQ)){
            //Calculate the next SEQ.
            $SEQ = $rSEQ + 1;

            //Check the email
            if(strpos($sender, '@') > 1){
                //Strip the message
                $message = htmlentities($message);

                //Calculate the current time
                $time = time();

                //Check to lenghts of the data before writing to db_core
                if(strlen($sender) <= 100 && strlen($subject) <= 100 && strlen($message) <= 10000){
                    //Save the message
                    $saved = save_contact($sender, $subject, $message, $time);
                    if(is_array($saved)){
                        if(!empty($saved["success"]) && $saved["success"]){
                            $success = "true";
                        } else {
                            $success = "false";
                            $message = $saved["error"];
                        }
                    } else {
                        $success = "false";
                        $message = "The response of the server was unexpected";
                    }
                } else {
                    $success = "false";
                    $message = "The input data was too long.";
                }
            } else {
                $success = "false";
                $message = "The email adress given does not contain @.";
            }
        } else {
            $success = "false";
            $message = "The SEQ received cannot be converted to int.";
        }
    } else {
        $success = "false";
        $message = "Not all the data was received";
    }
} else {
    $success = "false";
    $message = "No data was received";
}

//Compile the response
if(!empty($SEQ)) $response["SEQ"] = $SEQ;
if(!empty($success)) $response["Success"] = $success;
if(!empty($message)) $response["Message"] = $message;

print json_encode($response);

